
export interface PackageRow {
  id: string; // internal unique id
  number: number;
  npm_url: string;
  repository_url?: string; // New: GitHub/Repo URL
  entrypoints?: string[]; // New: Detected entry files (main, bin, etc.)
  author_name: string; // Kept for CSV compatibility
  maintainers?: string[]; // New: Array of maintainer names
  package_name: string;
  version?: string;
  file_number: number;
  unpacked_size: number;
  install_size?: number; // New: Bundlephobia minified+gzip size
  dependencies: number;
  dependencies_list?: string[]; // New: List of dependency package names
  dependents: number;
  latest_release_published_at: string;
  description: string;
  keywords: string;
  license: string;
  is_esm?: boolean; // New: Skypack ESM detection
  _status: 'idle' | 'pending' | 'enriched' | 'error';
  _error?: string;
  virtualIndex?: number;
}

export enum SortField {
  NUMBER = 'number',
  NAME = 'package_name',
  SIZE = 'unpacked_size',
  INSTALL_SIZE = 'install_size',
  FILES = 'file_number',
  DATE = 'latest_release_published_at',
}

export enum SortOrder {
  ASC = 'asc',
  DESC = 'desc',
}

export interface FilterState {
  search: string;
  minSizeMB: number;
  maxSizeMB: number;
  minFiles: number;
  minDate: string;
  hasKeywords: boolean;
  hideFailed: boolean;
}

export interface Stats {
  total: number;
  enriched: number;
  failed: number;
  totalSize: number;
}

// --- Indexer Types ---

export interface IndexerConfig {
  registry: string;
  startSequence: string;
  endSequence: string; 
  workers: number;
}

export interface LogEntry {
  id: string;
  timestamp: Date;
  message: string;
  type: 'info' | 'error' | 'success' | 'warn';
}

export interface PackageInfo {
  seq: string;
  name: string;
}

export interface WorkerStatus {
  id: number;
  currentSeq: string;
  status: 'idle' | 'working' | 'finished' | 'error';
  packagesFound: number;
  progress: number; // 0-100
}