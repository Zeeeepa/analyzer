
import React, { useState, useRef, useCallback, useEffect, useMemo } from 'react';
import { PackageRow, SortField, SortOrder, FilterState, Stats, PackageInfo } from './types';
import { VirtualTable } from './components/VirtualTable';
import { StatsBar } from './components/StatsBar';
import { ProjectDialog } from './components/ProjectDialog';
import { AuthorDialog } from './components/AuthorDialog';
import { DependenciesDialog } from './components/DependenciesDialog';
import { DependentsDialog } from './components/DependentsDialog';
import { ChatDialog } from './components/ChatDialog';
import { RegistryFetcherDialog } from './components/RegistryFetcherDialog';
import { enrichPackage, cleanPackageName } from './services/npmService';
import { DEFAULT_START_SEQ } from './services/registryService';

// Extend window interface for PapaParse which is loaded via CDN
declare global {
  interface Window {
    Papa: any;
  }
}

export default function App() {
  // We use a ref for the master list to avoid massive re-renders during enrichment of millions of rows.
  const masterRowsRef = useRef<PackageRow[]>([]);
  // Map package name to index in masterRowsRef for O(1) lookups/updates
  const packageMapRef = useRef<Map<string, number>>(new Map()); 
  
  const [displayRows, setDisplayRows] = useState<PackageRow[]>([]);
  const [isEnriching, setIsEnriching] = useState(false);
  const [stats, setStats] = useState<Stats>({ total: 0, enriched: 0, failed: 0, totalSize: 0 });
  const [workerLimit, setWorkerLimit] = useState(100);
  
  const [sortField, setSortField] = useState<SortField>(SortField.NUMBER);
  const [sortOrder, setSortOrder] = useState<SortOrder>(SortOrder.ASC);
  const [filter, setFilter] = useState<FilterState>({
    search: '',
    minSizeMB: 0,
    maxSizeMB: 0,
    minFiles: 0,
    minDate: '',
    hasKeywords: false,
    hideFailed: false,
  });

  // Dialog States
  const [selectedProject, setSelectedProject] = useState<PackageRow | null>(null);
  const [selectedAuthor, setSelectedAuthor] = useState<string | null>(null);
  const [selectedDepsPkg, setSelectedDepsPkg] = useState<string | null>(null);
  const [selectedDependentsPkg, setSelectedDependentsPkg] = useState<string | null>(null);
  const [chatContext, setChatContext] = useState<{project: PackageRow, tree?: string, activeFile?: string, activeCode?: string} | null>(null);
  
  // Fetcher State
  const [showFetcher, setShowFetcher] = useState(false);
  const [lastSequence, setLastSequence] = useState<string>(() => {
      return localStorage.getItem('npm_last_seq') || DEFAULT_START_SEQ;
  });
  const [showSuccessDialog, setShowSuccessDialog] = useState<{count: number, updated: number, time: string, seq: string} | null>(null);
  
  // Session stats for the current fetch operation
  const fetchSessionStatsRef = useRef({ added: 0, updated: 0 });

  // Enrichment Queue Management
  const enrichmentQueueRef = useRef<number[]>([]);
  const activeRequestsRef = useRef<number>(0);
  const isEnrichingRef = useRef<boolean>(false);
  const workerLimitRef = useRef(100); 
  
  // Performance Buffers
  // 1. Buffer for enrichment status updates
  const updatesBufferRef = useRef<{index: number, data: Partial<PackageRow>}[]>([]);
  // 2. Buffer for new incoming rows from Indexer
  const incomingRowsBufferRef = useRef<PackageInfo[]>([]);

  // Update ref when state changes
  useEffect(() => {
      workerLimitRef.current = workerLimit;
  }, [workerLimit]);
  
  // Data Version to trigger re-filters properly from the queue
  const [dataVersion, setDataVersion] = useState(0);

  // --- Batch Update Loop (Performance Optimization) ---
  useEffect(() => {
    const intervalId = setInterval(() => {
      let needsUpdate = false;

      // 1. Process Incoming Rows (From Indexer)
      if (incomingRowsBufferRef.current.length > 0) {
        const newPackages = incomingRowsBufferRef.current.splice(0, incomingRowsBufferRef.current.length);
        let batchAdded = 0;
        let batchUpdated = 0;
        
        newPackages.forEach(pkg => {
           if (packageMapRef.current.has(pkg.name)) {
               // Existing Package: Mark for update
               const idx = packageMapRef.current.get(pkg.name)!;
               const row = masterRowsRef.current[idx];
               
               // Only reset if not already pending/enriching to avoid race conditions
               if (row._status !== 'pending') {
                   row._status = 'idle';
                   row._error = undefined;
                   // Optional: Clear version to visually indicate staleness? 
                   // No, keep old data until new data arrives is better UX.
                   batchUpdated++;
                   fetchSessionStatsRef.current.updated++;
               }
           } else {
               // New Package
               const newIndex = masterRowsRef.current.length;
               packageMapRef.current.set(pkg.name, newIndex);
               
               const newRow: PackageRow = {
                  id: crypto.randomUUID(),
                  number: newIndex + 1,
                  npm_url: `https://www.npmjs.com/package/${pkg.name}`,
                  author_name: '',
                  package_name: pkg.name,
                  file_number: 0,
                  unpacked_size: 0,
                  dependencies: 0,
                  dependents: 0,
                  latest_release_published_at: '',
                  description: '',
                  keywords: '',
                  license: '',
                  _status: 'idle'
               };
               masterRowsRef.current.push(newRow);
               batchAdded++;
               fetchSessionStatsRef.current.added++;
           }
        });

        if (batchAdded > 0 || batchUpdated > 0) needsUpdate = true;
      }

      // 2. Process Enrichment Updates
      if (updatesBufferRef.current.length > 0) {
        const batch = updatesBufferRef.current.splice(0, updatesBufferRef.current.length);
        batch.forEach(({ index, data }) => {
          if (masterRowsRef.current[index]) {
               Object.assign(masterRowsRef.current[index], data);
          }
        });
        needsUpdate = true;
      }

      if (needsUpdate) {
        updateStats();
        setDataVersion(v => v + 1);
      }

    }, 250); // Run at 4 FPS (every 250ms) to keep UI responsive

    return () => clearInterval(intervalId);
  }, []);


  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!window.Papa) {
      alert('CSV Parser not loaded. Please refresh.');
      return;
    }

    // Reset state
    masterRowsRef.current = [];
    packageMapRef.current.clear();
    setStats({ total: 0, enriched: 0, failed: 0, totalSize: 0 });
    setIsEnriching(false);
    isEnrichingRef.current = false;
    setSelectedProject(null);
    setChatContext(null);
    updatesBufferRef.current = [];
    incomingRowsBufferRef.current = [];
    enrichmentQueueRef.current = [];
    activeRequestsRef.current = 0;

    // Streaming parse
    let rowCount = 0;
    window.Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      step: (results: any) => {
        const data = results.data;
        const safeNumber = parseInt(data.number) || rowCount + 1;
        
        // Only add if it looks like a valid row
        if (data.number || data.npm_url) {
            const name = data.package_name || cleanPackageName(data.npm_url);
            
            if (!packageMapRef.current.has(name)) {
                const newIndex = masterRowsRef.current.length;
                packageMapRef.current.set(name, newIndex);
                
                const newRow: PackageRow = {
                  id: crypto.randomUUID(),
                  number: safeNumber,
                  npm_url: data.npm_url || '',
                  author_name: data.author_name || '',
                  package_name: name,
                  file_number: parseInt(data.file_number) || 0,
                  unpacked_size: parseInt(data.unpacked_size) || 0,
                  dependencies: parseInt(data.dependencies) || 0,
                  dependents: parseInt(data.dependents) || 0,
                  latest_release_published_at: data.latest_release_published_at || '',
                  description: data.description || '',
                  keywords: data.keywords || '',
                  license: data.license || '',
                  is_esm: data.is_esm === 'true',
                  _status: (parseInt(data.unpacked_size) > 0 && data.latest_release_published_at) ? 'enriched' : 'idle',
                };
                
                masterRowsRef.current.push(newRow);
                rowCount++;
            }
        }
      },
      complete: () => {
        // Initial stats
        updateStats();
        applyFiltersAndSort();
      }
    });
  };

  const handlePackagesFound = (pkgs: PackageInfo[]) => {
      // Push to buffer for main thread processing
      incomingRowsBufferRef.current.push(...pkgs);
  };

  const handleFetcherComplete = (endSeq: string, count: number, elapsedMs: number) => {
      // Save the new sequence
      localStorage.setItem('npm_last_seq', endSeq);
      setLastSequence(endSeq);
      
      // Close fetcher
      setShowFetcher(false);

      // Format time
      const seconds = Math.floor(elapsedMs / 1000);
      const m = Math.floor(seconds / 60);
      const s = seconds % 60;
      const timeStr = `${m}m ${s}s`;

      // Show Success Dialog with detailed stats
      setShowSuccessDialog({
          count: fetchSessionStatsRef.current.added,
          updated: fetchSessionStatsRef.current.updated,
          time: timeStr,
          seq: endSeq
      });
  };
  
  const handleOpenFetcher = () => {
      fetchSessionStatsRef.current = { added: 0, updated: 0 };
      setShowFetcher(true);
  };

  const updateStats = () => {
    const total = masterRowsRef.current.length;
    let enriched = 0;
    let failed = 0;
    let totalSize = 0;
    
    // Use a simple loop for speed over .filter().length
    for (let i = 0; i < total; i++) {
        const r = masterRowsRef.current[i];
        if (r._status === 'enriched') enriched++;
        else if (r._status === 'error') failed++;
        totalSize += (r.unpacked_size || 0);
    }
    
    setStats({ total, enriched, failed, totalSize });
  };

  // Queue Processing Loop
  const processQueue = useCallback(async () => {
    if (!isEnrichingRef.current) return;

    // If queue is empty, refill it with idle rows
    if (enrichmentQueueRef.current.length === 0) {
       const candidates = [];
       const len = masterRowsRef.current.length;
       // Scan for idle rows to process
       for(let i=0; i<len; i++) {
         if (masterRowsRef.current[i]._status === 'idle') {
           candidates.push(i);
           if (candidates.length >= 2000) break; // Refill chunk size limit
         }
       }
       
       if (candidates.length === 0) {
         setIsEnriching(false);
         isEnrichingRef.current = false;
         alert("Enrichment complete or no more candidates found.");
         return;
       }
       enrichmentQueueRef.current = candidates;
    }

    // Fill concurrency slots based on dynamic worker limit
    while (activeRequestsRef.current < workerLimitRef.current && enrichmentQueueRef.current.length > 0 && isEnrichingRef.current) {
      const rowIndex = enrichmentQueueRef.current.shift();
      if (rowIndex === undefined) break;

      const row = masterRowsRef.current[rowIndex];
      // Double check status in case it changed
      if (!row || row._status !== 'idle') continue;

      // Mark as pending immediately so other workers don't pick it up
      // Note: We modify object directly here, UI updates in next batch
      row._status = 'pending';
      activeRequestsRef.current++;

      enrichPackage(row)
        .then(updates => {
          // Push to buffer instead of setting state directly
          updatesBufferRef.current.push({
              index: rowIndex,
              data: { ...updates, _status: 'enriched' }
          });
        })
        .catch(err => {
          updatesBufferRef.current.push({
              index: rowIndex,
              data: { _status: 'error', _error: err.message }
          });
        })
        .finally(() => {
          activeRequestsRef.current--;
          // Recursively call processQueue to keep the workers saturated
          // This happens on microtask queue, so it's non-blocking
          processQueue();
        });
    }
  }, []);

  const toggleEnrichment = () => {
    const nextState = !isEnriching;
    setIsEnriching(nextState);
    isEnrichingRef.current = nextState;
    if (nextState) {
      processQueue();
    }
  };

  const applyFiltersAndSort = useCallback(() => {
    let result = masterRowsRef.current;
    
    // Filter Failed
    if (filter.hideFailed) {
      result = result.filter(r => r._status !== 'error');
    }

    // Filtering
    if (filter.search) {
      const term = filter.search.toLowerCase();
      result = result.filter(r => 
        (r.package_name && r.package_name.toLowerCase().includes(term)) ||
        (r.keywords && r.keywords.toLowerCase().includes(term)) || 
        (r.description && r.description.toLowerCase().includes(term)) ||
        (r.author_name && r.author_name.toLowerCase().includes(term))
      );
    }

    if (filter.minSizeMB > 0) {
      const minSizeBytes = filter.minSizeMB * 1024 * 1024;
      result = result.filter(r => r.unpacked_size >= minSizeBytes);
    }

    if (filter.minFiles > 0) {
      result = result.filter(r => r.file_number >= filter.minFiles);
    }

    if (filter.minDate) {
      const minTime = new Date(filter.minDate).getTime();
      result = result.filter(r => {
        if (!r.latest_release_published_at) return false;
        return new Date(r.latest_release_published_at).getTime() >= minTime;
      });
    }

    // Sorting
    result.sort((a, b) => {
      let valA: any = a[sortField];
      let valB: any = b[sortField];

      // Handle numeric defaults
      if (sortField === SortField.SIZE || sortField === SortField.FILES || sortField === SortField.NUMBER || sortField === SortField.INSTALL_SIZE) {
        valA = valA || 0;
        valB = valB || 0;
      }

      // Handle date defaults
      if (sortField === SortField.DATE) {
        valA = valA ? new Date(valA).getTime() : 0;
        valB = valB ? new Date(valB).getTime() : 0;
      }

      if (valA < valB) return sortOrder === SortOrder.ASC ? -1 : 1;
      if (valA > valB) return sortOrder === SortOrder.ASC ? 1 : -1;
      return 0;
    });

    setDisplayRows([...result]);
  }, [filter, sortField, sortOrder]);

  // Trigger filter/sort when dependencies change
  useEffect(() => {
    if (masterRowsRef.current.length > 0) {
      applyFiltersAndSort();
    }
  }, [filter, sortField, sortOrder, dataVersion, applyFiltersAndSort]);

  const handleExport = () => {
    if (!window.Papa) return;
    try {
        // Sanitize data for CSV
        const exportData = displayRows.map(row => ({
            number: row.number,
            package_name: row.package_name,
            version: row.version || '',
            description: row.description ? row.description.replace(/(\r\n|\n|\r)/gm, " ") : '',
            author_name: row.author_name,
            maintainers: row.maintainers ? row.maintainers.join('; ') : '',
            unpacked_size: row.unpacked_size,
            install_size: row.install_size, 
            file_number: row.file_number,
            dependencies: row.dependencies,
            dependencies_list: row.dependencies_list ? row.dependencies_list.join('; ') : '',
            dependents: row.dependents,
            latest_release_published_at: row.latest_release_published_at,
            license: row.license,
            npm_url: row.npm_url,
            repository_url: row.repository_url || '',
            keywords: row.keywords,
            is_esm: row.is_esm,
            status: row._status,
            error: row._error || ''
        }));

        const csv = window.Papa.unparse(exportData);
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', `npm_enriched_${new Date().toISOString().slice(0,10)}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    } catch (e) {
        console.error("Export failed:", e);
        alert("Export failed. Check console for details.");
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gray-950 text-gray-100 font-sans selection:bg-blue-500 selection:text-white">
      
      {/* Top Bar: Logo & Stats */}
      <div className="bg-gray-900/90 backdrop-blur border-b border-gray-800 p-4 flex items-center justify-between shadow-lg z-30 relative">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-red-500 via-pink-600 to-purple-600 rounded-lg flex items-center justify-center shadow-[0_0_20px_rgba(220,38,38,0.4)] ring-1 ring-white/10">
            <span className="font-bold text-white text-xl">N</span>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white">NPM Enricher <span className="text-xs text-blue-400 font-mono ml-2 border border-blue-900/50 bg-blue-900/20 px-1 rounded">v3.0 PRO</span></h1>
            <p className="text-xs text-gray-500 tracking-wide">HYPER-SCALE METADATA ENGINE</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
            {/* Upsync Button (Visible when data exists) */}
            {masterRowsRef.current.length > 0 && (
                <button 
                    onClick={handleOpenFetcher}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold uppercase tracking-wider py-1.5 px-3 rounded border border-indigo-400/30 shadow-[0_0_10px_rgba(79,70,229,0.3)] transition-all flex items-center gap-2"
                    title={`Last Sequence: ${lastSequence}`}
                >
                    <svg className="w-4 h-4 animate-[spin_10s_linear_infinite]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                    Upsync New
                </button>
            )}

            {/* Worker Limit Control */}
            <div className="flex items-center gap-2 text-sm bg-gray-800/50 p-1.5 rounded border border-gray-700">
                <span className="text-gray-400 font-semibold uppercase text-[10px] tracking-wider px-1">Concurrency</span>
                <input 
                    type="number" 
                    min="1" 
                    max="500" 
                    value={workerLimit} 
                    onChange={(e) => setWorkerLimit(Number(e.target.value))}
                    className="bg-gray-950 border border-gray-600 rounded w-16 px-2 py-1 text-center text-cyan-400 font-mono focus:ring-1 focus:ring-cyan-500 outline-none text-xs"
                />
            </div>
        </div>

        {masterRowsRef.current.length === 0 && (
           <div className="flex-1 max-w-xl mx-8 flex gap-4">
             {/* Fetch Button */}
             <button 
                onClick={handleOpenFetcher}
                className="flex-1 flex flex-col items-center justify-center h-16 border-2 border-gray-700 border-dashed rounded-lg cursor-pointer bg-gray-800/40 hover:bg-gray-800/60 hover:border-indigo-500 transition-all group"
             >
                 <div className="flex items-center gap-2 group-hover:scale-105 transition-transform">
                    <svg className="w-6 h-6 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
                    <span className="font-semibold text-indigo-100">Fetch Registry</span>
                 </div>
                 <span className="text-[10px] text-gray-500 mt-1">Resume from seq: {lastSequence.slice(0,6)}...</span>
             </button>

             {/* Upload Button */}
             <label className="flex-1 flex flex-col items-center justify-center h-16 border-2 border-gray-700 border-dashed rounded-lg cursor-pointer bg-gray-800/40 hover:bg-gray-800/60 hover:border-gray-500 transition-all group">
                <div className="flex items-center gap-2 group-hover:scale-105 transition-transform">
                    <svg className="w-6 h-6 text-gray-400 group-hover:text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                    <span className="font-semibold text-gray-300">Upload CSV</span>
                </div>
                <input type="file" accept=".csv" className="hidden" onChange={handleFileUpload} />
            </label>
           </div>
        )}
      </div>

      {/* Stats Control Bar */}
      {masterRowsRef.current.length > 0 && (
        <StatsBar 
          stats={stats} 
          isEnriching={isEnriching} 
          onToggleEnrich={toggleEnrichment} 
          onExport={handleExport}
          onClear={() => {
            masterRowsRef.current = [];
            packageMapRef.current.clear();
            setDisplayRows([]);
            setStats({ total: 0, enriched: 0, failed: 0, totalSize: 0 });
          }}
          queueSize={enrichmentQueueRef.current.length}
        />
      )}

      {/* Filter Bar */}
      {masterRowsRef.current.length > 0 && (
        <div className="bg-gray-900/80 border-b border-gray-800 p-3 flex flex-wrap items-center gap-4 text-sm backdrop-blur z-20">
          
          {/* Search */}
          <div className="relative group">
             <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <svg className="w-4 h-4 text-gray-500 group-focus-within:text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
             </div>
             <input 
                type="text" 
                placeholder="SEARCH..." 
                className="bg-gray-950/50 border border-gray-700 text-gray-300 text-sm rounded-md focus:ring-blue-500 focus:border-blue-500 block w-64 pl-10 p-1.5 placeholder-gray-600 font-mono focus:bg-gray-900 transition-colors uppercase placeholder:normal-case"
                value={filter.search}
                onChange={(e) => setFilter(prev => ({ ...prev, search: e.target.value }))}
             />
          </div>

          <div className="h-6 w-px bg-gray-800 mx-1"></div>

          {/* Size Filter */}
          <div className="flex items-center gap-2 text-gray-400">
            <span className="text-[10px] uppercase font-bold tracking-wider text-gray-500">Min Size</span>
            <div className="relative">
                <input 
                type="number" 
                className="bg-gray-950/50 border border-gray-700 text-gray-300 text-sm rounded-md w-20 p-1.5 pr-8 font-mono text-right"
                placeholder="0"
                min="0"
                value={filter.minSizeMB || ''}
                onChange={(e) => setFilter(prev => ({ ...prev, minSizeMB: parseFloat(e.target.value) || 0 }))}
                />
                <span className="absolute right-2 top-1.5 text-gray-600 text-xs font-bold">MB</span>
            </div>
          </div>

          {/* Files Filter */}
          <div className="flex items-center gap-2 text-gray-400">
            <span className="text-[10px] uppercase font-bold tracking-wider text-gray-500">Min Files</span>
            <input 
               type="number" 
               className="bg-gray-950/50 border border-gray-700 text-gray-300 text-sm rounded-md w-20 p-1.5 font-mono text-right"
               placeholder="0"
               min="0"
               value={filter.minFiles || ''}
               onChange={(e) => setFilter(prev => ({ ...prev, minFiles: parseInt(e.target.value) || 0 }))}
            />
          </div>

          {/* Date Filter */}
          <div className="flex items-center gap-2 text-gray-400">
            <span className="text-[10px] uppercase font-bold tracking-wider text-gray-500">Since</span>
            <input 
               type="date" 
               className="bg-gray-950/50 border border-gray-700 text-gray-300 text-sm rounded-md p-1.5 [color-scheme:dark]"
               value={filter.minDate}
               onChange={(e) => setFilter(prev => ({ ...prev, minDate: e.target.value }))}
            />
          </div>

          <div className="h-6 w-px bg-gray-800 mx-1"></div>

          {/* Hide Failed Checkbox */}
          <label className="flex items-center gap-2 text-gray-400 cursor-pointer hover:text-white transition-colors select-none">
            <input 
              type="checkbox"
              className="w-4 h-4 rounded bg-gray-950 border-gray-700 text-blue-600 focus:ring-blue-500 focus:ring-offset-gray-900 accent-blue-600"
              checked={filter.hideFailed}
              onChange={(e) => setFilter(prev => ({ ...prev, hideFailed: e.target.checked }))}
            />
            <span className="text-[10px] uppercase font-bold tracking-wider">Hide Errors</span>
          </label>
           
           <div className="flex-1 text-right text-xs text-gray-600 font-mono">
             {displayRows.length.toLocaleString()} / {stats.total.toLocaleString()} ROWS
           </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 p-4 overflow-hidden relative bg-[#030508]">
        {masterRowsRef.current.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-gray-600">
             <div className="w-32 h-32 bg-gray-900/50 rounded-full flex items-center justify-center mb-6 border border-gray-800 shadow-[0_0_60px_-10px_rgba(0,0,0,0.5)] relative">
                <div className="absolute inset-0 rounded-full bg-blue-500/5 animate-pulse"></div>
                <svg className="w-12 h-12 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" /></svg>
             </div>
             <p className="text-xl font-light tracking-tight text-gray-400">System Idle</p>
             <p className="text-sm mt-2 max-w-md text-center text-gray-600">Upload a CSV payload or Fetch from Registry to initialize protocols.</p>
          </div>
        ) : (
          <VirtualTable 
            rows={displayRows} 
            sortField={sortField}
            sortOrder={sortOrder}
            onSort={(field) => {
              if (field === sortField) {
                setSortOrder(prev => prev === SortOrder.ASC ? SortOrder.DESC : SortOrder.ASC);
              } else {
                setSortField(field);
                setSortOrder(SortOrder.ASC);
              }
            }}
            onPackageClick={setSelectedProject}
            onAuthorClick={(name) => setSelectedAuthor(name)}
            onDepsClick={(row) => setSelectedDepsPkg(row.package_name)}
          />
        )}
      </div>
      
      {/* Dialogs */}
      {showFetcher && (
          <RegistryFetcherDialog 
            initialStartSequence={lastSequence}
            onClose={() => setShowFetcher(false)} 
            onPackagesFound={handlePackagesFound} 
            onComplete={handleFetcherComplete}
          />
      )}
      
      {showSuccessDialog && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in zoom-in duration-200">
              <div className="bg-gray-900 border border-emerald-500/30 rounded-xl p-6 shadow-[0_0_50px_-12px_rgba(16,185,129,0.5)] max-w-md w-full text-center ring-1 ring-white/10 relative overflow-hidden">
                   {/* Background Glow */}
                   <div className="absolute -top-24 -left-24 w-48 h-48 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none"></div>
                   
                   <div className="w-16 h-16 bg-emerald-900/30 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-500/50">
                       <svg className="w-8 h-8 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                   </div>
                   
                   <h2 className="text-2xl font-bold text-white mb-2">Indexing Complete</h2>
                   <p className="text-gray-400 text-sm mb-6">Registry traversal finished. The database has been synchronized.</p>
                   
                   <div className="grid grid-cols-2 gap-4 mb-6">
                       <div className="bg-gray-800/50 p-3 rounded border border-gray-700">
                           <span className="block text-xs text-gray-500 uppercase font-bold">New Added</span>
                           <span className="text-xl text-emerald-400 font-mono font-bold">{showSuccessDialog.count.toLocaleString()}</span>
                       </div>
                       <div className="bg-gray-800/50 p-3 rounded border border-gray-700">
                           <span className="block text-xs text-gray-500 uppercase font-bold">Updated</span>
                           <span className="text-xl text-amber-400 font-mono font-bold">{showSuccessDialog.updated.toLocaleString()}</span>
                       </div>
                   </div>
                   
                   <div className="flex justify-between items-center bg-black/30 p-2 rounded border border-gray-800 text-xs font-mono text-gray-500 mb-6">
                       <span>Duration: {showSuccessDialog.time}</span>
                       <span>Seq: {showSuccessDialog.seq.slice(0, 10)}...</span>
                   </div>

                   <button 
                        onClick={() => setShowSuccessDialog(null)}
                        className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-bold transition-colors shadow-lg shadow-emerald-900/20"
                   >
                       Proceed to Enrichment
                   </button>
              </div>
          </div>
      )}

      {selectedProject && (
        <ProjectDialog 
          row={selectedProject} 
          onClose={() => setSelectedProject(null)} 
          onCollaboratorClick={setSelectedAuthor}
          onDependenciesClick={setSelectedDepsPkg}
          onDependentsClick={setSelectedDependentsPkg}
          onChat={(context) => setChatContext(context)}
        />
      )}

      {chatContext && (
          <ChatDialog 
            context={chatContext}
            onClose={() => setChatContext(null)}
          />
      )}

      {selectedAuthor && (
        <AuthorDialog 
          authorName={selectedAuthor} 
          rows={masterRowsRef.current}
          onClose={() => setSelectedAuthor(null)} 
        />
      )}

      {selectedDepsPkg && (
        <DependenciesDialog 
          packageName={selectedDepsPkg} 
          onClose={() => setSelectedDepsPkg(null)} 
        />
      )}

      {selectedDependentsPkg && (
        <DependentsDialog 
          packageName={selectedDependentsPkg}
          rows={masterRowsRef.current}
          onClose={() => setSelectedDependentsPkg(null)}
          onPackageClick={(row) => {
            setSelectedDependentsPkg(null);
            setSelectedProject(row);
          }}
        />
      )}
    </div>
  );
}
