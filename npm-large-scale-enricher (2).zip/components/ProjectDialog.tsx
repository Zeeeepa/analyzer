
import React, { useEffect, useState, useMemo, useRef, useCallback } from 'react';
import { PackageRow } from '../types';
import { fetchPackageFiles, fetchFileContent, analyzeExports, analyzeDependencyGraph, analyzePackageStructure } from '../services/npmService';

interface ProjectDialogProps {
  row: PackageRow;
  onClose: () => void;
  onCollaboratorClick: (name: string) => void;
  onDependenciesClick: (pkgName: string) => void;
  onDependentsClick: (pkgName: string) => void;
  onChat: (context: {project: PackageRow, tree?: string, activeFile?: string, activeCode?: string}) => void;
}

interface SymbolData {
  type: 'class' | 'func' | 'var' | 'interface' | 'method' | 'type' | 'namespace';
  name: string;
  line: number;
  args?: string; // e.g., "req, res"
  usage?: string[]; // detected calls to other symbols
}

interface TreeNode {
  name: string;
  path: string;
  children?: TreeNode[];
  type: 'file' | 'folder';
  size?: number;
  isEntrypoint?: boolean;
}

interface ScanResult {
  exports: any;
  structure: any;
  dependencyGraph: any;
}

const Prism = (window as any).Prism;

const buildTree = (files: { name: string; size: number }[], entrypoints: string[] = []) => {
  const root: TreeNode = { name: 'root', path: '', type: 'folder', children: [] };
  
  files.forEach(file => {
    // Normalize file path for matching entrypoints
    const normalizedPath = file.name.startsWith('/') ? file.name.slice(1) : file.name;
    const isEntry = entrypoints.includes(normalizedPath);
    
    const parts = file.name.split('/').filter(Boolean);
    let current = root;
    
    parts.forEach((part, index) => {
      const isFile = index === parts.length - 1;
      let node = current.children?.find(c => c.name === part);
      
      if (!node) {
        node = {
          name: part,
          path: file.name,
          type: isFile ? 'file' : 'folder',
          children: isFile ? undefined : [],
          size: isFile ? file.size : undefined,
          isEntrypoint: isFile ? isEntry : false
        };
        current.children?.push(node);
      }
      current = node;
    });
  });
  
  const sortNodes = (nodes: TreeNode[]) => {
    nodes.sort((a, b) => {
      if (a.type === b.type) return a.name.localeCompare(b.name);
      return a.type === 'folder' ? -1 : 1;
    });
    nodes.forEach(n => {
      if (n.children) sortNodes(n.children);
    });
  };
  
  if (root.children) sortNodes(root.children);
  return root.children || [];
};

const findBodyEnd = (lines: string[], startLineIndex: number): number => {
  let braceCount = 0;
  let foundStart = false;
  
  for (let i = startLineIndex; i < lines.length; i++) {
    const line = lines[i];
    const open = (line.match(/{/g) || []).length;
    const close = (line.match(/}/g) || []).length;
    
    if (open > 0) foundStart = true;
    braceCount += open - close;
    
    if (foundStart && braceCount <= 0) return i;
    if (i - startLineIndex > 500) return i; 
  }
  return lines.length - 1;
};

const extractSymbols = (code: string, isDeclarationFile: boolean = false): SymbolData[] => {
  const symbols: SymbolData[] = [];
  const lines = code.split('\n');
  const allDefinedNames = new Set<string>();
  
  lines.forEach((line, i) => {
      const lineNum = i + 1;
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('//') || trimmed.startsWith('*')) return;

      // Support 'export declare const', 'declare const', 'export const', 'const'
      const declPrefix = isDeclarationFile ? '(?:export\\s+)?(?:declare\\s+)?' : '(?:export\\s+)?';

      // 1. Class
      const classMatch = trimmed.match(new RegExp(`^${declPrefix}(?:abstract\\s+)?class\\s+([A-Z][a-zA-Z0-9_$]*)`));
      if (classMatch) {
          const name = classMatch[1];
          allDefinedNames.add(name);
          symbols.push({ type: 'class', name, line: lineNum });
          return;
      }

      // 2. Function
      const funcMatch = trimmed.match(new RegExp(`^${declPrefix}(?:async\\s+)?function\\s+([a-zA-Z0-9_$]+)\\s*\\(([^)]*)\\)`));
      if (funcMatch) {
          const name = funcMatch[1];
          const args = funcMatch[2].trim();
          allDefinedNames.add(name);
          symbols.push({ type: 'func', name, line: lineNum, args });
          return;
      }

      // 3. Variable / Arrow Func
      const varMatch = trimmed.match(new RegExp(`^${declPrefix}(?:const|let|var)\\s+([a-zA-Z0-9_$]+)\\s*=\\s*(?:async\\s*)?(\\([^)]*\\)|[a-zA-Z0-9_$]+)\\s*=>`));
      if (varMatch) {
           const name = varMatch[1];
           let args = varMatch[2].trim();
           if (args.startsWith('(') && args.endsWith(')')) args = args.slice(1, -1);
           allDefinedNames.add(name);
           symbols.push({ type: 'func', name, line: lineNum, args });
           return;
      }

      // Destructuring
      const destructMatch = trimmed.match(new RegExp(`^${declPrefix}(?:const|let|var)\\s+\\{([^}]+)\\}\\s*=`));
      if (destructMatch) {
          const vars = destructMatch[1].split(',').map(v => v.trim().split(':')[0].trim());
          vars.forEach(v => {
              if (v) {
                  allDefinedNames.add(v);
                  symbols.push({ type: 'var', name: v, line: lineNum });
              }
          });
          return;
      }

      // Simple Variable
      // Modified to handle 'declare const X: Type;'
      const simpleVar = trimmed.match(new RegExp(`^${declPrefix}(?:const|let|var)\\s+([a-zA-Z0-9_$]+)(?:\\s*[:=])`));
      if (simpleVar && !varMatch) {
           const name = simpleVar[1];
           allDefinedNames.add(name);
           symbols.push({ type: 'var', name, line: lineNum });
           return;
      }

      // 4. Types / Interfaces (TS)
      const typeMatch = trimmed.match(new RegExp(`^${declPrefix}(?:type|interface)\\s+([A-Z][a-zA-Z0-9_$]*)`));
      if (typeMatch) {
          symbols.push({ type: trimmed.includes('interface') ? 'interface' : 'type', name: typeMatch[1], line: lineNum });
          return;
      }

      // 5. Namespace / Module (d.ts)
      const nsMatch = trimmed.match(new RegExp(`^${declPrefix}(?:namespace|module)\\s+([a-zA-Z0-9_$.]+)`));
      if (nsMatch) {
          symbols.push({ type: 'namespace', name: nsMatch[1], line: lineNum });
          return;
      }

      // 6. Method
      if (!isDeclarationFile && !/^(if|for|while|switch|catch|return|throw|try|finally|else|console|module|import|from)\b/.test(trimmed)) {
           const methodMatch = trimmed.match(/^(?:static\s+|async\s+|get\s+|set\s+)*([a-zA-Z0-9_$]+)\s*(?:<[^>]*>)?\s*\(([^)]*)\)/);
           if (methodMatch) {
               const name = methodMatch[1];
               if (name !== 'function' && name.length > 1) {
                   symbols.push({ type: 'method', name, line: lineNum, args: methodMatch[2].trim() });
               }
           }
      }
  });

  // Pass 2: Dependencies (skip for d.ts generally as it's just decls)
  if (!isDeclarationFile) {
      symbols.forEach((sym, idx) => {
        if (sym.type === 'func' || sym.type === 'method') {
            const startLine = sym.line - 1;
            const endLine = findBodyEnd(lines, startLine);
            const bodyText = lines.slice(startLine, endLine + 1).join('\n');
            
            const used: Set<string> = new Set();
            allDefinedNames.forEach(definedName => {
                if (definedName === sym.name) return; 
                const regex = new RegExp(`(?<![.\\w])\\b${definedName}\\b(?!\\s*:)`);
                if (regex.test(bodyText)) {
                    used.add(definedName);
                }
            });
            
            if (used.size > 0) {
                sym.usage = Array.from(used);
            }
        }
      });
  }
  
  return symbols;
};

const TreeItem = ({ node, level, onSelect, expandedPaths, togglePath, onScrollToLine, symbolsMap }: any) => {
  const isExpanded = expandedPaths.has(node.path || node.name);
  const isJs = /\.(js|ts|jsx|tsx|mjs|cjs|vue|svelte|java|py|go|rb)$/.test(node.name);
  const isDts = node.name.endsWith('.d.ts');
  
  const nodeSymbols = node.type === 'file' ? symbolsMap[node.path] : undefined;

  const handleExpand = async (e: React.MouseEvent) => {
    e.stopPropagation();
    togglePath(node.path || node.name, node.type);
  };

  return (
    <div>
      <div 
        className="flex items-center gap-2 py-1 px-2 hover:bg-gray-800 cursor-pointer text-sm select-none truncate group transition-colors relative"
        style={{ paddingLeft: `${level * 12 + 8}px` }}
        onClick={() => {
          if (node.type === 'file') onSelect(node);
          else togglePath(node.path || node.name, 'folder');
        }}
      >
        <span 
            onClick={handleExpand}
            className={`text-gray-500 w-4 flex-none text-center hover:text-white z-10 ${node.type === 'file' && (isJs || isDts) ? 'cursor-pointer font-bold text-blue-400' : ''}`}
        >
          {node.type === 'folder' 
            ? (isExpanded ? '📂' : '📁') 
            : ((isJs || isDts) ? (isExpanded ? '−' : '+') : '📄')}
        </span>
        
        <span className={`${node.type === 'file' ? (isDts ? 'text-yellow-200/80 group-hover:text-yellow-100' : 'text-gray-300 group-hover:text-white') : 'text-blue-300 font-medium group-hover:text-blue-200'} flex items-center gap-2`}>
          {node.name}
          {node.isEntrypoint && (
             <span className="text-[10px] bg-red-900/50 text-red-200 px-1 rounded border border-red-800/50" title="Entrypoint">🚀</span>
          )}
        </span>
        {node.size && <span className="ml-auto text-xs text-gray-600 group-hover:text-gray-400 font-mono mr-2">{Math.round(node.size / 1024)}KB</span>}
      </div>

      {isExpanded && (
         <>
            {nodeSymbols && nodeSymbols.length > 0 && (
                <div className="border-l border-gray-700 ml-4 pl-2 my-1 animate-in slide-in-from-top-1 duration-150">
                    {nodeSymbols.map((s: SymbolData, i: number) => (
                        <div 
                            key={i} 
                            onClick={(e) => {
                                e.stopPropagation();
                                onSelect(node);
                                setTimeout(() => onScrollToLine(s.line), 50); 
                            }}
                            className="text-xs text-gray-500 py-0.5 pl-6 hover:text-cyan-400 hover:bg-white/5 cursor-pointer transition-colors group/sym relative"
                        >
                            <div className="flex items-center gap-2">
                                <span className={`w-1.5 h-1.5 rounded-sm flex-none 
                                    ${s.type === 'class' ? 'bg-yellow-500 shadow-[0_0_5px_rgba(234,179,8,0.5)]' : 
                                    s.type === 'func' ? 'bg-purple-500 shadow-[0_0_5px_rgba(168,85,247,0.5)]' : 
                                    s.type === 'interface' || s.type === 'type' ? 'bg-green-500' :
                                    s.type === 'namespace' ? 'bg-pink-500' :
                                    s.type === 'var' ? 'bg-orange-400' :
                                    'bg-blue-400'}`}>
                                </span>
                                <span className="font-mono truncate group-hover/sym:text-gray-300">
                                    {s.name}
                                    {s.type === 'func' || s.type === 'method' ? (
                                        <span className="text-gray-600 group-hover/sym:text-gray-400">({s.args})</span>
                                    ) : ''}
                                </span>
                            </div>
                            
                            {/* Usage Context */}
                            {s.usage && s.usage.length > 0 && (
                                <div className="pl-4 text-[10px] text-gray-600 font-mono mt-0.5 truncate">
                                    ↳ Uses: {s.usage.join(', ')}
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            )}
            
            {node.children && (
                <div>
                {node.children.map((child: any) => (
                    <TreeItem 
                    key={child.name + child.path} 
                    node={child} 
                    level={level + 1} 
                    onSelect={onSelect} 
                    expandedPaths={expandedPaths} 
                    togglePath={togglePath}
                    onScrollToLine={onScrollToLine}
                    symbolsMap={symbolsMap}
                    />
                ))}
                </div>
            )}
         </>
      )}
    </div>
  );
};

export const ProjectDialog: React.FC<ProjectDialogProps> = ({ row, onClose, onCollaboratorClick, onDependenciesClick, onDependentsClick, onChat }) => {
  const [files, setFiles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [viewMode, setViewMode] = useState<'tree' | 'flat' | 'stats'>('tree');
  const [expandedPaths, setExpandedPaths] = useState<Set<string>>(new Set());
  
  const [selectedFile, setSelectedFile] = useState<{path: string, name: string} | null>(null);
  const [fileContent, setFileContent] = useState<string>('');
  const [contentLoading, setContentLoading] = useState(false);
  
  const [symbolsMap, setSymbolsMap] = useState<Record<string, SymbolData[]>>({});
  
  // Scan State
  const [scanning, setScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);

  // Sidebar Resizing
  const [sidebarWidth, setSidebarWidth] = useState(320);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const [isResizing, setIsResizing] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);
  const [copyFileSuccess, setCopyFileSuccess] = useState(false);

  const maintainers = row.maintainers && row.maintainers.length > 0 ? row.maintainers : [row.author_name];

  const startResizing = useCallback(() => setIsResizing(true), []);
  const stopResizing = useCallback(() => setIsResizing(false), []);
  
  const resize = useCallback((mouseMoveEvent: MouseEvent) => {
      if (isResizing && sidebarRef.current) {
          const newWidth = mouseMoveEvent.clientX - sidebarRef.current.getBoundingClientRect().left;
          if (newWidth > 200 && newWidth < 800) {
              setSidebarWidth(newWidth);
          }
      }
  }, [isResizing]);

  useEffect(() => {
      window.addEventListener('mousemove', resize);
      window.addEventListener('mouseup', stopResizing);
      return () => {
          window.removeEventListener('mousemove', resize);
          window.removeEventListener('mouseup', stopResizing);
      };
  }, [resize, stopResizing]);

  useEffect(() => {
    const loadFiles = async () => {
      try {
        const list = await fetchPackageFiles(row.package_name, row.version || 'latest');
        setFiles(list);
      } catch (e) {
        setError('Failed to load file structure.');
      } finally {
        setLoading(false);
      }
    };
    loadFiles();
  }, [row]);

  const treeStructure = useMemo(() => buildTree(files, row.entrypoints), [files, row.entrypoints]);

  const togglePath = async (path: string, type: 'file' | 'folder') => {
    const isExpanding = !expandedPaths.has(path);

    setExpandedPaths(prev => {
        const next = new Set(prev);
        if (next.has(path)) next.delete(path);
        else next.add(path);
        return next;
    });

    if (isExpanding && type === 'file' && !symbolsMap[path]) {
         try {
             const text = await fetchFileContent(row.package_name, row.version!, path);
             const symbols = extractSymbols(text, path.endsWith('.d.ts'));
             setSymbolsMap(prev => ({ ...prev, [path]: symbols }));
        } catch (err) { console.error('Lazy load failed', err); }
    }
  };

  useEffect(() => {
    if (selectedFile && row.version) {
      setContentLoading(true);
      const loadContent = async () => {
        try {
          const text = await fetchFileContent(row.package_name, row.version!, selectedFile.path);
          setFileContent(text);
          
          if (/\.(js|ts|jsx|tsx|mjs|cjs|vue|svelte|java|py|go)$/.test(selectedFile.name) || selectedFile.name.endsWith('.d.ts')) {
              const symbols = extractSymbols(text, selectedFile.name.endsWith('.d.ts'));
              setSymbolsMap(prev => ({
                  ...prev,
                  [selectedFile.path]: symbols
              }));
              
              setExpandedPaths(prev => {
                  const next = new Set(prev);
                  next.add(selectedFile.path);
                  return next;
              });
          }

        } catch (e) {
          setFileContent('Failed to load file content.');
        } finally {
          setContentLoading(false);
        }
      };
      loadContent();
    } else {
        setFileContent(`# ${row.package_name}\n\n${row.description}\n\nSelect a file to view contents.`);
    }
  }, [selectedFile, row]);

  useEffect(() => {
    if (!contentLoading && fileContent && Prism) {
        setTimeout(() => Prism.highlightAll(), 50);
    }
  }, [fileContent, contentLoading]);

  const scanProject = async () => {
    if (scanning) return;
    setScanning(true);
    setScanProgress(0);
    
    const codeFiles = files.filter(f => /\.(js|ts|jsx|tsx|mjs|cjs|vue|svelte|java|py|rb|go|php)$/.test(f.name) || f.name.endsWith('.d.ts'));
    const CONCURRENCY = 10; 
    let completed = 0;
    
    const processFile = async (f: any) => {
        try {
            if (symbolsMap[f.name]) return;
            const text = await fetchFileContent(row.package_name, row.version!, f.name);
            const syms = extractSymbols(text, f.name.endsWith('.d.ts'));
            setSymbolsMap(prev => ({...prev, [f.name]: syms}));
            
            if (syms.length > 0) {
                 setExpandedPaths(prev => new Set(prev).add(f.name));
            }
        } catch (e) {
            console.error(`Failed to scan ${f.name}`, e);
        } finally {
            completed++;
            setScanProgress(Math.floor((completed / codeFiles.length) * 90));
        }
    };

    const queue = [...codeFiles];
    const workers = Array(Math.min(CONCURRENCY, queue.length)).fill(null).map(async () => {
        while (queue.length > 0) {
            const f = queue.shift();
            if (f) await processFile(f);
        }
    });

    await Promise.all(workers);

    // Run Advanced Analysis
    const [exportsData, structureData, dependencyData] = await Promise.all([
        analyzeExports(row.package_name, row.version!),
        analyzePackageStructure(row.package_name, row.version!),
        analyzeDependencyGraph(row.package_name)
    ]);

    setScanResult({
        exports: exportsData,
        structure: structureData,
        dependencyGraph: dependencyData
    });

    setScanning(false);
    setScanProgress(100);
    setViewMode('stats'); // Auto switch to stats after scan
  };

  const generateTreeText = (nodes: TreeNode[], depth: number = 0): string => {
    let text = '';
    const indent = '  '.repeat(depth);
    nodes.forEach(node => {
      if (node.type === 'folder') {
        text += `${indent}📂 ${node.name}/\n`;
        if (node.children) text += generateTreeText(node.children, depth + 1);
      } else {
        text += `${indent}📄 ${node.name}${node.isEntrypoint ? ' [ENTRY]' : ''}\n`;
        const syms = symbolsMap[node.path];
        if (syms && syms.length > 0) {
          syms.forEach(s => {
            const args = s.args ? `(${s.args})` : '';
            let line = `${indent}  └─ [${s.type.toUpperCase()}] ${s.name}${args} (L${s.line})`;
            if (s.usage && s.usage.length > 0) {
                line += `\n${indent}     ↳ Uses: ${s.usage.join(', ')}`;
            }
            text += line + '\n';
          });
        }
      }
    });
    return text;
  };

  const handleCopyTree = () => {
    const treeText = `PROJECT STRUCTURE & SYMBOL CONTEXT: ${row.package_name} v${row.version}\nScan Date: ${new Date().toISOString()}\n\n${generateTreeText(treeStructure)}`;
    navigator.clipboard.writeText(treeText);
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 2000);
  };

  const handleCopyFile = () => {
      if (!fileContent) return;
      navigator.clipboard.writeText(fileContent);
      setCopyFileSuccess(true);
      setTimeout(() => setCopyFileSuccess(false), 2000);
  };

  const handleChatClick = () => {
      const tree = generateTreeText(treeStructure);
      onChat({
          project: row,
          tree: tree,
          activeFile: selectedFile?.name,
          activeCode: fileContent
      });
  };

  const scrollToLine = (lineNumber: number) => {
      const container = document.getElementById('code-container');
      if (container) {
          const lineEl = container.querySelector(`.line-numbers-rows > span:nth-child(${lineNumber})`);
          if (lineEl) {
              lineEl.scrollIntoView({ block: 'center', behavior: 'smooth' });
          } else {
              container.scrollTo({ top: (lineNumber - 1) * 20, behavior: 'smooth' });
          }
      }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4">
      <div className="bg-[#05080f] w-full max-w-7xl h-[90vh] rounded-xl border border-gray-800/50 shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in duration-200 ring-1 ring-white/10">
        
        {/* Header */}
        <div className="bg-gray-900/80 backdrop-blur p-6 border-b border-gray-800 flex justify-between items-start relative z-20">
            <div className="flex flex-col gap-2 w-full">
                <div className="flex items-baseline gap-3">
                    <h2 className="text-3xl font-bold text-white tracking-tight">{row.package_name}</h2>
                    <span className="bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs px-2 py-0.5 rounded-full font-mono">{row.version || 'latest'}</span>
                    <a href={row.npm_url} target="_blank" rel="noreferrer" className="text-gray-500 hover:text-white text-xs underline flex items-center gap-1 transition-colors">
                        NPM Registry
                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
                    </a>
                    {row.repository_url && (
                        <a href={row.repository_url} target="_blank" rel="noreferrer" className="text-gray-500 hover:text-white text-xs underline flex items-center gap-1 transition-colors ml-2">
                             <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-1.334-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/></svg>
                             GitHub Repo
                        </a>
                    )}
                </div>
                
                <p className="text-gray-400 text-sm max-w-4xl leading-relaxed">{row.description}</p>
                
                <div className="grid grid-cols-2 gap-4 mt-2 text-sm text-gray-500 w-full max-w-4xl">
                    <div className="flex items-center gap-2">
                        <span className="font-semibold text-gray-600 uppercase text-xs tracking-wider">Collaborators:</span>
                        <div className="flex flex-wrap gap-2">
                            {maintainers.map((m, i) => (
                                <button 
                                    key={i} 
                                    onClick={() => onCollaboratorClick(m)}
                                    className="text-cyan-500 hover:text-cyan-300 hover:underline bg-cyan-950/30 border border-cyan-900/50 px-2 py-0.5 rounded text-xs transition-all"
                                >
                                    {m}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Stats Bar */}
                <div className="flex gap-8 mt-4 pt-4 border-t border-gray-800 w-full">
                     <button onClick={() => onDependenciesClick(row.package_name)} className="flex flex-col group">
                         <span className="text-[10px] text-gray-500 uppercase font-bold group-hover:text-cyan-400 transition-colors tracking-widest">Dependencies</span>
                         <span className="text-2xl font-bold text-white group-hover:text-cyan-400 transition-colors font-mono">{row.dependencies}</span>
                     </button>
                     <button onClick={() => onDependentsClick(row.package_name)} className="flex flex-col group">
                         <span className="text-[10px] text-gray-500 uppercase font-bold group-hover:text-cyan-400 transition-colors tracking-widest">Dependents</span>
                         <span className="text-2xl font-bold text-white group-hover:text-cyan-400 transition-colors font-mono">{row.dependents > 0 ? row.dependents : (row.dependencies_list ? 'Unknown' : '-')}</span>
                     </button>
                     <div className="flex flex-col">
                         <span className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Unpacked Size</span>
                         <span className="text-2xl font-bold text-white font-mono">{Math.round(row.unpacked_size / 1024)} <span className="text-sm font-normal text-gray-600">KB</span></span>
                     </div>
                     {row.install_size ? (
                        <div className="flex flex-col">
                             <span className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Install Size</span>
                             <span className="text-2xl font-bold text-orange-400 font-mono">{Math.round(row.install_size / 1024)} <span className="text-sm font-normal text-gray-600">KB</span></span>
                        </div>
                     ) : null}
                     <div className="flex flex-col">
                         <span className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Files</span>
                         <span className="text-2xl font-bold text-white font-mono">{row.file_number}</span>
                     </div>
                     <div className="flex flex-col ml-auto text-right">
                         <span className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Published</span>
                         <span className="text-xl text-gray-300 font-mono">{row.latest_release_published_at?.split('T')[0]}</span>
                     </div>
                </div>
            </div>

            <button onClick={onClose} className="text-gray-500 hover:text-white p-2 absolute top-4 right-4 transition-colors">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
        </div>

        {/* Body */}
        <div className="flex flex-1 overflow-hidden relative" ref={sidebarRef}>
            
            {/* Left: Resizable Sidebar */}
            <div 
                className="flex-none flex flex-col bg-gray-900/30"
                style={{ width: sidebarWidth }}
            >
                <div className="p-2 border-b border-gray-800 flex gap-2 flex-wrap">
                    <button 
                        onClick={() => setViewMode('tree')}
                        className={`flex-1 text-[10px] uppercase tracking-wider font-bold py-1.5 rounded border transition-colors ${viewMode === 'tree' ? 'bg-blue-900/30 border-blue-800 text-blue-300' : 'bg-gray-800/50 border-gray-700 text-gray-400 hover:text-gray-300'}`}
                    >
                        Struct
                    </button>
                    <button 
                        onClick={() => setViewMode('flat')}
                        className={`flex-1 text-[10px] uppercase tracking-wider font-bold py-1.5 rounded border transition-colors ${viewMode === 'flat' ? 'bg-blue-900/30 border-blue-800 text-blue-300' : 'bg-gray-800/50 border-gray-700 text-gray-400 hover:text-gray-300'}`}
                    >
                        Flat
                    </button>
                     {scanResult && (
                        <button 
                            onClick={() => setViewMode('stats')}
                            className={`flex-1 text-[10px] uppercase tracking-wider font-bold py-1.5 rounded border transition-colors ${viewMode === 'stats' ? 'bg-blue-900/30 border-blue-800 text-blue-300' : 'bg-gray-800/50 border-gray-700 text-gray-400 hover:text-gray-300'}`}
                        >
                            Stats
                        </button>
                     )}
                    
                    <div className="w-full flex gap-2 mt-1">
                        <button 
                            onClick={scanProject}
                            disabled={scanning}
                            className="flex-1 px-3 bg-cyan-900/30 hover:bg-cyan-800/50 text-[10px] uppercase tracking-wider font-bold text-cyan-300 py-1.5 rounded border border-cyan-800/50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                            title="Deep Scan: Fetch all code files, parse d.ts, analyze structure"
                        >
                            {scanning ? `${scanProgress}%` : 'Deep Scan'}
                        </button>

                        <button 
                            onClick={handleCopyTree}
                            className={`px-3 text-[10px] uppercase tracking-wider font-bold py-1.5 rounded border transition-colors flex items-center gap-1 ${copySuccess ? 'bg-green-900/50 border-green-700 text-green-400' : 'bg-gray-800/50 hover:bg-gray-700/50 border-gray-700 text-gray-300'}`}
                            title="Copy Full Symbol Tree Structure (Scan first for full details)"
                        >
                        {copySuccess ? 'Copied' : 'Copy'}
                        </button>
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto p-2 scrollbar-thin scrollbar-thumb-gray-700 relative">
                    {scanning && (
                        <div className="absolute top-0 left-0 right-0 h-1 bg-gray-800">
                            <div className="h-full bg-cyan-500 transition-all duration-300" style={{ width: `${scanProgress}%` }}></div>
                        </div>
                    )}

                    {loading ? (
                        <div className="flex justify-center p-4"><span className="animate-spin w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full"></span></div>
                    ) : error ? (
                        <div className="text-red-400 text-sm p-2">{error}</div>
                    ) : viewMode === 'stats' && scanResult ? (
                         <div className="space-y-4 p-2">
                            <div className="bg-gray-800/40 p-3 rounded border border-gray-700/50">
                                <h4 className="text-xs uppercase font-bold text-gray-400 mb-2">Structure Analysis</h4>
                                <div className="grid grid-cols-2 gap-2 text-xs">
                                    <div>
                                        <span className="text-gray-500 block">Languages</span>
                                        <span className="text-gray-300">{scanResult.structure.languages.join(', ') || '-'}</span>
                                    </div>
                                    <div>
                                        <span className="text-gray-500 block">Frameworks</span>
                                        <span className="text-gray-300">{scanResult.structure.frameworks.join(', ') || '-'}</span>
                                    </div>
                                    <div>
                                        <span className="text-gray-500 block">Tests</span>
                                        <span className={scanResult.structure.hasTests ? "text-green-400" : "text-gray-600"}>{scanResult.structure.hasTests ? 'Yes' : 'No'}</span>
                                    </div>
                                     <div>
                                        <span className="text-gray-500 block">Types</span>
                                        <span className={scanResult.structure.hasTypes ? "text-green-400" : "text-gray-600"}>{scanResult.structure.hasTypes ? 'Yes' : 'No'}</span>
                                    </div>
                                </div>
                            </div>

                            <div className="bg-gray-800/40 p-3 rounded border border-gray-700/50">
                                <h4 className="text-xs uppercase font-bold text-gray-400 mb-2">Exports</h4>
                                <div className="text-xs space-y-1">
                                    <div className="flex justify-between">
                                        <span className="text-gray-500">Format</span>
                                        <span className="text-cyan-300 font-mono">{scanResult.exports.moduleFormat.toUpperCase()}</span>
                                    </div>
                                    {Object.entries(scanResult.exports.entryPoints).map(([key, val]: any) => (
                                        <div key={key} className="flex flex-col mt-2">
                                            <span className="text-gray-500 capitalize">{key}</span>
                                            <span className="text-gray-400 font-mono bg-gray-900 px-1 rounded break-all">{val}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className="bg-gray-800/40 p-3 rounded border border-gray-700/50">
                                <h4 className="text-xs uppercase font-bold text-gray-400 mb-2">Dependency Graph</h4>
                                <div className="text-xs space-y-1">
                                    <div className="flex justify-between">
                                        <span className="text-gray-500">Total (Recursive)</span>
                                        <span className="text-white">{scanResult.dependencyGraph.totalDependencies}</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-gray-500">Max Depth</span>
                                        <span className="text-white">{scanResult.dependencyGraph.maxDepth}</span>
                                    </div>
                                     {scanResult.dependencyGraph.circularDependencies.length > 0 && (
                                        <div className="mt-2">
                                            <span className="text-red-400 block">Circular Dependencies Detected!</span>
                                            <ul className="list-disc list-inside text-gray-500 mt-1">
                                                {scanResult.dependencyGraph.circularDependencies.slice(0,3).map((chain:string[], i:number) => (
                                                    <li key={i} className="truncate" title={chain.join(' -> ')}>{chain.join(' -> ')}</li>
                                                ))}
                                            </ul>
                                        </div>
                                    )}
                                </div>
                            </div>
                         </div>
                    ) : viewMode === 'tree' ? (
                        treeStructure.map((node, i) => (
                            <TreeItem 
                                key={i} 
                                node={node} 
                                level={0} 
                                onSelect={setSelectedFile}
                                expandedPaths={expandedPaths}
                                togglePath={togglePath}
                                onScrollToLine={scrollToLine}
                                symbolsMap={symbolsMap}
                            />
                        ))
                    ) : (
                        files.map((f, i) => (
                            <div key={i}>
                                <div 
                                    onClick={() => setSelectedFile({ path: f.name, name: f.name })}
                                    className="flex items-center gap-2 py-1 px-2 hover:bg-gray-800 cursor-pointer text-sm select-none transition-colors"
                                >
                                    <span className="text-gray-500 text-xs">📄</span>
                                    <span className="text-gray-300 truncate font-mono">{f.name}</span>
                                </div>
                                {/* Show symbols in Flat View too if available */}
                                {symbolsMap[f.name] && symbolsMap[f.name].length > 0 && (
                                    <div className="pl-6 border-l border-gray-800 ml-2 mb-1">
                                        {symbolsMap[f.name].map((s: SymbolData, idx: number) => (
                                            <div key={idx} className="text-[10px] text-gray-500 font-mono flex items-center gap-2 truncate">
                                                <span className={`w-1 h-1 rounded-full ${s.type==='class'?'bg-yellow-500':s.type==='func'?'bg-purple-500':'bg-blue-500'}`}></span>
                                                {s.name}
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        ))
                    )}
                </div>
            </div>

            {/* Resize Handle */}
            <div 
                className="w-1 bg-gray-800 hover:bg-blue-500 cursor-col-resize z-30 flex-none transition-colors"
                onMouseDown={startResizing}
            ></div>

            {/* Right: Content */}
            <div className="flex-1 flex flex-col bg-[#05080f] relative min-w-0">
                <div className="h-12 border-b border-gray-800 flex items-center px-4 bg-gray-900/50 text-sm text-gray-400 select-text font-mono justify-between backdrop-blur-sm">
                    <span className="truncate max-w-2xl">{selectedFile ? selectedFile.path : 'README.md'}</span>
                    
                    <div className="flex items-center gap-2">
                        <button 
                            onClick={handleCopyFile}
                             className={`flex items-center gap-2 bg-gray-800 hover:bg-gray-700 text-gray-300 px-3 py-1.5 rounded border border-gray-700 transition-all text-xs font-bold uppercase tracking-wider ${copyFileSuccess ? 'text-green-400 border-green-800' : ''}`}
                        >
                           {copyFileSuccess ? 'Copied!' : 'Copy File'}
                        </button>
                        <button 
                            onClick={handleChatClick}
                            className="flex items-center gap-2 bg-cyan-900/20 hover:bg-cyan-900/40 text-cyan-400 px-3 py-1.5 rounded border border-cyan-900/50 transition-all shadow-[0_0_10px_rgba(8,145,178,0.2)] hover:shadow-[0_0_15px_rgba(8,145,178,0.4)] group"
                        >
                            <svg className="w-4 h-4 group-hover:animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
                            <span className="text-xs font-bold uppercase tracking-wider">AI Chat</span>
                        </button>
                    </div>
                </div>

                <div 
                    id="code-container"
                    className="flex-1 overflow-auto p-0 relative scrollbar-thin scrollbar-thumb-gray-800 scrollbar-track-transparent bg-[#0d1117]"
                >
                    {contentLoading && (
                        <div className="absolute inset-0 flex items-center justify-center bg-[#05080f]/60 backdrop-blur-[2px] z-20 transition-all duration-200">
                            <div className="flex flex-col items-center gap-3">
                                <span className="animate-spin w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full shadow-[0_0_15px_rgba(34,211,238,0.5)]"></span>
                                <span className="text-xs text-cyan-400 font-mono animate-pulse tracking-widest">FETCHING STREAM...</span>
                            </div>
                        </div>
                    )}
                    
                    <pre className={`line-numbers transition-opacity duration-200 ${contentLoading ? 'opacity-40' : 'opacity-100'}`} style={{ margin: 0, minHeight: '100%', background: 'transparent' }}>
                        <code className={`language-${selectedFile?.name.split('.').pop() || 'md'} !bg-transparent !text-sm !font-mono`}>
                            {fileContent || 'No content available.'}
                        </code>
                    </pre>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};
