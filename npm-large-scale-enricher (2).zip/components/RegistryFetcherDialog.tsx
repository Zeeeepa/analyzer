
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { IndexerConfig, LogEntry, PackageInfo, WorkerStatus } from '../types';
import { getRegistryInfo, IndexerWorker, DEFAULT_REGISTRY, DEFAULT_START_SEQ, DEFAULT_WORKERS, TAG_MOST_RECENT } from '../services/registryService';

interface RegistryFetcherDialogProps {
  initialStartSequence?: string;
  onClose: () => void;
  onPackagesFound: (pkgs: PackageInfo[]) => void;
  onComplete: (endSeq: string, totalFound: number, elapsedMs: number) => void;
}

export const RegistryFetcherDialog: React.FC<RegistryFetcherDialogProps> = ({ 
  initialStartSequence, 
  onClose, 
  onPackagesFound,
  onComplete 
}) => {
  const [config, setConfig] = useState<IndexerConfig>({
    registry: DEFAULT_REGISTRY,
    startSequence: initialStartSequence || DEFAULT_START_SEQ,
    endSequence: TAG_MOST_RECENT,
    workers: DEFAULT_WORKERS,
  });

  const [isRunning, setIsRunning] = useState(false);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [workerStatuses, setWorkerStatuses] = useState<WorkerStatus[]>([]);
  const [isCheckingRegistry, setIsCheckingRegistry] = useState(false);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [totalFound, setTotalFound] = useState(0);
  
  // To store the resolved end sequence
  const resolvedEndSeqRef = useRef<number>(0);

  const workersRef = useRef<IndexerWorker[]>([]);
  const logsEndRef = useRef<HTMLDivElement>(null);

  // Timer for elapsed time
  useEffect(() => {
    if (!isRunning) return;
    const interval = setInterval(() => {
        if (startTime) setElapsed(Date.now() - startTime);
    }, 1000);
    return () => clearInterval(interval);
  }, [isRunning, startTime]);

  // Auto-scroll logs
  useEffect(() => {
      logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const addLog = useCallback((type: LogEntry['type'], message: string) => {
    setLogs(prev => [...prev.slice(-99), { 
      id: crypto.randomUUID(),
      timestamp: new Date(),
      type,
      message
    }]);
  }, []);

  const handleStop = useCallback(() => {
    workersRef.current.forEach(w => w.stop());
    setIsRunning(false);
    addLog('warn', 'Indexing stopped by user.');
  }, [addLog]);

  const handleResolveLatest = async () => {
    if (isRunning || isCheckingRegistry) return;
    setIsCheckingRegistry(true);
    addLog('info', `Resolving latest sequence from ${config.registry}...`);
    
    try {
        const info = await getRegistryInfo(config.registry);
        const seq = info.update_seq;
        setConfig(prev => ({ ...prev, endSequence: seq }));
        
        const start = parseInt(config.startSequence);
        const end = parseInt(seq);
        
        if (!isNaN(start) && !isNaN(end) && start > end) {
            addLog('warn', `⚠️ Registry Mismatch: Start (${start}) is higher than Latest (${end}). This usually happens when switching registries (e.g. npmjs -> npmmirror). Please Reset Start to 0.`);
        } else {
            addLog('success', `Resolved latest sequence: ${seq}`);
        }
    } catch (err: any) {
        addLog('error', `Failed to resolve: ${err.message}`);
    } finally {
        setIsCheckingRegistry(false);
    }
  };

  const handleStart = useCallback(async () => {
    if (isRunning) return;
    setLogs([]);
    setWorkerStatuses([]);
    setTotalFound(0);
    setElapsed(0);
    setIsRunning(true);
    setStartTime(Date.now());
    
    addLog('info', 'Initializing indexer...');

    try {
      // 1. Resolve sequences
      let startSeq = parseInt(config.startSequence);
      let endSeq = 0;

      if (config.endSequence === TAG_MOST_RECENT) {
        setIsCheckingRegistry(true);
        addLog('info', `Fetching registry info from ${config.registry}...`);
        try {
          const info = await getRegistryInfo(config.registry);
          endSeq = parseInt(info.update_seq);
          resolvedEndSeqRef.current = endSeq;
          // Update config UI to show the resolved number for clarity
          setConfig(prev => ({...prev, endSequence: info.update_seq}));
          addLog('success', `Resolved most recent sequence: ${endSeq}`);
        } catch (err: any) {
          addLog('error', `Failed to fetch registry info: ${err.message}. Check CORS/URL.`);
          setIsCheckingRegistry(false);
          setIsRunning(false);
          return;
        } finally {
          setIsCheckingRegistry(false);
        }
      } else {
        endSeq = parseInt(config.endSequence);
        resolvedEndSeqRef.current = endSeq;
      }

      if (isNaN(startSeq) || isNaN(endSeq)) {
        throw new Error('Invalid sequence numbers');
      }

      if (startSeq >= endSeq) {
        addLog('warn', `Start sequence (${startSeq}) >= end sequence (${endSeq}). Range is empty or invalid.`);
        addLog('warn', `TIP: If you switched registries, click "Reset" on Start Sequence.`);
        setIsRunning(false);
        return;
      }

      // 2. Prepare Workers
      const workerCount = Math.min(config.workers, 500); 
      const range = endSeq - startSeq;
      const step = Math.ceil(range / workerCount);

      addLog('info', `Launching ${workerCount} workers. Range: ${range.toLocaleString()} pkgs.`);

      const newWorkers: IndexerWorker[] = [];
      const initialStatuses: WorkerStatus[] = [];

      for (let i = 0; i < workerCount; i++) {
        const wStart = startSeq + (i * step);
        const wEnd = Math.min(wStart + step, endSeq);
        
        if (wStart >= endSeq) break;

        initialStatuses.push({
          id: i,
          currentSeq: String(wStart),
          status: 'idle',
          packagesFound: 0,
          progress: 0
        });

        const worker = new IndexerWorker(
          i,
          config.registry,
          wStart,
          wEnd,
          // Update Status
          (status) => {
            setWorkerStatuses(prev => {
              const next = [...prev];
              const idx = next.findIndex(s => s.id === status.id);
              if (idx !== -1) next[idx] = status;
              return next;
            });
          },
          // Found Package
          (pkg) => {
             setTotalFound(prev => prev + 1);
             onPackagesFound([pkg]); // Send immediately to parent app
          },
          // Log
          (entry) => {
            setLogs(prev => [...prev.slice(-99), entry]);
          }
        );
        newWorkers.push(worker);
      }

      setWorkerStatuses(initialStatuses);
      workersRef.current = newWorkers;

      // 3. Execute
      const promises = newWorkers.map(w => w.start());

      // Wait for all workers to settle
      Promise.allSettled(promises).then(() => {
        const aborted = workersRef.current.some(w => w.abortController?.signal.aborted);

        if (!aborted) {
            setIsRunning(false);
            const finalEndSeq = resolvedEndSeqRef.current;
            const elapsedFinal = Date.now() - (startTime || Date.now());
            
            addLog('success', `All workers completed. Final Sequence: ${finalEndSeq}`);
            onComplete(String(finalEndSeq), totalFound, elapsedFinal); 
        }
      });

    } catch (err: any) {
      addLog('error', `Initialization failed: ${err.message}`);
      setIsRunning(false);
    }
  }, [config, isRunning, addLog, onPackagesFound, onComplete, startTime, totalFound]);

  const formatTime = (ms: number) => {
    const seconds = Math.floor(ms / 1000);
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}m ${s}s`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
       <div className="bg-slate-900 w-full max-w-5xl h-[90vh] rounded-xl border border-slate-800 shadow-2xl flex flex-col overflow-hidden ring-1 ring-white/10">
          {/* Header */}
          <div className="bg-slate-950 p-6 border-b border-slate-800 flex justify-between items-center">
              <div>
                  <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                      <span className="text-indigo-500">📦</span> Registry Indexer
                  </h2>
                  <p className="text-slate-400 text-sm">High-concurrency package discovery via CouchDB Sequence Protocol</p>
              </div>
              {!isRunning && (
                  <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors">
                        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                  </button>
              )}
          </div>

          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
             {/* Left Panel: Config */}
             <div className="w-full md:w-1/3 bg-slate-900/50 p-6 border-r border-slate-800 overflow-y-auto flex flex-col gap-6">
                 <div className="space-y-4">
                    <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase">Registry URL</label>
                        <input 
                            type="text" 
                            disabled={isRunning}
                            value={config.registry}
                            onChange={e => setConfig({...config, registry: e.target.value})}
                            className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:border-indigo-500 outline-none font-mono text-sm disabled:opacity-50"
                        />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                         <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase">Workers</label>
                            <input 
                                type="number" 
                                min="1"
                                max="500"
                                disabled={isRunning}
                                value={config.workers}
                                onChange={e => setConfig({...config, workers: parseInt(e.target.value) || 1})}
                                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:border-indigo-500 outline-none font-mono text-sm disabled:opacity-50"
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase flex justify-between items-center">
                                Start Seq
                                <button 
                                    disabled={isRunning}
                                    onClick={() => setConfig({...config, startSequence: '0'})}
                                    className="text-[9px] bg-slate-800 hover:bg-slate-700 px-2 py-0.5 rounded text-slate-400 hover:text-white transition-colors"
                                    title="Reset to 0 (Full Index)"
                                >
                                    RESET
                                </button>
                            </label>
                            <input 
                                type="text" 
                                disabled={isRunning}
                                value={config.startSequence}
                                onChange={e => setConfig({...config, startSequence: e.target.value})}
                                className="w-full bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:border-indigo-500 outline-none font-mono text-sm disabled:opacity-50"
                            />
                             <div className="text-[10px] text-slate-500 text-right">
                                {initialStartSequence === config.startSequence ? '(Auto-loaded)' : ''}
                            </div>
                        </div>
                    </div>

                    <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase">End Sequence</label>
                        <div className="flex gap-2">
                            <input 
                                type="text" 
                                disabled={isRunning || isCheckingRegistry}
                                value={config.endSequence}
                                onChange={e => setConfig({...config, endSequence: e.target.value})}
                                className="flex-1 bg-slate-950 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:border-indigo-500 outline-none font-mono text-sm disabled:opacity-50"
                            />
                            <button 
                                disabled={isRunning || isCheckingRegistry}
                                onClick={handleResolveLatest}
                                className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 rounded border border-slate-700 transition-colors whitespace-nowrap disabled:opacity-50 flex items-center gap-1"
                            >
                                {isCheckingRegistry && <span className="animate-spin w-3 h-3 border-2 border-slate-400 border-t-transparent rounded-full"></span>}
                                Resolve
                            </button>
                        </div>
                    </div>
                 </div>

                 <div className="mt-auto">
                    {!isRunning ? (
                        <button 
                            onClick={handleStart}
                            className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded font-bold shadow-lg shadow-indigo-900/50 transition-all flex items-center justify-center gap-2"
                        >
                             <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                            Start Indexing
                        </button>
                    ) : (
                        <button 
                            onClick={handleStop}
                            className="w-full py-3 bg-rose-600 hover:bg-rose-500 text-white rounded font-bold shadow-lg shadow-rose-900/50 transition-all flex items-center justify-center gap-2"
                        >
                            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M6 6h12v12H6z"/></svg>
                            Stop Process
                        </button>
                    )}
                 </div>
             </div>

             {/* Right Panel: Visualization */}
             <div className="w-full md:w-2/3 p-6 flex flex-col bg-[#05080f] relative">
                 {/* Stats Grid */}
                 <div className="grid grid-cols-3 gap-4 mb-6">
                    <div className="bg-slate-800/30 border border-slate-700 p-4 rounded-lg">
                        <span className="text-xs text-slate-500 uppercase font-bold">Found</span>
                        <div className="text-3xl font-mono text-emerald-400">{totalFound.toLocaleString()}</div>
                    </div>
                    <div className="bg-slate-800/30 border border-slate-700 p-4 rounded-lg">
                        <span className="text-xs text-slate-500 uppercase font-bold">Duration</span>
                        <div className="text-3xl font-mono text-blue-400">{formatTime(elapsed)}</div>
                    </div>
                    <div className="bg-slate-800/30 border border-slate-700 p-4 rounded-lg">
                        <span className="text-xs text-slate-500 uppercase font-bold">Avg Speed</span>
                        <div className="text-3xl font-mono text-amber-400">
                             {elapsed > 0 ? Math.round((totalFound / (elapsed / 1000))).toLocaleString() : 0}
                             <span className="text-sm text-slate-600 ml-1">/s</span>
                        </div>
                    </div>
                 </div>

                 {/* Worker Grid */}
                 <div className="flex-1 bg-slate-950 border border-slate-800 rounded-lg p-4 overflow-hidden flex flex-col mb-4 shadow-inner">
                    <h3 className="text-xs text-slate-400 uppercase font-bold mb-3 flex justify-between">
                        <span>Worker Matrix ({workerStatuses.length})</span>
                        {isRunning && <span className="text-indigo-400 animate-pulse">● Active</span>}
                    </h3>
                    <div className="flex-1 overflow-y-auto pr-1 min-h-[150px]">
                        <div className="grid grid-cols-10 md:grid-cols-12 lg:grid-cols-20 gap-1">
                            {workerStatuses.map(w => (
                                <div 
                                    key={w.id}
                                    title={`Worker ${w.id}: ${w.status} (${Math.round(w.progress)}%)`}
                                    className={`h-1.5 w-full rounded-sm transition-all duration-500 ${
                                        w.status === 'working' ? 'bg-indigo-500 shadow-[0_0_5px_rgba(99,102,241,0.8)]' :
                                        w.status === 'finished' ? 'bg-emerald-500' :
                                        w.status === 'error' ? 'bg-rose-500' : 'bg-slate-800'
                                    }`}
                                ></div>
                            ))}
                            {workerStatuses.length === 0 && <span className="col-span-full text-center text-slate-700 italic mt-10">Workers not initialized</span>}
                        </div>
                    </div>
                 </div>

                 {/* Logs */}
                 <div className="h-40 bg-slate-950 border border-slate-800 rounded-lg p-3 overflow-y-auto font-mono text-[10px] space-y-1 shadow-inner">
                    {logs.map(l => (
                        <div key={l.id} className={`flex gap-2 ${
                            l.type === 'error' ? 'text-rose-400' : 
                            l.type === 'warn' ? 'text-amber-400' : 
                            l.type === 'success' ? 'text-emerald-400' : 'text-slate-400'
                        }`}>
                            <span className="text-slate-600 shrink-0">[{l.timestamp.toLocaleTimeString()}]</span>
                            <span>{l.message}</span>
                        </div>
                    ))}
                    <div ref={logsEndRef} />
                 </div>
             </div>
          </div>
       </div>
    </div>
  );
};
