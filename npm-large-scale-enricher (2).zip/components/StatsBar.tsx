import React from 'react';
import { Stats } from '../types';

interface StatsBarProps {
  stats: Stats;
  isEnriching: boolean;
  onToggleEnrich: () => void;
  onExport: () => void;
  onClear: () => void;
  queueSize: number;
}

export const StatsBar: React.FC<StatsBarProps> = ({ stats, isEnriching, onToggleEnrich, onExport, onClear, queueSize }) => {
  const percent = stats.total > 0 ? Math.round((stats.enriched / stats.total) * 100) : 0;

  return (
    <div className="bg-gray-900 border-b border-gray-800 p-4 flex flex-wrap items-center gap-6 shadow-lg">
      <div className="flex items-center gap-4 flex-1">
        <div className="flex flex-col">
          <span className="text-xs text-gray-500 uppercase tracking-wider font-bold">Total Loaded</span>
          <span className="text-2xl font-bold text-white">{stats.total.toLocaleString()}</span>
        </div>
        
        <div className="h-8 w-px bg-gray-700 mx-2"></div>

        <div className="flex flex-col">
           <span className="text-xs text-gray-500 uppercase tracking-wider font-bold">Enriched</span>
           <div className="flex items-baseline gap-2">
             <span className="text-2xl font-bold text-green-400">{stats.enriched.toLocaleString()}</span>
             <span className="text-xs text-gray-500">({percent}%)</span>
           </div>
        </div>

        <div className="h-8 w-px bg-gray-700 mx-2"></div>

        <div className="flex flex-col">
           <span className="text-xs text-gray-500 uppercase tracking-wider font-bold">Failed</span>
           <span className="text-2xl font-bold text-red-400">{stats.failed.toLocaleString()}</span>
        </div>

        <div className="h-8 w-px bg-gray-700 mx-2"></div>
        
        <div className="flex flex-col">
           <span className="text-xs text-gray-500 uppercase tracking-wider font-bold">Queue</span>
           <span className="text-xl font-mono text-blue-300">{queueSize}</span>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <button 
          onClick={onToggleEnrich}
          className={`px-4 py-2 rounded-md font-semibold text-sm transition-all shadow-md flex items-center gap-2 ${
            isEnriching 
            ? 'bg-red-600 hover:bg-red-500 text-white' 
            : 'bg-green-600 hover:bg-green-500 text-white'
          }`}
        >
          {isEnriching ? (
            <>
              <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>
              Stop Enrichment
            </>
          ) : (
             <>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
              Start Enrichment
            </>
          )}
        </button>

        <button 
          onClick={onExport}
          disabled={stats.total === 0}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-md font-semibold text-sm transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
          Export CSV
        </button>
        
        <button 
          onClick={onClear}
          className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-md font-semibold text-sm transition-all shadow-md"
        >
          Clear
        </button>
      </div>
    </div>
  );
};