
import React, { useEffect, useState } from 'react';
import { fetchDependencies } from '../services/npmService';

interface DependenciesDialogProps {
  packageName: string;
  onClose: () => void;
}

export const DependenciesDialog: React.FC<DependenciesDialogProps> = ({ packageName, onClose }) => {
  const [deps, setDeps] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchDependencies(packageName)
      .then(setDeps)
      .catch(() => setError('Failed to load dependencies'))
      .finally(() => setLoading(false));
  }, [packageName]);

  const depEntries = Object.entries(deps);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-gray-900 w-full max-w-md h-[70vh] rounded-xl border border-gray-800 shadow-2xl flex flex-col overflow-hidden">
        <div className="bg-gray-950 p-4 border-b border-gray-800 flex justify-between items-center">
           <div>
                <h2 className="text-lg font-bold text-white">Dependencies</h2>
                <p className="text-gray-500 text-xs">for {packageName}</p>
           </div>
           <button onClick={onClose} className="text-gray-500 hover:text-white">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
           </button>
        </div>

        <div className="flex-1 overflow-y-auto p-2 scrollbar-thin scrollbar-thumb-gray-700">
            {loading ? (
                <div className="flex justify-center p-8"><span className="animate-spin w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full"></span></div>
            ) : error ? (
                <div className="text-red-400 p-4 text-center">{error}</div>
            ) : depEntries.length === 0 ? (
                <div className="text-gray-500 p-4 text-center">No dependencies found.</div>
            ) : (
                <table className="w-full text-sm text-left text-gray-400">
                    <thead className="text-xs text-gray-500 uppercase bg-gray-800">
                        <tr>
                            <th className="px-4 py-2">Package</th>
                            <th className="px-4 py-2 text-right">Version</th>
                        </tr>
                    </thead>
                    <tbody>
                        {depEntries.map(([name, version]) => (
                            <tr key={name} className="bg-gray-900 border-b border-gray-800 hover:bg-gray-800/50">
                                <td className="px-4 py-2 font-medium text-gray-300">
                                    <a href={`https://www.npmjs.com/package/${name}`} target="_blank" rel="noreferrer" className="hover:underline text-blue-400">
                                        {name}
                                    </a>
                                </td>
                                <td className="px-4 py-2 text-right font-mono text-gray-500">{version}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
      </div>
    </div>
  );
};
