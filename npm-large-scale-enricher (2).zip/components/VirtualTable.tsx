
import React, { useRef, useState, useEffect, useMemo, useCallback } from 'react';
import { PackageRow, SortField, SortOrder } from '../types';

interface VirtualTableProps {
  rows: PackageRow[];
  onSort: (field: SortField) => void;
  sortField: SortField;
  sortOrder: SortOrder;
  onPackageClick: (row: PackageRow) => void;
  onAuthorClick: (name: string) => void;
  onDepsClick: (row: PackageRow) => void;
}

const ROW_HEIGHT = 46;
const OVERSCAN = 10;

const formatBytes = (bytes: number) => {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

const formatDate = (dateStr: string) => {
  if (!dateStr) return '-';
  try {
    return new Date(dateStr).toISOString().split('T')[0];
  } catch {
    return dateStr;
  }
};

// --- Gradient Color Generators ---
const interpolateColor = (ratio: number, startRgb: number[], endRgb: number[]) => {
    const r = Math.round(startRgb[0] + (endRgb[0] - startRgb[0]) * ratio);
    const g = Math.round(startRgb[1] + (endRgb[1] - startRgb[1]) * ratio);
    const b = Math.round(startRgb[2] + (endRgb[2] - startRgb[2]) * ratio);
    return `rgb(${r}, ${g}, ${b})`;
};

const getPerceptualRatio = (val: number, max: number, gamma: number) => {
    const linear = Math.min(Math.max(val / max, 0), 1);
    return Math.pow(linear, gamma);
};

const getSizeColorStyle = (bytes: number) => {
    const max = 100 * 1024 * 1024;
    const ratio = getPerceptualRatio(bytes, max, 0.25);
    const color = interpolateColor(ratio, [255, 255, 255], [34, 197, 94]);
    return { color };
};

const getInstallSizeColorStyle = (bytes: number) => {
    const max = 5 * 1024 * 1024; // 5MB bundle is huge
    const ratio = getPerceptualRatio(bytes, max, 0.3);
    // White to Orange/Red for bundle size
    const color = interpolateColor(ratio, [255, 255, 255], [251, 146, 60]);
    return { color };
};

const getFileColorStyle = (count: number) => {
    const max = 1000;
    const ratio = getPerceptualRatio(count, max, 0.4);
    const color = interpolateColor(ratio, [255, 255, 255], [250, 204, 21]);
    return { color };
};

const getDateColorStyle = (dateStr: string) => {
    if (!dateStr) return { color: 'rgb(107, 114, 128)' }; 
    const now = new Date().getTime();
    const date = new Date(dateStr).getTime();
    const diff = now - date;
    const oneYear = 365 * 24 * 60 * 60 * 1000;
    const newness = Math.max(0, 1 - (diff / oneYear));
    const color = interpolateColor(newness, [255, 255, 255], [239, 68, 68]);
    return { color };
};


export const VirtualTable: React.FC<VirtualTableProps> = ({ 
  rows, 
  onSort, 
  sortField, 
  sortOrder,
  onPackageClick,
  onAuthorClick,
  onDepsClick
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scrollTop, setScrollTop] = useState(0);
  const [containerHeight, setContainerHeight] = useState(0);
  const [tooltipData, setTooltipData] = useState<{text: string, top: number, left: number} | null>(null);
  
  // Resizable Column State
  const [nameColWidth, setNameColWidth] = useState(160);
  const [isResizingName, setIsResizingName] = useState(false);

  useEffect(() => {
    const updateHeight = () => {
      if (containerRef.current) {
        setContainerHeight(containerRef.current.clientHeight);
      }
    };
    window.addEventListener('resize', updateHeight);
    updateHeight();
    return () => window.removeEventListener('resize', updateHeight);
  }, []);

  // Column Resize Logic
  const startResizingName = useCallback(() => setIsResizingName(true), []);
  const stopResizingName = useCallback(() => setIsResizingName(false), []);
  
  const onMouseMove = useCallback((e: MouseEvent) => {
      if (isResizingName) {
          const newWidth = Math.max(100, Math.min(600, nameColWidth + e.movementX));
          setNameColWidth(newWidth);
      }
  }, [isResizingName, nameColWidth]);

  useEffect(() => {
      if (isResizingName) {
          window.addEventListener('mousemove', onMouseMove);
          window.addEventListener('mouseup', stopResizingName);
      }
      return () => {
          window.removeEventListener('mousemove', onMouseMove);
          window.removeEventListener('mouseup', stopResizingName);
      };
  }, [isResizingName, onMouseMove, stopResizingName]);

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    setScrollTop(e.currentTarget.scrollTop);
    setTooltipData(null);
  };

  const handleMouseEnterDesc = (e: React.MouseEvent, text: string) => {
     if (!text) return;
     const rect = e.currentTarget.getBoundingClientRect();
     setTooltipData({
         text,
         top: rect.bottom + 5,
         left: rect.left
     });
  };

  const handleMouseLeaveDesc = () => {
      setTooltipData(null);
  };

  const totalHeight = rows.length * ROW_HEIGHT;
  
  const startIndex = Math.max(0, Math.floor(scrollTop / ROW_HEIGHT) - OVERSCAN);
  const endIndex = Math.min(
    rows.length,
    Math.ceil((scrollTop + containerHeight) / ROW_HEIGHT) + OVERSCAN
  );

  const visibleRows = useMemo(() => {
    const result = [];
    for (let i = startIndex; i < endIndex; i++) {
      result.push({ ...rows[i], virtualIndex: i });
    }
    return result;
  }, [rows, startIndex, endIndex]);

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <span className="ml-1 text-gray-700 opacity-0 group-hover:opacity-50 transition-opacity">↕</span>;
    return <span className="ml-1 text-cyan-400 shadow-[0_0_5px_rgba(34,211,238,0.5)]">{sortOrder === SortOrder.ASC ? '↑' : '↓'}</span>;
  };

  const HeaderCell = ({ field, label, width, align = 'left', resizable = false, onResizeStart }: any) => (
    <div 
      className={`flex items-center group cursor-pointer hover:bg-white/5 transition-colors px-3 py-3 font-bold text-[10px] uppercase tracking-widest text-gray-400 border-r border-gray-800/50 select-none relative ${align === 'right' ? 'justify-end' : ''}`}
      style={{ width: width }}
      onClick={() => onSort(field)}
    >
      {label} <SortIcon field={field} />
      {resizable && (
          <div 
             className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-500 z-10"
             onMouseDown={(e) => { e.stopPropagation(); onResizeStart && onResizeStart(); }}
             onClick={(e) => e.stopPropagation()}
          ></div>
      )}
    </div>
  );

  const StaticHeader = ({ label, width, align = 'left' }: { label: string, width: string, align?: string }) => (
     <div 
       className={`px-3 py-3 font-bold text-[10px] uppercase tracking-widest text-gray-400 border-r border-gray-800/50 flex items-center ${align === 'right' ? 'justify-end' : (align === 'center' ? 'justify-center' : '')}`}
       style={{ width: width }}
     >
        {label}
     </div>
  );

  return (
    <div className="flex flex-col h-full bg-[#05080f] rounded-lg overflow-hidden shadow-[0_0_20px_rgba(0,0,0,0.5)] ring-1 ring-white/10 relative">
      {/* Background Grid Effect */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none"></div>

      {/* Header */}
      <div className="flex flex-none bg-gray-950/80 backdrop-blur-md z-20 shadow border-b border-gray-800">
        <HeaderCell field={SortField.NUMBER} label="#" width="64px" />
        
        {/* Resizable Name Column */}
        <HeaderCell 
            field={SortField.NAME} 
            label="Package ID" 
            width={`${nameColWidth}px`} 
            resizable={true} 
            onResizeStart={startResizingName}
        />
        
        <StaticHeader label="Desc" width="48px" align="center" />
        <HeaderCell field={SortField.SIZE} label="Size" width="96px" align="right" />
        <HeaderCell field={SortField.INSTALL_SIZE} label="Inst. Size" width="96px" align="right" />
        <HeaderCell field={SortField.FILES} label="Files" width="80px" align="right" />
        <StaticHeader label="Dep" width="64px" align="right" />
        <HeaderCell field={SortField.DATE} label="Published" width="112px" align="right" />
        <StaticHeader label="License" width="96px" align="center" />
        <StaticHeader label="Collaborators" width="128px" />
        <div className="flex-1 border-r border-gray-800/50"></div> {/* Spacer */}
      </div>

      {/* Virtual List */}
      <div 
        ref={containerRef}
        className="flex-1 overflow-y-auto relative scrollbar-thin scrollbar-thumb-gray-800 scrollbar-track-transparent z-10"
        onScroll={handleScroll}
      >
        <div style={{ height: totalHeight, position: 'relative' }}>
          {visibleRows.map((row) => {
            // Status Color Logic
            let statusColor = 'bg-gray-700';
            let rowBg = '';
            if (row._status === 'enriched') {
                statusColor = 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)]';
                rowBg = 'bg-emerald-900/5';
            } else if (row._status === 'error') {
                statusColor = 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)]';
                rowBg = 'bg-red-900/10';
            } else if (row._status === 'pending') {
                statusColor = 'bg-blue-500 animate-pulse shadow-[0_0_8px_rgba(59,130,246,0.6)]';
            }

            return (
            <div
              key={row.id}
              className={`absolute left-0 right-0 flex items-center border-b border-gray-800/50 hover:bg-white/5 hover:border-l-2 hover:border-l-cyan-400 transition-all group text-sm ${rowBg}`}
              style={{
                top: row.virtualIndex! * ROW_HEIGHT,
                height: ROW_HEIGHT,
              }}
            >
              <div className="flex-none px-3 flex items-center gap-2 font-mono text-xs text-gray-600 group-hover:text-gray-400" style={{ width: '64px' }}>
                 <div className={`w-1.5 h-1.5 rounded-full ${statusColor}`}></div>
                 {row.number}
              </div>
              
              <div className="flex-none px-3 truncate font-medium font-mono text-blue-300 group-hover:text-cyan-300 transition-colors" style={{ width: `${nameColWidth}px` }}>
                <button 
                    onClick={() => onPackageClick(row)}
                    className="hover:underline flex items-center gap-2 text-left w-full truncate"
                    title={row.package_name}
                >
                  {row.package_name || 'Unknown'}
                </button>
              </div>

              <div 
                className="flex-none flex items-center justify-center border-l border-gray-800/30"
                style={{ width: '48px' }}
                onMouseEnter={(e) => handleMouseEnterDesc(e, row.description)}
                onMouseLeave={handleMouseLeaveDesc}
              >
                {row.description ? (
                    <span className="text-gray-600 cursor-help hover:text-white transition-colors font-mono text-xs">[?]</span>
                ) : <span className="text-gray-800 text-xs">-</span>}
              </div>

              <div className="flex-none px-3 text-right font-mono text-xs group-hover:opacity-100" style={{ width: '96px' }}>
                <span style={getSizeColorStyle(row.unpacked_size)} className="transition-colors duration-300">
                    {row.unpacked_size > 0 ? formatBytes(row.unpacked_size) : <span className="opacity-20 text-gray-600">-</span>}
                </span>
              </div>
              
              <div className="flex-none px-3 text-right font-mono text-xs group-hover:opacity-100" style={{ width: '96px' }}>
                <span style={getInstallSizeColorStyle(row.install_size || 0)} className="transition-colors duration-300">
                    {row.install_size ? formatBytes(row.install_size) : <span className="opacity-20 text-gray-600">-</span>}
                </span>
              </div>

              <div className="flex-none px-3 text-right font-mono text-xs" style={{ width: '80px' }}>
                 <span style={getFileColorStyle(row.file_number)} className="transition-colors duration-300">
                    {row.file_number > 0 ? row.file_number.toLocaleString() : <span className="opacity-20 text-gray-600">-</span>}
                 </span>
              </div>

              {/* Dependencies */}
              <div className="flex-none px-3 text-right text-gray-500 text-xs border-l border-gray-800/30" style={{ width: '64px' }}>
                <button onClick={() => onDepsClick(row)} className="hover:text-cyan-400 hover:underline w-full text-right font-mono">
                     {row.dependencies || <span className="opacity-20">0</span>}
                </button>
              </div>

              <div className="flex-none px-3 text-right text-xs font-mono" style={{ width: '112px' }}>
                <span style={getDateColorStyle(row.latest_release_published_at)} className="transition-colors duration-300">
                    {formatDate(row.latest_release_published_at)}
                </span>
              </div>
              
              <div className="flex-none px-3 truncate text-gray-500 text-xs text-center border-l border-gray-800/30 flex items-center justify-center gap-1" style={{ width: '96px' }}>
                {row.is_esm && (
                    <span className="text-[8px] bg-yellow-500/20 text-yellow-400 px-1 rounded border border-yellow-500/30" title="ESM Ready (Skypack)">ESM</span>
                )}
                {row.license ? <span className="px-1.5 py-0.5 rounded bg-gray-800 text-gray-300 text-[10px] truncate max-w-full">{row.license}</span> : <span className="opacity-20">-</span>}
              </div>

              <div className="flex-none px-3 truncate text-gray-500 text-xs flex gap-1 font-mono min-w-0" style={{ width: '128px' }}>
                {row.maintainers && row.maintainers.length > 0 ? (
                   row.maintainers.slice(0, 2).map((auth, i) => (
                        <button key={i} onClick={() => onAuthorClick(auth)} className="hover:text-cyan-400 hover:underline transition-colors truncate">
                            {auth}{i < Math.min(row.maintainers!.length, 2) - 1 ? ',' : ''}
                        </button>
                   ))
                ) : (
                   <button onClick={() => onAuthorClick(row.author_name)} className="hover:text-cyan-400 hover:underline truncate w-full text-left transition-colors">
                    {row.author_name}
                   </button>
                )}
                {row.maintainers && row.maintainers.length > 2 && <span className="text-gray-700">+{row.maintainers.length - 2}</span>}
              </div>

              {/* Spacer Row Background */}
              <div className="flex-1"></div>
            </div>
          )})}
        </div>
      </div>

      {/* Fixed Description Tooltip */}
      {tooltipData && (
          <div 
            className="fixed z-50 bg-gray-900 border border-gray-700 rounded-lg p-3 shadow-2xl max-w-sm pointer-events-none animate-in fade-in zoom-in duration-150"
            style={{ 
                top: Math.min(tooltipData.top, window.innerHeight - 150),
                left: Math.min(tooltipData.left, window.innerWidth - 320)
            }}
          >
              <div className="absolute -top-1 left-3 w-2 h-2 bg-gray-700 rotate-45"></div>
              <h4 className="text-[10px] uppercase tracking-widest text-gray-500 mb-1">Description</h4>
              <p className="text-sm text-gray-200 leading-relaxed font-light">{tooltipData.text}</p>
          </div>
      )}
    </div>
  );
};
