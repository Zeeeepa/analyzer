import React, { useState, useRef, useEffect } from 'react';
import { PackageRow } from '../types';
import { GoogleGenAI } from "@google/genai";

interface ChatDialogProps {
  context: {
      project: PackageRow;
      tree?: string;
      activeFile?: string;
      activeCode?: string;
  };
  onClose: () => void;
}

export const ChatDialog: React.FC<ChatDialogProps> = ({ context, onClose }) => {
    const { project, tree, activeFile, activeCode } = context;
    const [messages, setMessages] = useState<{role: 'user' | 'ai' | 'error', text: string}[]>([
        { role: 'ai', text: `Connected to **${project.package_name}** v${project.version || 'latest'} context.\nI have awareness of the file structure and the currently open file. Ask me anything about the codebase!` }
    ]);
    const [input, setInput] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const bottomRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, isTyping]);

    const send = async () => {
        if (!input.trim() || isTyping) return;
        
        const userMsg = input;
        setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
        setInput('');
        setIsTyping(true);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            
            // Construct System Prompt with Context
            let systemPrompt = `You are an expert Senior Software Engineer analyzing an NPM package named "${project.package_name}" (version ${project.version}).
            
            CONTEXT:
            - Description: ${project.description}
            - Entrypoints: ${project.entrypoints?.join(', ') || 'Unknown'}
            - Dependencies: ${project.dependencies_list?.join(', ') || 'None'}
            `;

            if (tree) {
                systemPrompt += `\n\nPROJECT FILE STRUCTURE & SYMBOLS:\n${tree}`;
            }
            
            if (activeFile && activeCode) {
                systemPrompt += `\n\nCURRENTLY OPEN FILE (${activeFile}):\n${activeCode.slice(0, 30000)}... (truncated if too long)`;
            }

            systemPrompt += `\n\nTASK: Answer the user's question about this codebase. Be specific, technical, and reference the provided file structure and symbols where possible.`;

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: [
                    { role: 'user', parts: [{ text: systemPrompt }] }, // Pre-load context in first turn (simulated system prompt via user msg for flash)
                    { role: 'model', parts: [{ text: "Understood. I have analyzed the context. How can I help?" }] },
                    { role: 'user', parts: [{ text: userMsg }] }
                ]
            });

            const text = response.text;
            if (text) {
                setMessages(prev => [...prev, { role: 'ai', text }]);
            } else {
                 throw new Error("Empty response");
            }

        } catch (err: any) {
            console.error(err);
            setMessages(prev => [...prev, { role: 'error', text: `Error: ${err.message || 'Failed to connect to AI'}` }]);
        } finally {
            setIsTyping(false);
        }
    };

    return (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
             <div className="w-full max-w-3xl h-[700px] bg-[#0a0f1a] border border-blue-500/30 rounded-xl shadow-[0_0_50px_-12px_rgba(59,130,246,0.3)] flex flex-col overflow-hidden relative ring-1 ring-white/5">
                {/* Header */}
                <div className="p-4 border-b border-gray-800 bg-gray-900/80 backdrop-blur flex justify-between items-center">
                    <div className="flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.8)] animate-pulse"></div>
                        <div className="flex flex-col">
                            <span className="font-mono text-cyan-300 font-bold tracking-wider text-sm uppercase">Gemini 2.5 Flash</span>
                            <span className="text-xs text-gray-500 font-mono">Context: {project.package_name} {activeFile ? ` > ${activeFile}` : ''}</span>
                        </div>
                    </div>
                    <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin scrollbar-thumb-blue-900/50 scrollbar-track-transparent bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')]">
                    {messages.map((m, i) => (
                        <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[85%] p-3 rounded text-sm font-mono leading-relaxed shadow-lg whitespace-pre-wrap ${
                                m.role === 'user' 
                                ? 'bg-blue-600/20 border border-blue-500/50 text-blue-100 rounded-br-none' 
                                : m.role === 'error'
                                ? 'bg-red-900/20 border border-red-500/50 text-red-300'
                                : 'bg-gray-800/60 border border-gray-700 text-gray-300 rounded-bl-none'
                            }`}>
                                {m.text}
                            </div>
                        </div>
                    ))}
                    {isTyping && (
                        <div className="flex justify-start">
                            <div className="bg-gray-800/60 border border-gray-700 p-3 rounded rounded-bl-none flex gap-1">
                                <span className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></span>
                                <span className="w-2 h-2 bg-gray-500 rounded-full animate-bounce delay-75"></span>
                                <span className="w-2 h-2 bg-gray-500 rounded-full animate-bounce delay-150"></span>
                            </div>
                        </div>
                    )}
                    <div ref={bottomRef}></div>
                </div>

                {/* Input */}
                <div className="p-4 bg-gray-900/90 border-t border-gray-800 backdrop-blur">
                    <div className="relative flex items-center gap-2">
                        <input 
                            className="flex-1 bg-[#05080f] border border-gray-700 rounded px-4 py-3 text-gray-200 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all font-mono text-sm placeholder-gray-600 shadow-inner"
                            placeholder="Ask about dependencies, structure, or code logic..."
                            value={input}
                            onChange={e => setInput(e.target.value)}
                            onKeyDown={e => e.key === 'Enter' && send()}
                            autoFocus
                            disabled={isTyping}
                        />
                        <button onClick={send} disabled={isTyping} className="p-3 bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-700 text-white rounded transition-colors shadow-[0_0_15px_rgba(8,145,178,0.4)]">
                             <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
                        </button>
                    </div>
                </div>
             </div>
        </div>
    )
}