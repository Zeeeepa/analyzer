
import { LogEntry, PackageInfo, WorkerStatus } from '../types';

export const TAG_MOST_RECENT = '<MOSTRECENT>';
export const DEFAULT_REGISTRY = 'https://registry.npmmirror.com'; 
export const DEFAULT_START_SEQ = '90095688';
export const DEFAULT_WORKERS = 50; 
export const BATCH_SIZE = 1000;

// Utility to create a delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Custom error for fetch failures
class FetchError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

// Fetch with retry logic adapted for browser
async function fetchWithRetry(url: string, signal?: AbortSignal, maxRetries = 3): Promise<any> {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const response = await fetch(url, {
        headers: {
          'Accept': 'application/json',
        },
        signal,
      });

      if (response.status === 429) {
        const retryAfter = parseInt(response.headers.get('retry-after') || '5');
        await delay(retryAfter * 1000);
        continue;
      }

      if (!response.ok) {
        throw new FetchError(response.status, `HTTP ${response.status}`);
      }

      return await response.json();
    } catch (err: any) {
      if (err.name === 'AbortError') throw err;
      
      if (attempt === maxRetries) throw err;
      await delay(1000 * attempt); // Exponential-ish backoff
    }
  }
}

// Validate package name
function isValidPackageName(name: string): boolean {
  return /^(@[a-z0-9-~][a-z0-9-._~]*\/)?[a-z0-9-~][a-z0-9-._~]*$/.test(name);
}

// Get the current update_seq from the registry
export async function getRegistryInfo(registry: string): Promise<{ update_seq: string }> {
  const data = await fetchWithRetry(registry.endsWith('/') ? registry : `${registry}/`);
  return { update_seq: String(data.update_seq || 0) };
}

// The Worker Logic
export class IndexerWorker {
  id: number;
  registry: string;
  startSeq: number;
  endSeq: number;
  onUpdate: (status: WorkerStatus) => void;
  onPackageFound: (pkg: PackageInfo) => void;
  onLog: (entry: LogEntry) => void;
  abortController: AbortController | null = null;

  constructor(
    id: number,
    registry: string,
    startSeq: number,
    endSeq: number,
    onUpdate: (status: WorkerStatus) => void,
    onPackageFound: (pkg: PackageInfo) => void,
    onLog: (entry: LogEntry) => void
  ) {
    this.id = id;
    this.registry = registry;
    this.startSeq = startSeq;
    this.endSeq = endSeq;
    this.onUpdate = onUpdate;
    this.onPackageFound = onPackageFound;
    this.onLog = onLog;
  }

  async start() {
    this.abortController = new AbortController();
    let since = this.startSeq;
    const totalRange = this.endSeq - this.startSeq;
    let packagesFound = 0;
    let errorCount = 0;

    this.updateStatus(since, 'working', packagesFound, 0);

    try {
      while (since < this.endSeq) {
        if (this.abortController.signal.aborted) break;

        // Calculate a safe batch size that doesn't overshoot endSeq too much
        const url = `${this.registry}/_changes?since=${since}&limit=${BATCH_SIZE}&include_docs=false`;

        try {
          const data = await fetchWithRetry(url, this.abortController.signal);
          const results = data.results || [];

          if (results.length === 0) {
            // No more changes, but we haven't reached endSeq? 
            // Registry might be sparse or we reached the actual end.
            break; 
          }

          let maxChangeSeq = since;

          for (const change of results) {
            const seq = Number(change.seq);
            const fullname = change.id;

            // Keep track of the highest sequence seen
            if (seq > maxChangeSeq) maxChangeSeq = seq;

            // Process package
            if (seq > since && fullname && !fullname.startsWith('_')) {
              if (isValidPackageName(fullname)) {
                 this.onPackageFound({ seq: String(seq), name: fullname });
                 packagesFound++;
              }
            }
          }

          // Update loop state
          since = maxChangeSeq;
          errorCount = 0; // Reset errors on success

          // Calculate progress
          const progressRaw = totalRange > 0 ? ((since - this.startSeq) / totalRange) * 100 : 100;
          const progress = Math.min(Math.max(progressRaw, 0), 100);

          this.updateStatus(since, 'working', packagesFound, progress);

          // Artificial tiny throttle to let UI breathe if network is super fast
          await delay(10); 

        } catch (err: any) {
          if (this.abortController.signal.aborted) break;
          
          errorCount++;
          this.onLog({
            id: crypto.randomUUID(),
            timestamp: new Date(),
            type: 'warn',
            message: `Worker #${this.id} error: ${err.message}. Retry ${errorCount}/5`
          });

          if (errorCount > 5) {
             this.updateStatus(since, 'error', packagesFound, 0);
             throw new Error('Max retries exceeded');
          }
          await delay(2000);
        }
      }
      
      this.updateStatus(since, 'finished', packagesFound, 100);
      this.onLog({
        id: crypto.randomUUID(),
        timestamp: new Date(),
        type: 'success',
        message: `Worker #${this.id} finished. Found ${packagesFound} packages.`
      });

    } catch (err: any) {
      if (err.name !== 'AbortError') {
         this.updateStatus(since, 'error', packagesFound, 0);
         this.onLog({
            id: crypto.randomUUID(),
            timestamp: new Date(),
            type: 'error',
            message: `Worker #${this.id} failed: ${err.message}`
         });
      }
    }
  }

  stop() {
    if (this.abortController) {
      this.abortController.abort();
    }
    this.updateStatus(this.startSeq, 'idle', 0, 0);
  }

  private updateStatus(currentSeq: number, status: WorkerStatus['status'], found: number, progress: number) {
    this.onUpdate({
      id: this.id,
      currentSeq: String(currentSeq),
      status,
      packagesFound: found,
      progress
    });
  }
}
