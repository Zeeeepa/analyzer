
import { PackageRow } from '../types';

const REGISTRY_BASE = 'https://registry.npmjs.org';
const JSDELIVR_BASE = 'https://data.jsdelivr.com/v1/package/npm';
const UNPKG_BASE = 'https://unpkg.com';
const JSDELIVR_CDN = 'https://cdn.jsdelivr.net/npm';
const BUNDLEPHOBIA_API = 'https://bundlephobia.com/api';
const SKYPACK_API = 'https://api.skypack.dev/v1';

interface JSDelivrFile {
  name: string;
  hash: string;
  time: string;
  size: number;
}

interface JSDelivrFlatResponse {
  files: JSDelivrFile[];
}

interface UnpkgFile {
  path: string;
  size: number;
  files?: UnpkgFile[];
}

// --- Utilities ---

const fetchWithRetry = async (url: string, retries = 3): Promise<Response> => {
  for (let i = 0; i < retries; i++) {
    try {
      const res = await fetch(url);
      if (res.status === 429) { // Rate limit
         await new Promise(r => setTimeout(r, 1000 * (i + 1)));
         continue;
      }
      return res;
    } catch (e) {
      if (i === retries - 1) throw e;
      await new Promise(r => setTimeout(r, 500));
    }
  }
  throw new Error('Max retries reached');
};

export const cleanPackageName = (urlOrName: string): string => {
  if (!urlOrName) return '';
  let name = urlOrName.trim();
  if (name.startsWith('https://www.npmjs.com/package/')) {
    name = name.replace('https://www.npmjs.com/package/', '');
  }
  // Remove potential trailing slashes or query params
  name = name.split('?')[0].replace(/\/$/, '');
  return name;
};

const countUnpkgFiles = (file: UnpkgFile): { count: number; size: number } => {
  if (!file.files) {
    return { count: 1, size: file.size };
  }
  return file.files.reduce(
    (acc, f) => {
      const res = countUnpkgFiles(f);
      return { count: acc.count + res.count, size: acc.size + res.size };
    },
    { count: 0, size: 0 }
  );
};

const normalizeRepoUrl = (url: string): string | undefined => {
    if (!url) return undefined;
    let clean = url.replace(/^git\+/, '').replace(/^git:\/\//, 'https://').replace(/\.git$/, '');
    if (clean.startsWith('github.com')) clean = `https://${clean}`;
    return clean.startsWith('http') ? clean : undefined;
};

const getBundleSize = async (pkgName: string, version: string): Promise<number> => {
    try {
        // Use version if available, otherwise latest
        const v = version || 'latest';
        const res = await fetchWithRetry(`${BUNDLEPHOBIA_API}/size?package=${pkgName}@${v}`, 1);
        if (res.ok) {
            const data = await res.json();
            return data.gzip || 0;
        }
    } catch (e) {
        // Bundlephobia often fails or times out for new/unpopular packages
    }
    return 0;
};

const getSkypackData = async (pkgName: string): Promise<{ isModule: boolean, isDeprecated: boolean }> => {
    try {
        const res = await fetchWithRetry(`${SKYPACK_API}/package/${pkgName}`, 1);
        if (res.ok) {
            const data = await res.json();
            // Skypack logic: Check if it's a package, not deprecated, and has ESM characteristics
            return {
                isModule: data.isPackage && !data.isDeprecated && (data.isExportMode || data.hasTypes || data.isModule), 
                isDeprecated: data.isDeprecated
            };
        }
    } catch (e) {
        // Ignore skypack errors to avoid failing enrichment
    }
    return { isModule: false, isDeprecated: false };
}

// --- Main Enrichment ---

export const enrichPackage = async (row: PackageRow): Promise<Partial<PackageRow>> => {
  const pkgName = cleanPackageName(row.package_name || row.npm_url);
  
  if (!pkgName || pkgName === '-' || pkgName.startsWith('-')) {
    throw new Error('Invalid package name');
  }

  try {
    // 1. Fetch Metadata from NPM Registry
    const registryRes = await fetchWithRetry(`${REGISTRY_BASE}/${pkgName}`);

    if (!registryRes.ok) {
       if (registryRes.status === 404) throw new Error('Package not found (404)');
       if (registryRes.status === 405) throw new Error('Method Not Allowed');
       throw new Error(`Registry Error: ${registryRes.status}`);
    }

    const metadata = await registryRes.json();
    const latestVersion = metadata['dist-tags']?.latest;
    
    if (!latestVersion) {
        throw new Error('No latest version tag found');
    }

    const versionData = metadata.versions?.[latestVersion] || {};
    
    // Extract time safely
    let publishedAt = '';
    if (metadata.time) {
      publishedAt = metadata.time[latestVersion] || metadata.time.modified || metadata.time.created || '';
    }
    
    // Extract maintainers safely
    let maintainers: string[] = [];
    if (versionData.maintainers && Array.isArray(versionData.maintainers)) {
        maintainers = versionData.maintainers.map((m: any) => typeof m === 'string' ? m : m.name);
    } else if (metadata.maintainers && Array.isArray(metadata.maintainers)) {
        maintainers = metadata.maintainers.map((m: any) => typeof m === 'string' ? m : m.name);
    }

    // Fallback to author if no maintainers
    if (maintainers.length === 0) {
        const author = versionData.author || metadata.author;
        if (author) {
            maintainers.push(typeof author === 'string' ? author : author.name);
        }
    }
    
    // Remove duplicates and empty strings
    maintainers = [...new Set(maintainers.filter(Boolean))];

    // Extract dependencies keys for indexing
    const dependenciesList = versionData.dependencies ? Object.keys(versionData.dependencies) : [];

    // Extract Repository URL
    let repoUrl = undefined;
    if (versionData.repository) {
        repoUrl = normalizeRepoUrl(typeof versionData.repository === 'string' ? versionData.repository : versionData.repository.url);
    } else if (metadata.repository) {
        repoUrl = normalizeRepoUrl(typeof metadata.repository === 'string' ? metadata.repository : metadata.repository.url);
    }

    // Identify Entrypoints
    const entrypoints: string[] = [];
    if (versionData.main) entrypoints.push(versionData.main);
    if (versionData.module) entrypoints.push(versionData.module);
    if (versionData.types) entrypoints.push(versionData.types);
    if (versionData.bin) {
        if (typeof versionData.bin === 'string') entrypoints.push(versionData.bin);
        else if (typeof versionData.bin === 'object') entrypoints.push(...Object.values(versionData.bin as Record<string, string>));
    }
    const uniqueEntrypoints = [...new Set(entrypoints.map(e => {
        const clean = e.startsWith('./') ? e.slice(2) : e;
        return clean.startsWith('/') ? clean.slice(1) : clean;
    }))];

    // Basic Update Object
    const updates: Partial<PackageRow> = {
      version: latestVersion,
      author_name: maintainers[0] || 'Unknown', 
      maintainers: maintainers,
      dependencies_list: dependenciesList,
      repository_url: repoUrl,
      entrypoints: uniqueEntrypoints,
      description: versionData.description || metadata.description || '',
      keywords: Array.isArray(versionData.keywords) ? versionData.keywords.join(', ') : (metadata.keywords?.join(', ') || ''),
      latest_release_published_at: publishedAt,
      dependencies: dependenciesList.length,
      package_name: metadata.name,
      npm_url: `https://www.npmjs.com/package/${metadata.name}`,
      license: versionData.license || metadata.license || '',
    };

    // 2. Parallel Fetch for Files, BundleSize, and Skypack
    // We use individual try/catch blocks inside Promise.all to prevent one failure from stopping others
    const [fileStats, bundleSize, skypackData] = await Promise.all([
        // File Stats (JSDelivr/Unpkg)
        (async () => {
            try {
                const jsDelivrRes = await fetchWithRetry(`${JSDELIVR_BASE}/${pkgName}@${latestVersion}/flat`);
                if (jsDelivrRes.ok) {
                    const flatData: JSDelivrFlatResponse = await jsDelivrRes.json();
                    return {
                        files: flatData.files.length,
                        size: flatData.files.reduce((acc, file) => acc + file.size, 0)
                    };
                }
            } catch (e) {
                try {
                    const unpkgRes = await fetchWithRetry(`${UNPKG_BASE}/${pkgName}@${latestVersion}/?meta`);
                    if (unpkgRes.ok) {
                        const unpkgData: UnpkgFile = await unpkgRes.json();
                        const { count, size } = countUnpkgFiles(unpkgData);
                        return { files: count, size: size };
                    }
                } catch (e2) { /* ignore */ }
            }
            return { files: 0, size: 0 };
        })(),
        // Bundle Size
        getBundleSize(pkgName, latestVersion),
        // Skypack Data (Robust check)
        getSkypackData(pkgName)
    ]);

    updates.file_number = fileStats.files;
    updates.unpacked_size = fileStats.size;
    updates.install_size = bundleSize;
    // Determine ESM based on Package.json OR Skypack
    updates.is_esm = skypackData.isModule || !!versionData.module || versionData.type === 'module';

    return updates;

  } catch (error: any) {
    throw new Error(error.message || 'Unknown Error');
  }
};

// --- API Functions ---

export const fetchPackageFiles = async (
  pkgName: string,
  version: string
): Promise<JSDelivrFile[]> => {
  const res = await fetchWithRetry(`${JSDELIVR_BASE}/${pkgName}@${version}/flat`);
  if (!res.ok) throw new Error('Failed to fetch file list');
  const data: JSDelivrFlatResponse = await res.json();
  return data.files;
};

export const fetchFileContent = async (
  pkgName: string,
  version: string,
  path: string
): Promise<string> => {
  const cleanPath = path.startsWith('/') ? path.slice(1) : path;
  const res = await fetchWithRetry(`${JSDELIVR_CDN}/${pkgName}@${version}/${cleanPath}`);
  if (!res.ok) throw new Error('Failed to fetch content');
  return await res.text();
};

export const fetchDependencies = async (
  pkgName: string
): Promise<Record<string, string>> => {
  const res = await fetchWithRetry(`${REGISTRY_BASE}/${pkgName}/latest`);
  if (!res.ok) throw new Error('Failed to fetch dependencies');
  const data = await res.json();
  return data.dependencies || {};
};

// --- Deep Analysis Functions ---

export const analyzeExports = async (
  pkgName: string,
  version: string
): Promise<{
  exportTypes: string[];
  entryPoints: Record<string, string>;
  moduleFormat: 'esm' | 'cjs' | 'umd' | 'mixed';
}> => {
  try {
    const pkgJson = await fetchFileContent(pkgName, version, 'package.json');
    const pkg = JSON.parse(pkgJson);
    
    const exportTypes: string[] = [];
    const entryPoints: Record<string, string> = {};
    
    if (pkg.main) {
      entryPoints.main = pkg.main;
      exportTypes.push('commonjs');
    }
    
    if (pkg.module) {
      entryPoints.module = pkg.module;
      exportTypes.push('esm');
    }
    
    if (pkg.browser) {
      entryPoints.browser = typeof pkg.browser === 'string' ? pkg.browser : 'browser-field';
      exportTypes.push('browser');
    }
    
    if (pkg.exports) {
      entryPoints.exports = JSON.stringify(pkg.exports);
      exportTypes.push('exports-field');
    }
    
    // Determine module format
    let moduleFormat: 'esm' | 'cjs' | 'umd' | 'mixed' = 'cjs';
    if (pkg.type === 'module') {
      moduleFormat = 'esm';
    } else if (pkg.module && pkg.main) {
      moduleFormat = 'mixed';
    } else if (pkg.browser) {
      moduleFormat = 'umd';
    }
    
    return {
      exportTypes,
      entryPoints,
      moduleFormat,
    };
  } catch (error) {
    return {
      exportTypes: [],
      entryPoints: {},
      moduleFormat: 'cjs',
    };
  }
};

export const analyzePackageStructure = async (
  pkgName: string,
  version: string
): Promise<{
  languages: string[];
  frameworks: string[];
  hasTests: boolean;
  hasTypes: boolean;
}> => {
  const files = await fetchPackageFiles(pkgName, version);
  
  const languages = new Set<string>();
  const frameworks = new Set<string>();
  
  // Detect languages
  if (files.some(f => f.name.endsWith('.ts') || f.name.endsWith('.tsx'))) languages.add('TypeScript');
  if (files.some(f => f.name.endsWith('.js') || f.name.endsWith('.mjs'))) languages.add('JavaScript');
  if (files.some(f => f.name.endsWith('.py'))) languages.add('Python');
  if (files.some(f => f.name.endsWith('.rs'))) languages.add('Rust');
  if (files.some(f => f.name.endsWith('.go'))) languages.add('Go');
  
  // Detect frameworks from file patterns
  const fileNames = files.map(f => f.name.toLowerCase());
  if (fileNames.some(n => n.includes('react') || n.endsWith('.jsx') || n.endsWith('.tsx'))) frameworks.add('React');
  if (fileNames.some(n => n.includes('vue') || n.endsWith('.vue'))) frameworks.add('Vue');
  if (fileNames.some(n => n.includes('angular'))) frameworks.add('Angular');
  if (fileNames.some(n => n.endsWith('.svelte'))) frameworks.add('Svelte');
  if (fileNames.some(n => n.includes('tailwind'))) frameworks.add('Tailwind');
  
  const hasTests = fileNames.some(n => n.includes('test') || n.includes('spec'));
  const hasTypes = files.some(f => f.name.endsWith('.d.ts'));

  return {
    languages: Array.from(languages),
    frameworks: Array.from(frameworks),
    hasTests,
    hasTypes,
  };
};

export const analyzeDependencyGraph = async (
  pkgName: string,
  maxDepth: number = 3
): Promise<{
  directDependencies: number;
  totalDependencies: number;
  maxDepth: number;
  circularDependencies: string[][];
  duplicatedDependencies: Record<string, number>;
}> => {
  const visited = new Map<string, { depth: number; parents: string[] }>();
  const circular: string[][] = [];
  const duplicates = new Map<string, number>();
  
  async function traverse(
    name: string,
    currentDepth: number,
    parentChain: string[]
  ): Promise<void> {
    if (currentDepth > maxDepth) return;
    
    // Check for circular dependency
    if (parentChain.includes(name)) {
      circular.push([...parentChain, name]);
      return;
    }
    
    // Track duplicates
    const count = duplicates.get(name) || 0;
    duplicates.set(name, count + 1);
    
    // Track visited
    if (visited.has(name)) {
      const existing = visited.get(name)!;
      existing.parents.push(...parentChain);
      return;
    }
    
    visited.set(name, { depth: currentDepth, parents: [...parentChain] });
    
    try {
      const deps = await fetchDependencies(name);
      const depNames = Object.keys(deps);
      
      for (const dep of depNames.slice(0, 20)) { // Limit width for performance
        await traverse(dep, currentDepth + 1, [...parentChain, name]);
      }
    } catch (error) {
      // Silently fail on individual dependencies
    }
  }
  
  await traverse(pkgName, 0, []);
  
  // Find direct dependencies
  const directDeps = await fetchDependencies(pkgName);
  
  return {
    directDependencies: Object.keys(directDeps).length,
    totalDependencies: visited.size,
    maxDepth: Math.max(...Array.from(visited.values()).map(v => v.depth), 0),
    circularDependencies: circular,
    duplicatedDependencies: Object.fromEntries(
      Array.from(duplicates.entries()).filter(([, count]) => count > 1)
    ),
  };
};
