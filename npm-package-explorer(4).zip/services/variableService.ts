
import { GithubConfig, UserVariable } from '../types';
import { getFileContent, updateFile } from './githubService';
import { csvToJson, jsonToCsv } from '../utils/csv';

// Defines the storage format where value is split
interface ScatteredVariableRow {
    id: string;
    key: string;
    v_part1: string; // First half of base64
    v_part2: string; // Second half of base64
    updatedAt: string;
}

export const variableService = {
    
    async loadVariables(config: GithubConfig, path: string): Promise<UserVariable[]> {
        try {
            const csvContent = await getFileContent(config, path);
            if (!csvContent) return [];
            
            const rows = csvToJson<ScatteredVariableRow>(csvContent);
            
            return rows.map(row => {
                const fullBase64 = (row.v_part1 || '') + (row.v_part2 || '');
                let value = '';
                try {
                     value = decodeURIComponent(escape(window.atob(fullBase64)));
                } catch (e) {
                    value = '**DECRYPTION_FAILED**';
                }
                
                return {
                    id: row.id,
                    key: row.key,
                    value: value,
                    updatedAt: row.updatedAt
                };
            });
        } catch (error) {
            console.error("Failed to load variables", error);
            return [];
        }
    },

    async saveVariables(config: GithubConfig, path: string, variables: UserVariable[]): Promise<void> {
        try {
            const scatteredRows: ScatteredVariableRow[] = variables.map(v => {
                const base64 = window.btoa(unescape(encodeURIComponent(v.value)));
                const midpoint = Math.ceil(base64.length / 2);
                
                return {
                    id: v.id,
                    key: v.key,
                    v_part1: base64.slice(0, midpoint),
                    v_part2: base64.slice(midpoint),
                    updatedAt: v.updatedAt || new Date().toISOString()
                };
            });
            
            const csvContent = jsonToCsv(scatteredRows);
            await updateFile(config, path, csvContent, "Update Environment Variables");
        } catch (error) {
            console.error("Failed to save variables", error);
            throw new Error("Failed to persist variables to GitHub.");
        }
    }
};
