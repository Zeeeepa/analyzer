


import { openDB, IDBPDatabase } from 'idb';

const CACHE_DB_NAME = 'RepoCacheDB';
const CACHE_STORE_NAME = 'github_cache';
const CACHE_VERSION = 1;

interface CacheEntry {
    key: string;
    value: any;
    timestamp: number;
    sha?: string;
    metadata?: any;
}

class SmartCacheService {
    private dbPromise: Promise<IDBPDatabase<any>>;
    private memoryCache: Map<string, CacheEntry> = new Map();
    private maxMemoryEntries = 100; // Increased memory limit for hot files

    constructor() {
        this.dbPromise = openDB(CACHE_DB_NAME, CACHE_VERSION, {
            upgrade(db) {
                if (!db.objectStoreNames.contains(CACHE_STORE_NAME)) {
                    const store = db.createObjectStore(CACHE_STORE_NAME, { keyPath: 'key' });
                    store.createIndex('timestamp', 'timestamp');
                }
            },
        });
    }

    /**
     * Retrieves an item from cache. 
     * If a SHA is provided, it validates freshness against the stored SHA.
     */
    async get<T>(key: string, sha?: string): Promise<T | null> {
        // 1. Check Memory (Fastest)
        if (this.memoryCache.has(key)) {
            const entry = this.memoryCache.get(key)!;
            // If SHA validation is requested and fails, invalidate
            if (sha && entry.sha && entry.sha !== sha) {
                this.memoryCache.delete(key);
                return null; 
            }
            return entry.value as T;
        }

        // 2. Check IndexedDB (Persistent)
        try {
            const db = await this.dbPromise;
            const entry = await db.get(CACHE_STORE_NAME, key) as CacheEntry;
            
            if (entry) {
                // SHA Validation
                if (sha && entry.sha && entry.sha !== sha) {
                    await db.delete(CACHE_STORE_NAME, key);
                    return null;
                }
                
                // Hydrate memory cache for next time (LRU-ish)
                this.updateMemoryCache(key, entry);
                return entry.value as T;
            }
        } catch (e) {
            console.warn("Cache read error", e);
        }

        return null;
    }

    /**
     * Retrieves multiple items from cache in a single transaction.
     * Returns a map of Key -> Value for found items.
     */
    async getBatch<T>(keys: string[]): Promise<Map<string, T>> {
        const result = new Map<string, T>();
        const missingKeys: string[] = [];

        // Check Memory first
        keys.forEach(key => {
            if (this.memoryCache.has(key)) {
                result.set(key, this.memoryCache.get(key)!.value as T);
            } else {
                missingKeys.push(key);
            }
        });

        if (missingKeys.length === 0) return result;

        try {
            const db = await this.dbPromise;
            const tx = db.transaction(CACHE_STORE_NAME, 'readonly');
            const store = tx.objectStore(CACHE_STORE_NAME);

            await Promise.all(missingKeys.map(async (key) => {
                const entry = await store.get(key) as CacheEntry;
                if (entry) {
                    this.updateMemoryCache(key, entry);
                    result.set(key, entry.value as T);
                }
            }));
            
            await tx.done;
        } catch (e) {
            console.warn("Batch cache read error", e);
        }

        return result;
    }

    /**
     * Saves an item to cache.
     */
    async set(key: string, value: any, sha?: string): Promise<void> {
        const entry: CacheEntry = {
            key,
            value,
            timestamp: Date.now(),
            sha
        };

        this.updateMemoryCache(key, entry);

        // Update DB
        try {
            const db = await this.dbPromise;
            await db.put(CACHE_STORE_NAME, entry);
        } catch (e) {
            console.warn("Cache write error", e);
        }
    }

    /**
     * Saves multiple items to cache in a single transaction.
     */
    async setBatch(items: { key: string; value: any; sha?: string }[]): Promise<void> {
        try {
            const db = await this.dbPromise;
            const tx = db.transaction(CACHE_STORE_NAME, 'readwrite');
            const store = tx.objectStore(CACHE_STORE_NAME);

            const timestamp = Date.now();

            await Promise.all(items.map(async (item) => {
                const entry: CacheEntry = {
                    key: item.key,
                    value: item.value,
                    sha: item.sha,
                    timestamp
                };
                this.updateMemoryCache(item.key, entry);
                await store.put(entry);
            }));

            await tx.done;
        } catch (e) {
            console.error("Batch cache write error", e);
        }
    }

    /**
     * Clear all cache entries.
     */
    async clear(): Promise<void> {
        this.memoryCache.clear();
        const db = await this.dbPromise;
        await db.clear(CACHE_STORE_NAME);
    }

    private updateMemoryCache(key: string, entry: CacheEntry) {
        if (this.memoryCache.size >= this.maxMemoryEntries) {
            const firstKey = this.memoryCache.keys().next().value;
            if (firstKey) this.memoryCache.delete(firstKey);
        }
        this.memoryCache.set(key, entry);
    }
}

export const cacheService = new SmartCacheService();
