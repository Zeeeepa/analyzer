
import { GithubConfig, GithubRepo, RepoMetadata } from '../types';
import { getRepoTree } from './githubService';

// A list of common code file extensions for analysis.
const CODE_EXTENSIONS = new Set([
    'js', 'ts', 'jsx', 'tsx', 'py', 'java', 'c', 'cpp', 'h', 'cs', 'go', 'rb', 'php',
    'swift', 'kt', 'rs', 'scala', 'm', 'sh', 'ps1', 'json', 'yml', 'yaml', 'xml', 
    'html', 'css', 'scss', 'less', 'sql'
]);


/**
 * Analyzes a GitHub repository to extract metadata like file counts and lines of code.
 * Uses a fallback mechanism for Lines of Code based on repo size if tree fetch fails.
 *
 * @param config The GitHub configuration containing the auth token.
 * @param repo The repository object to analyze.
 * @returns A promise that resolves to the repository's metadata.
 */
export async function analyzeRepo(config: GithubConfig, repo: GithubRepo): Promise<RepoMetadata> {
    const repoConfig: GithubConfig = {
        token: config.token,
        owner: repo.owner.login,
        repo: repo.name,
    };

    // Estimating lines of code based on repository size.
    // Average of 30 lines of code per KB of repo size.
    const estimatedLinesOfCode = repo.size > 0 ? Math.round(repo.size * 30) : 0;

    try {
        // Pass default_branch if available to save an API call
        const tree = await getRepoTree(repoConfig, repo.default_branch);
        
        if (!tree) {
            // If tree fetch fails (empty or quota), return estimated LOC so card isn't empty
            return { fileCount: 0, codeFileCount: 0, linesOfCode: estimatedLinesOfCode };
        }

        const files = tree.filter(item => item.type === 'blob');
        const fileCount = files.length;
        
        const codeFileCount = files.filter(file => {
            const extension = file.path.split('.').pop()?.toLowerCase();
            return extension && CODE_EXTENSIONS.has(extension);
        }).length;

        return {
            fileCount,
            codeFileCount,
            linesOfCode: estimatedLinesOfCode,
        };

    } catch (error) {
        console.error(`Failed to analyze repo ${repo.full_name}:`, error);
        // Return zeroed file counts but estimated LOC on failure to avoid breaking the UI.
        return { fileCount: 0, codeFileCount: 0, linesOfCode: estimatedLinesOfCode };
    }
}
