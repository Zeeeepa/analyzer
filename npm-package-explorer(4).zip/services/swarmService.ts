
import { GoogleGenAI } from "@google/genai";
import { AgentNode, SwarmState, StudioResource } from "../types";
import { v4 as uuidv4 } from 'uuid';

// --- Configuration ---
const MAX_PARALLEL_AGENTS = 5; // Browser limitation safety
const MODEL_NAME = "gemini-2.5-flash"; // Fast thinking model

// --- Swarm Orchestrator ---

export class SwarmOrchestrator {
    private ai: GoogleGenAI;
    private state: SwarmState;
    private listeners: ((state: SwarmState) => void)[] = [];
    private resourceContext: StudioResource[] = [];

    constructor(apiKey: string) {
        this.ai = new GoogleGenAI({ apiKey });
        this.state = {
            agents: {},
            rootAgentId: 'overseer',
            activeTaskCount: 0
        };
        // Initialize Overseer
        this.createAgent('overseer', undefined, 'overseer', 'System Overseer');
    }

    public setResources(resources: StudioResource[]) {
        this.resourceContext = resources;
    }

    public subscribe(listener: (state: SwarmState) => void) {
        this.listeners.push(listener);
        listener(this.state);
        return () => {
            this.listeners = this.listeners.filter(l => l !== listener);
        };
    }

    private updateState(updater: (prev: SwarmState) => void) {
        updater(this.state);
        this.listeners.forEach(l => l({ ...this.state })); // Broadcast copy
    }

    private createAgent(id: string, parentId: string | undefined, role: AgentNode['role'], name: string) {
        this.updateState(state => {
            state.agents[id] = {
                id,
                parentId,
                name,
                role,
                status: 'idle',
                depth: parentId ? (state.agents[parentId].depth + 1) : 0,
                logs: [],
                children: []
            };
            if (parentId && state.agents[parentId]) {
                state.agents[parentId].children.push(id);
            }
        });
        return id;
    }

    private log(agentId: string, message: string) {
        this.updateState(state => {
            if (state.agents[agentId]) {
                state.agents[agentId].logs.push(`[${new Date().toLocaleTimeString()}] ${message}`);
            }
        });
    }

    private setAgentStatus(agentId: string, status: AgentNode['status'], task?: string) {
        this.updateState(state => {
            if (state.agents[agentId]) {
                state.agents[agentId].status = status;
                if (task) state.agents[agentId].currentTask = task;
            }
        });
    }

    // --- Core Intelligence ---

    public async processQuery(query: string) {
        const rootId = 'overseer';
        this.setAgentStatus(rootId, 'thinking', `Analyzing request: "${query}"`);
        
        try {
            // 1. Root Agent analyzes intent and decomposition
            const decomposition = await this.decomposeTask(query);
            this.log(rootId, `Decomposed into ${decomposition.subtasks.length} subtasks.`);

            // 2. Spawn Sub-Agents
            await this.executeParallelTasks(rootId, decomposition.subtasks);

            this.setAgentStatus(rootId, 'completed', 'All tasks finished.');
        } catch (e: any) {
            this.setAgentStatus(rootId, 'failed', e.message);
            this.log(rootId, `Critical Failure: ${e.message}`);
        }
    }

    private async decomposeTask(query: string): Promise<{ subtasks: { description: string, role: AgentNode['role'], targetResources?: string[] }[] }> {
        // Construct context summary
        const resourceSummary = this.resourceContext.map(r => `- [${r.type}] ${r.name} (ID: ${r.id})`).join('\n').slice(0, 5000); // Limit context

        const prompt = `
        You are the Overseer of a software analysis swarm.
        
        User Query: "${query}"
        
        Available Resources (Snippet):
        ${resourceSummary}
        
        Goal: Break this query down into parallel execution tasks for sub-agents.
        If the user wants to analyze many repos, batch them.
        
        Return JSON structure:
        {
          "subtasks": [
            { "description": "Analyze repo X logic", "role": "researcher", "targetResources": ["resource_id"] }
          ]
        }
        `;

        const response = await this.ai.models.generateContent({
            model: MODEL_NAME,
            contents: prompt,
            config: { responseMimeType: "application/json" }
        });

        return JSON.parse(response.text);
    }

    private async executeParallelTasks(parentId: string, tasks: any[]) {
        const chunks = [];
        for (let i = 0; i < tasks.length; i += MAX_PARALLEL_AGENTS) {
            chunks.push(tasks.slice(i, i + MAX_PARALLEL_AGENTS));
        }

        for (const chunk of chunks) {
            await Promise.all(chunk.map(async (task: any, idx: number) => {
                const agentId = uuidv4();
                this.createAgent(agentId, parentId, task.role, `Agent-${parentId.slice(0,4)}-${idx}`);
                
                await this.runWorkerAgent(agentId, task);
            }));
        }
    }

    private async runWorkerAgent(agentId: string, task: any) {
        this.setAgentStatus(agentId, 'working', task.description);
        this.log(agentId, "Starting task execution...");

        try {
            // Retrieve specific resource details if targeted
            let contextData = "";
            if (task.targetResources && task.targetResources.length > 0) {
                const targets = this.resourceContext.filter(r => task.targetResources.includes(r.id));
                contextData = JSON.stringify(targets.map(t => ({ name: t.name, desc: t.description, metadata: t.metadata })));
            }

            const prompt = `
            You are a sub-agent.
            Task: ${task.description}
            Context Data: ${contextData.slice(0, 10000)}
            
            Perform the analysis or action. If the task is too complex, you can request sub-delegation (simulated here by just solving it).
            Provide a concise result.
            `;

            const response = await this.ai.models.generateContent({
                model: MODEL_NAME,
                contents: prompt
            });

            const result = response.text;
            this.log(agentId, `Result: ${result.slice(0, 100)}...`);
            
            this.updateState(state => {
                if(state.agents[agentId]) state.agents[agentId].result = result;
            });
            
            this.setAgentStatus(agentId, 'completed');
            
            // recursive check? For now, 1 level deep is implemented in this snippet, 
            // but the architecture allows calling executeParallelTasks(agentId, ...) here if the model requested it.

        } catch (e: any) {
            this.log(agentId, `Error: ${e.message}`);
            this.setAgentStatus(agentId, 'failed');
        }
    }
}
