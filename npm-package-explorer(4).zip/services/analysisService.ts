import { SymbolData } from '../types';

const findBodyEnd = (lines: string[], startLineIndex: number): number => {
  let braceCount = 0;
  let foundStart = false;
  
  for (let i = startLineIndex; i < lines.length; i++) {
    const line = lines[i];
    const open = (line.match(/{/g) || []).length;
    const close = (line.match(/}/g) || []).length;
    
    if (open > 0) foundStart = true;
    braceCount += open - close;
    
    if (foundStart && braceCount <= 0) return i;
    if (i - startLineIndex > 500) return i; 
  }
  return lines.length - 1;
};

// Advanced Analysis using ts-morph (Dynamic Import)
export const analyzeWithTsMorph = async (code: string): Promise<SymbolData[]> => {
    try {
        const { Project } = await import('ts-morph');
        // ts-morph in browser requires a virtual file system. 
        // We useInMemoryFileSystem which is standard for web usage.
        const project = new Project({ useInMemoryFileSystem: true });
        
        // Create a source file in the virtual fs
        const sourceFile = project.createSourceFile('temp.ts', code);
        const symbols: SymbolData[] = [];

        sourceFile.getClasses().forEach(c => {
            symbols.push({ type: 'class', name: c.getName() || 'AnonymousClass', line: c.getStartLineNumber() });
        });

        sourceFile.getFunctions().forEach(f => {
            const name = f.getName() || 'AnonymousFunc';
            const params = f.getParameters().map(p => p.getName()).join(', ');
            symbols.push({ type: 'func', name, line: f.getStartLineNumber(), args: params });
        });

        sourceFile.getInterfaces().forEach(i => {
            symbols.push({ type: 'interface', name: i.getName(), line: i.getStartLineNumber() });
        });

        sourceFile.getVariableStatements().forEach(v => {
            v.getDeclarations().forEach(d => {
                symbols.push({ type: 'var', name: d.getName(), line: d.getStartLineNumber() });
            });
        });

        return symbols;
    } catch (e) {
        console.warn("TS-Morph analysis failed/unavailable, falling back to regex.", e);
        return extractSymbols(code, false);
    }
};

export const extractSymbols = (code: string, isDeclarationFile: boolean = false): SymbolData[] => {
  const symbols: SymbolData[] = [];
  const lines = code.split('\n');
  const allDefinedNames = new Set<string>();
  
  lines.forEach((line, i) => {
      const lineNum = i + 1;
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('//') || trimmed.startsWith('*')) return;

      // Support 'export declare const', 'declare const', 'export const', 'const'
      const declPrefix = isDeclarationFile ? '(?:export\\s+)?(?:declare\\s+)?' : '(?:export\\s+)?';

      // 1. Class
      const classMatch = trimmed.match(new RegExp(`^${declPrefix}(?:abstract\\s+)?class\\s+([A-Z][a-zA-Z0-9_$]*)`));
      if (classMatch) {
          const name = classMatch[1];
          allDefinedNames.add(name);
          symbols.push({ type: 'class', name, line: lineNum });
          return;
      }

      // 2. Function
      const funcMatch = trimmed.match(new RegExp(`^${declPrefix}(?:async\\s+)?function\\s+([a-zA-Z0-9_$]+)\\s*\\(([^)]*)\\)`));
      if (funcMatch) {
          const name = funcMatch[1];
          const args = funcMatch[2].trim();
          allDefinedNames.add(name);
          symbols.push({ type: 'func', name, line: lineNum, args });
          return;
      }

      // 3. Variable / Arrow Func
      const varMatch = trimmed.match(new RegExp(`^${declPrefix}(?:const|let|var)\\s+([a-zA-Z0-9_$]+)\\s*=\\s*(?:async\\s*)?(\\([^)]*\\)|[a-zA-Z0-9_$]+)\\s*=>`));
      if (varMatch) {
           const name = varMatch[1];
           let args = varMatch[2].trim();
           if (args.startsWith('(') && args.endsWith(')')) args = args.slice(1, -1);
           allDefinedNames.add(name);
           symbols.push({ type: 'func', name, line: lineNum, args });
           return;
      }

      // Destructuring
      const destructMatch = trimmed.match(new RegExp(`^${declPrefix}(?:const|let|var)\\s+\\{([^}]+)\\}\\s*=`));
      if (destructMatch) {
          const vars = destructMatch[1].split(',').map(v => v.trim().split(':')[0].trim());
          vars.forEach(v => {
              if (v) {
                  allDefinedNames.add(v);
                  symbols.push({ type: 'var', name: v, line: lineNum });
              }
          });
          return;
      }

      // Simple Variable
      const simpleVar = trimmed.match(new RegExp(`^${declPrefix}(?:const|let|var)\\s+([a-zA-Z0-9_$]+)(?:\\s*[:=])`));
      if (simpleVar && !varMatch) {
           const name = simpleVar[1];
           allDefinedNames.add(name);
           symbols.push({ type: 'var', name, line: lineNum });
           return;
      }

      // 4. Types / Interfaces (TS)
      const typeMatch = trimmed.match(new RegExp(`^${declPrefix}(?:type|interface)\\s+([A-Z][a-zA-Z0-9_$]*)`));
      if (typeMatch) {
          symbols.push({ type: trimmed.includes('interface') ? 'interface' : 'type', name: typeMatch[1], line: lineNum });
          return;
      }

      // 5. Namespace / Module (d.ts)
      const nsMatch = trimmed.match(new RegExp(`^${declPrefix}(?:namespace|module)\\s+([a-zA-Z0-9_$.]+)`));
      if (nsMatch) {
          symbols.push({ type: 'namespace', name: nsMatch[1], line: lineNum });
          return;
      }

      // 6. Method
      if (!isDeclarationFile && !/^(if|for|while|switch|catch|return|throw|try|finally|else|console|module|import|from)\b/.test(trimmed)) {
           const methodMatch = trimmed.match(/^(?:static\s+|async\s+|get\s+|set\s+)*([a-zA-Z0-9_$]+)\s*(?:<[^>]*>)?\s*\(([^)]*)\)/);
           if (methodMatch) {
               const name = methodMatch[1];
               if (name !== 'function' && name.length > 1) {
                   symbols.push({ type: 'method', name, line: lineNum, args: methodMatch[2].trim() });
               }
           }
      }
  });

  // Pass 2: Dependencies (skip for d.ts generally as it's just decls)
  if (!isDeclarationFile) {
      symbols.forEach((sym, idx) => {
        if (sym.type === 'func' || sym.type === 'method' || sym.type === 'class') {
            const startLine = sym.line - 1;
            const endLine = findBodyEnd(lines, startLine);
            const bodyText = lines.slice(startLine, endLine + 1).join('\n');
            
            const used: Set<string> = new Set();
            allDefinedNames.forEach(definedName => {
                if (definedName === sym.name) return; 
                const regex = new RegExp(`(?<![.\\w])\\b${definedName}\\b(?!\\s*:)`);
                if (regex.test(bodyText)) {
                    used.add(definedName);
                }
            });
            
            if (used.size > 0) {
                sym.usage = Array.from(used);
            }
        }
      });
  }
  
  return symbols;
};

export const generateMermaidGraph = (symbols: SymbolData[]): string => {
    let graph = 'graph TD;\n';
    const nodes = new Set<string>();
    const edges = new Set<string>();
    
    symbols.forEach(s => {
        // Sanitize IDs
        const nodeId = s.name.replace(/[^a-zA-Z0-9]/g, '_');
        if (!nodes.has(nodeId)) {
            let shape = `[${s.name}]`; // Default var/other
            if (s.type === 'class') shape = `([${s.name}])`; // stadium
            if (s.type === 'func' || s.type === 'method') shape = `{{${s.name}}}`; // hexagon
            if (s.type === 'interface') shape = `>${s.name}]`; // flag
            if (s.type === 'var') shape = `(${s.name})`; // rounded
            
            graph += `    ${nodeId}${shape};\n`;
            nodes.add(nodeId);
        }

        if (s.usage) {
            s.usage.forEach(u => {
                 const targetId = u.replace(/[^a-zA-Z0-9]/g, '_');
                 // Only link if we know the target or generic. 
                 const edgeKey = `${nodeId}->${targetId}`;
                 if (!edges.has(edgeKey) && nodeId !== targetId) {
                    graph += `    ${nodeId} --> ${targetId};\n`;
                    edges.add(edgeKey);
                 }
            });
        }
    });
    
    // Fallback if empty
    if (nodes.size === 0) return 'graph TD;\n    Start[Analysis] --> End[No Symbols Found];';
    
    return graph;
};