


import { GithubConfig, GithubRepo, GithubUser, DiffResult } from "../types";
import { cacheService } from "./cacheService";

const GITHUB_API_BASE_URL = 'https://api.github.com';

// Helper for UTF-8 safe Base64 encoding
export function utf8_to_b64(str: string) {
  return window.btoa(unescape(encodeURIComponent(str)));
}

// Helper for UTF-8 safe Base64 decoding
export function b64_to_utf8(str: string) {
  if (!str) return '';
  // Remove newlines and whitespace
  const cleanStr = str.replace(/[\s\n\r]/g, '');
  try {
      // Use TextDecoder for proper UTF-8 handling of multibyte characters
      const binaryString = window.atob(cleanStr);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      return new TextDecoder().decode(bytes);
  } catch (e) {
      console.error("Base64 decode failed:", e);
      return `[Error decoding file content: ${e instanceof Error ? e.message : 'Unknown error'}]`;
  }
}

async function githubApiRequest(token: string | undefined, endpoint: string, options: RequestInit = {}, isFullUrl: boolean = false) {
    const headers: any = {
        'Accept': 'application/vnd.github.v3+json',
        ...options.headers,
    };
    
    // Allow unauthenticated requests for public data if token is missing
    if (token) {
        headers['Authorization'] = `token ${token}`;
    }
    
    const url = isFullUrl ? endpoint : `${GITHUB_API_BASE_URL}${endpoint}`;
    const response = await fetch(url, { ...options, headers });

    if (!response.ok) {
        let errorMessage = 'No details';
        try {
             const errorData = await response.json();
             errorMessage = errorData.message || errorMessage;
        } catch {
             try { errorMessage = await response.text(); } catch {}
        }
        
        // Don't throw for 202 (stats computing)
        if (response.status === 202) return response;

        throw new Error(`GitHub API Error: ${response.status} ${response.statusText} - ${errorMessage}`);
    }

    return response;
}

export async function validateToken(token: string): Promise<string | null> {
    if (!token) return null; 
    try {
        const response = await githubApiRequest(token, '/user');
        const data = await response.json();
        return data.login; 
    } catch (error) {
        console.error("Token validation failed:", error);
        return null;
    }
}

export async function listAllUserRepos(token: string): Promise<GithubRepo[]> {
    if (!token) throw new Error("Token required for listing user repos");
    let allRepos: GithubRepo[] = [];
    let nextUrl: string | null = `${GITHUB_API_BASE_URL}/user/repos?type=owner&sort=updated&per_page=100`;

    while (nextUrl) {
        const response = await githubApiRequest(token, nextUrl, {}, true);
        const repos: GithubRepo[] = await response.json();
        allRepos = allRepos.concat(repos);

        const linkHeader = response.headers.get('Link');
        const nextLink = linkHeader?.split(',').find(s => s.includes('rel="next"'));
        
        if (nextLink) {
            nextUrl = nextLink.match(/<(.+)>/)?.[1] || null;
        } else {
            nextUrl = null;
        }
    }
    return allRepos;
}

export async function listUserRepos(token: string, username: string): Promise<GithubRepo[]> {
    if (!token) throw new Error("Token required for listing user repos");
    let allRepos: GithubRepo[] = [];
    let nextUrl: string | null = `${GITHUB_API_BASE_URL}/users/${username}/repos?sort=updated&per_page=100`;

    while (nextUrl) {
        const response = await githubApiRequest(token, nextUrl, {}, true);
        const repos: GithubRepo[] = await response.json();
        allRepos = allRepos.concat(repos);

        const linkHeader = response.headers.get('Link');
        const nextLink = linkHeader?.split(',').find(s => s.includes('rel="next"'));
        
        if (nextLink) {
            nextUrl = nextLink.match(/<(.+)>/)?.[1] || null;
        } else {
            nextUrl = null;
        }
    }
    return allRepos;
}

export async function listUserStarred(token: string, username: string): Promise<GithubRepo[]> {
    if (!token) throw new Error("Token required for listing starred repos");
    const response = await githubApiRequest(token, `/users/${username}/starred?sort=created&per_page=50`);
    return await response.json();
}

// Fetch raw blob content for large files
async function getBlobContent(token: string | undefined, owner: string, repo: string, sha: string): Promise<string | null> {
    try {
        const response = await githubApiRequest(token, `/repos/${owner}/${repo}/git/blobs/${sha}`);
        const text = await response.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch {
             return null;
        }

        if (data.encoding === 'base64' && data.content) {
            return b64_to_utf8(data.content);
        }
        return null;
    } catch (e) {
        console.error(`Failed to fetch blob ${sha}`, e);
        return null;
    }
}

export async function getFileContent(config: GithubConfig, path: string): Promise<string | null> {
    const { token, owner, repo } = config;
    const cacheKey = `content:${owner}/${repo}/${path}`;

    try {
        const cached = await cacheService.get<string>(cacheKey);
        if (cached) return cached;

        const encodedPath = path.split('/').map(encodeURIComponent).join('/');
        let data: any = null;
        let sha: string | undefined = undefined;

        try {
            const response = await githubApiRequest(token, `/repos/${owner}/${repo}/contents/${encodedPath}`);
            const text = await response.text();
            try { data = JSON.parse(text); } catch (e) { data = null; }
        } catch (e) {}

        if (data && !Array.isArray(data)) {
            if (data.encoding === 'base64' && data.content) {
                const content = b64_to_utf8(data.content);
                await cacheService.set(cacheKey, content, data.sha);
                return content;
            }
            if (data.sha) sha = data.sha;
        }

        if (!sha) {
            const tree = await getRepoTree(config);
            if (tree) {
                const item = tree.find(t => t.path === path);
                if (item?.sha) sha = item.sha;
            }
        }

        if (sha) {
             const content = await getBlobContent(token, owner, repo, sha);
             if (content) {
                 await cacheService.set(cacheKey, content, sha);
                 return content;
             }
        }

        return null;
    } catch (error) {
        if (error instanceof Error && error.message.includes('404')) {
            return null;
        }
        console.error(`Failed to get file '${path}':`, error);
        throw error;
    }
}

/**
 * Advanced Library Loading: Fetch multiple files in parallel with intelligent caching.
 * Used for hydration of the "Hot Context" for AI.
 */
export async function fetchFilesParallel(
    config: GithubConfig, 
    files: { path: string; sha?: string }[]
): Promise<Record<string, string>> {
    const { token, owner, repo } = config;
    const results: Record<string, string> = {};
    const toFetch: { path: string; sha?: string }[] = [];

    // 1. Check Cache in Batch
    const keys = files.map(f => `content:${owner}/${repo}/${f.path}`);
    const cachedMap = await cacheService.getBatch<string>(keys);

    files.forEach((f, idx) => {
        const key = keys[idx];
        const cached = cachedMap.get(key);
        // We could verify SHA here if we stored it with the value, 
        // but for speed we trust the batch get or if cacheService implemented internal SHA check
        if (cached) {
            results[f.path] = cached;
        } else {
            toFetch.push(f);
        }
    });

    // 2. Fetch Missing Files with Concurrency Limit
    if (toFetch.length > 0) {
        const CONCURRENCY_LIMIT = 5;
        const queue = [...toFetch];
        const batchUpdates: { key: string; value: any; sha?: string }[] = [];

        const worker = async () => {
            while (queue.length > 0) {
                const file = queue.shift();
                if (!file) break;

                try {
                    // Reuse getFileContent logic but avoid internal cache check as we already did it
                    // Directly fetch via blob if SHA known (faster), else content API
                    let content: string | null = null;
                    
                    if (file.sha) {
                        content = await getBlobContent(token, owner, repo, file.sha);
                    } else {
                        // Fallback to content API
                        const encodedPath = file.path.split('/').map(encodeURIComponent).join('/');
                        const res = await githubApiRequest(token, `/repos/${owner}/${repo}/contents/${encodedPath}`);
                        const data = await res.json();
                        if (data.encoding === 'base64' && data.content) {
                            content = b64_to_utf8(data.content);
                        }
                    }

                    if (content !== null) {
                        results[file.path] = content;
                        batchUpdates.push({
                            key: `content:${owner}/${repo}/${file.path}`,
                            value: content,
                            sha: file.sha
                        });
                    }
                } catch (e) {
                    console.warn(`Failed to parallel fetch ${file.path}`, e);
                }
            }
        };

        const workers = Array(Math.min(toFetch.length, CONCURRENCY_LIMIT)).fill(null).map(() => worker());
        await Promise.all(workers);

        // 3. Update Cache in Batch
        if (batchUpdates.length > 0) {
            await cacheService.setBatch(batchUpdates);
        }
    }

    return results;
}

async function getFileSha(config: GithubConfig, path: string): Promise<string | undefined> {
    const { token, owner, repo } = config;
    try {
        const encodedPath = path.split('/').map(encodeURIComponent).join('/');
        const response = await githubApiRequest(token, `/repos/${owner}/${repo}/contents/${encodedPath}`);
        const text = await response.text();
        const data = JSON.parse(text);
        return data.sha;
    } catch (error) {
         if (error instanceof Error && error.message.includes('404')) {
            return undefined;
        }
        throw error;
    }
}

export async function updateFile(config: GithubConfig, path: string, content: string, message: string): Promise<void> {
    const { token, owner, repo } = config;
    if (!token) throw new Error("Authentication required to update files");

    const sha = await getFileSha(config, path);
    const encodedPath = path.split('/').map(encodeURIComponent).join('/');

    const body = {
        message,
        content: utf8_to_b64(content), 
        sha,
    };

    await githubApiRequest(token, `/repos/${owner}/${repo}/contents/${encodedPath}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
    });
    
    const cacheKey = `content:${owner}/${repo}/${path}`;
    await cacheService.set(cacheKey, content); 
}

export async function getRepoDetails(token: string | undefined, owner: string, repo: string): Promise<any> {
    const response = await githubApiRequest(token, `/repos/${owner}/${repo}`);
    return response.json();
}

export async function getRepoTree(config: GithubConfig | string, repoArg?: string): Promise<{ path: string; type: string; size?: number; sha: string }[]> {
    let token, owner, repo;
    if (typeof config === 'string' && repoArg) {
         owner = config;
         repo = repoArg;
         token = undefined;
    } else {
        const c = config as GithubConfig;
        token = c.token;
        owner = c.owner;
        repo = c.repo;
    }

    const cacheKey = `tree:${owner}/${repo}:default`;

    try {
        const cached = await cacheService.get<{ path: string; type: string; size?: number; sha: string }[]>(cacheKey);
        if (cached) return cached;

        const repoDetails = await getRepoDetails(token, owner, repo);
        const targetBranch = repoDetails.default_branch;

        const response = await githubApiRequest(token, `/repos/${owner}/${repo}/git/trees/${targetBranch}?recursive=1`);
        const text = await response.text();
        const data = JSON.parse(text);
        
        if (!data.tree) return [];

        const tree = data.tree.map((item: any) => ({ 
            path: item.path, 
            type: item.type, 
            size: item.size,
            sha: item.sha 
        }));
        
        await cacheService.set(cacheKey, tree);
        return tree;
    } catch (error) {
        console.error(`Failed to get repo tree for ${owner}/${repo}:`, error);
        return [];
    }
}

// Alias for RepoAnalyzer
export const fetchRepoFileTree = async (owner: string, repo: string): Promise<any[]> => {
    return getRepoTree({ token: '', owner, repo });
}

// --- New Stats Features ---

/**
 * Calculates Lines Committed Per Month (LCPM) based on code frequency stats.
 * Robustly handles 202 Accepted retries.
 */
export async function getCodeFrequency(token: string, owner: string, repo: string): Promise<number> {
    const MAX_RETRIES = 3;
    let attempts = 0;

    while (attempts < MAX_RETRIES) {
        try {
            // Returns [timestamp, additions, deletions] array
            const response = await githubApiRequest(token, `/repos/${owner}/${repo}/stats/code_frequency`);
            
            if (response.status === 202) {
                // Stats are computing. Wait a bit and try again.
                await new Promise(r => setTimeout(r, 1500));
                attempts++;
                continue;
            }

            const stats: [number, number, number][] = await response.json();
            
            if (!Array.isArray(stats)) return 0;
            
            // Filter last 4 weeks
            const recentStats = stats.slice(-4);
            const totalAdditions = recentStats.reduce((acc, week) => acc + (week[1] || 0), 0);
            return totalAdditions;

        } catch (e) {
            console.warn(`Failed to fetch code frequency for ${owner}/${repo}`, e);
            return 0;
        }
    }
    return 0;
}

/**
 * Compare two commits/branches.
 * Compares Base (My fork) to Head (Upstream).
 * 'ahead_by' = How many commits Upstream is ahead of Me.
 */
export async function getCompareData(
    token: string, 
    baseOwner: string, 
    baseRepo: string, 
    headOwner: string, 
    headRepo: string,
    baseBranchName?: string,
    headBranchName?: string
): Promise<DiffResult | null> {
    
    const tryCompare = async (base: string, head: string) => {
        // Compare URL: /repos/BASE_OWNER/BASE_REPO/compare/BASE...HEAD
        const compareSpec = `${baseOwner}:${base}...${headOwner}:${head}`;
        const response = await githubApiRequest(token, `/repos/${baseOwner}/${baseRepo}/compare/${compareSpec}`);
        return await response.json();
    };

    // 1. If branches explicit, try them directly
    if (baseBranchName && headBranchName) {
        try {
            return await tryCompare(baseBranchName, headBranchName) as DiffResult;
        } catch (e) {
            console.warn(`Failed to compare explicit branches ${baseBranchName}...${headBranchName}, falling back to defaults.`);
        }
    }

    // 2. Resolve default branches if not provided
    let baseBranch = baseBranchName || 'main';
    let headBranch = headBranchName || 'main';

    try {
        if (!baseBranchName) {
            const baseDetails = await getRepoDetails(token, baseOwner, baseRepo);
            baseBranch = baseDetails.default_branch;
        }
        if (!headBranchName) {
            const headDetails = await getRepoDetails(token, headOwner, headRepo);
            headBranch = headDetails.default_branch;
        }
    } catch (e) {
        console.warn("Could not fetch repo details for branches, checking defaults...");
    }

    try {
        return await tryCompare(baseBranch, headBranch) as DiffResult;
    } catch (e) {
        // 3. Fallback: If 'main' failed, try 'master' (common legacy issue)
        try {
             const fallbackBase = baseBranch === 'main' ? 'master' : baseBranch;
             const fallbackHead = headBranch === 'main' ? 'master' : headBranch;
             return await tryCompare(fallbackBase, fallbackHead) as DiffResult;
        } catch (e2) {
             console.warn(`Failed to compare ${baseOwner}/${baseRepo} with ${headOwner}/${headRepo}`, e);
             return null;
        }
    }
}

export function parseGitHubUrl(url: string): { owner: string, repo: string } | null {
    if (!url) return null;
    try {
        // Handle git+https://github.com/... or just https://github.com/...
        const clean = url.replace(/^git\+/, '').replace(/\.git$/, '');
        const urlObj = new URL(clean);
        if (urlObj.hostname !== 'github.com') return null;
        
        const parts = urlObj.pathname.split('/').filter(p => p);
        if (parts.length >= 2) {
            return { owner: parts[0], repo: parts[1] };
        }
        return null;
    } catch {
        // Try regex for simple strings
        const match = url.match(/github\.com\/([^\/]+)\/([^\/]+)/);
        if (match) return { owner: match[1], repo: match[2] };
        return null;
    }
}

export function formatRelativeTime(isoDate: string): string {
    const date = new Date(isoDate);
    if (isNaN(date.getTime())) return 'N/A';
    
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    
    const seconds = Math.floor(diffMs / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    const months = Math.floor(days / 30);
    
    if (months > 0) {
        const remainingDays = days % 30;
        return remainingDays > 0 ? `${months}M ${remainingDays}D AGO` : `${months}M AGO`;
    }
    if (days > 0) return `${days}D AGO`;
    if (hours > 0) return `${hours}H AGO`;
    if (minutes > 0) return `${minutes}M AGO`;
    return 'JUST NOW';
}
