
import { EnrichedPackageInfo, FileTreeNode, JsDelivrDir, JsDelivrFile, NpmUser } from '../types';

const REGISTRY_BASE_URL = 'https://registry.npmmirror.com';
const DOWNLOADS_API_URL = 'https://api.npmjs.org/downloads/point/last-week';
const JSDELIVR_DATA_URL = 'https://data.jsdelivr.com';
const JSDELIVR_CDN_URL = 'https://cdn.jsdelivr.net';
const UNPKG_CDN_URL = 'https://unpkg.com';

const CODE_EXTENSIONS = new Set(['js', 'ts', 'jsx', 'tsx', 'mjs', 'cjs', 'vue', 'svelte', 'html', 'css', 'scss', 'less', 'json', 'py', 'go', 'rb']);
const DOC_EXTENSIONS = new Set(['md', 'txt', 'doc', 'docx', 'pdf']);

// Estimate LoC based on file size (avg 30 bytes per line for compact JS)
const estimateLoC = (size: number) => Math.round(size / 30);

// Helper to parse author string "Name <email> (url)"
function parseAuthor(author: any): { name: string, email?: string, url?: string } {
    if (!author) return { name: 'Unknown' };
    
    if (typeof author === 'string') {
        const emailMatch = author.match(/<([^>]+)>/);
        const urlMatch = author.match(/\(([^)]+)\)/);
        const nameMatch = author.replace(/<[^>]+>/, '').replace(/\([^)]+\)/, '').trim();
        return {
            name: nameMatch || author,
            email: emailMatch ? emailMatch[1].trim() : undefined,
            url: urlMatch ? urlMatch[1].trim() : undefined
        };
    }
    if (typeof author === 'object') {
        return {
            name: author.name || 'Unknown',
            email: author.email,
            url: author.url
        };
    }
    return { name: 'Unknown' };
}

export async function getPackagesByMaintainer(username: string): Promise<NpmUser | null> {
    try {
        const response = await fetch(`https://registry.npmjs.org/-/v1/search?text=maintainer:${username}&size=100`);
        if (!response.ok) return null;
        
        const data = await response.json();
        const objects = data.objects || [];
        
        const packages: Partial<EnrichedPackageInfo>[] = objects.map((obj: any) => ({
            name: obj.package.name,
            version: obj.package.version,
            description: obj.package.description,
            lastPublished: obj.package.date,
            keywords: obj.package.keywords,
            homepage: obj.package.links?.homepage,
            repositoryUrl: obj.package.links?.repository,
            status: 'enriched', // Minimal enrichment for display
            maintainers: obj.package.maintainers ? obj.package.maintainers.map((m: any) => parseAuthor(m)) : []
        }));

        let email = '';
        
        // Try to find author info in the first package to populate user profile
        if (objects.length > 0) {
            const firstPkg = objects[0].package;
            if (firstPkg.publisher && firstPkg.publisher.username === username) {
                email = firstPkg.publisher.email;
            } else if (firstPkg.maintainers) {
                const maintainer = firstPkg.maintainers.find((m: any) => m.username === username);
                if (maintainer) email = maintainer.email;
            }
        }
        
        return {
            username,
            email: email || undefined,
            avatar: `https://github.com/${username}.png`, // Optimistic fallback
            packageCount: packages.length,
            packages,
            lastUpdated: new Date().toISOString()
        };

    } catch (e) {
        console.error(`Failed to fetch packages for maintainer ${username}`, e);
        return null;
    }
}

export async function enrichPackageInfo(packageName: string): Promise<Partial<EnrichedPackageInfo> | null> {
  try {
    // 1. Fetch Registry Metadata
    const response = await fetch(`${REGISTRY_BASE_URL}/${packageName}`);
    if (!response.ok) return null;
    const data = await response.json();
    const latestVersion = data['dist-tags']?.latest;
    if (!latestVersion) return null;
    
    const versionData = data.versions?.[latestVersion];
    if (!versionData) return null;

    const getRepoUrl = (repo: any): string => {
      if (!repo) return '';
      if (typeof repo === 'string') return repo;
      if (typeof repo.url === 'string') {
        return repo.url.replace(/^git\+/, '').replace(/\.git$/, '');
      }
      return '';
    }

    // 2. Fetch Downloads (Context)
    let downloads = 0;
    try {
        const dlRes = await fetch(`${DOWNLOADS_API_URL}/${packageName}`);
        if(dlRes.ok) {
            const dlData = await dlRes.json();
            downloads = dlData.downloads || 0;
        }
    } catch (e) {
        // Ignore download fetch error
    }

    // 3. Extract Stars & Maintainers
    const stars = data.users ? Object.keys(data.users).length : 0;
    
    // Combine 'maintainers', 'contributors', 'author' and 'publisher' from all sources
    const maintainerMap = new Map<string, { name: string, email?: string }>();
    
    // Helper to add to map
    const addPerson = (person: any) => {
        if (!person) return;
        const parsed = parseAuthor(person);
        if (parsed.name && parsed.name !== 'Unknown') {
            const existing = maintainerMap.get(parsed.name);
            // Prioritize having an email
            if (!existing || (!existing.email && parsed.email)) {
                maintainerMap.set(parsed.name, parsed);
            }
        }
    };

    // A. Publisher (_npmUser) - CRITICAL: Add this FIRST as they are the releaser
    if (versionData._npmUser) {
         addPerson(versionData._npmUser);
    }

    // B. Author from Version Data
    if (versionData.author) {
        addPerson(versionData.author);
    }

    // C. Maintainers from Registry Root
    if (data.maintainers && Array.isArray(data.maintainers)) {
        data.maintainers.forEach((m: any) => addPerson(m));
    }
    
    // D. Contributors from Version Data
    if (versionData.contributors) {
        if (Array.isArray(versionData.contributors)) {
            versionData.contributors.forEach((c: any) => addPerson(c));
        } else {
            addPerson(versionData.contributors);
        }
    }
    
    // E. Maintainers from Version Data (sometimes different from root)
    if (versionData.maintainers && Array.isArray(versionData.maintainers)) {
        versionData.maintainers.forEach((m: any) => addPerson(m));
    }

    const maintainers = Array.from(maintainerMap.values());

    // 4. Fetch File Tree for Deep Analysis
    let codeFileCount = 0;
    let docFileCount = 0;
    let totalLinesOfCode = 0;
    let hasTypes = false;
    const techStack = new Set<string>();

    try {
       const treeResponse = await fetch(`${JSDELIVR_DATA_URL}/v1/package/npm/${packageName}@${latestVersion}/flat`);
       if (treeResponse.ok) {
           const treeData: JsDelivrDir = await treeResponse.json();
           treeData.files.forEach(f => {
               const ext = f.name.split('.').pop()?.toLowerCase() || '';
               if (CODE_EXTENSIONS.has(ext)) {
                   codeFileCount++;
                   totalLinesOfCode += estimateLoC(f.size);
                   if (ext === 'ts' || ext === 'tsx') techStack.add('TypeScript');
                   if (ext === 'jsx' || ext === 'tsx') techStack.add('React');
                   if (ext === 'vue') techStack.add('Vue');
                   if (ext === 'svelte') techStack.add('Svelte');
               }
               if (DOC_EXTENSIONS.has(ext)) {
                   docFileCount++;
               }
               if (f.name.endsWith('.d.ts')) {
                   hasTypes = true;
               }
           });
       }
    } catch (e) {
        console.warn(`Failed to fetch file tree for ${packageName}`, e);
    }

    // 5. Fetch package.json content via metadata for precise entrypoints
    let entrypoints: Record<string, string> = {};
    try {
        if (versionData.main) entrypoints['main'] = versionData.main;
        if (versionData.module) entrypoints['module'] = versionData.module;
        if (versionData.types || versionData.typings) {
            entrypoints['types'] = versionData.types || versionData.typings;
            hasTypes = true;
        }
        if (versionData.exports) entrypoints['exports'] = JSON.stringify(versionData.exports);
        
        // Detect dependencies for tech stack
        const allDeps = { ...versionData.dependencies, ...versionData.devDependencies, ...versionData.peerDependencies };
        if (allDeps['react']) techStack.add('React');
        if (allDeps['vue']) techStack.add('Vue');
        if (allDeps['@angular/core']) techStack.add('Angular');
        if (allDeps['tailwindcss']) techStack.add('Tailwind');
        if (allDeps['typescript']) techStack.add('TypeScript');
        if (allDeps['next']) techStack.add('Next.js');
        if (allDeps['express']) techStack.add('Express');
        if (allDeps['three']) techStack.add('Three.js');
        if (allDeps['@nestjs/core']) techStack.add('NestJS');
        if (allDeps['ts-morph']) techStack.add('ts-morph');
        
    } catch (e) {
        console.warn(`Failed to analyze package.json for ${packageName}`, e);
    }

    return {
      name: data.name,
      version: latestVersion,
      description: data.description || versionData.description || 'No description available.',
      lastPublished: data.time?.modified,
      fileCount: versionData.dist?.fileCount || 0,
      unpackedSize: versionData.dist?.unpackedSize || 0,
      dependenciesCount: Object.keys(versionData.dependencies || {}).length,
      devDependenciesCount: Object.keys(versionData.devDependencies || {}).length,
      keywords: data.keywords || [],
      homepage: data.homepage || '',
      repositoryUrl: getRepoUrl(data.repository),
      license: data.license || 'N/A',
      status: 'enriched',
      // New Deep Analysis & Context Fields
      codeFileCount,
      docFileCount,
      totalLinesOfCode,
      entrypoints: JSON.stringify(entrypoints),
      hasTypes,
      techStack: Array.from(techStack),
      downloads,
      stars,
      maintainers,
      lastAnalyzed: new Date().toISOString()
    };
  } catch (error) {
    console.error(`Failed to enrich package info for ${packageName}`, error);
    return null;
  }
}

export async function fetchFileTree(packageName: string, version: string): Promise<FileTreeNode[]> {
  const response = await fetch(`${JSDELIVR_DATA_URL}/v1/package/npm/${packageName}@${version}/flat`);
  if (!response.ok) {
    throw new Error('Failed to fetch file tree');
  }
  const data: JsDelivrDir = await response.json();
  return buildTreeFromFlatList(data.files);
}

export async function fetchFileContent(packageName: string, version: string, path: string): Promise<string> {
  const ver = version || 'latest';
  
  // Normalize Path: Remove leading slashes and redundant package name prefixes
  let cleanPath = path.trim();
  cleanPath = cleanPath.replace(/^\/+/, ''); // Remove leading /
  
  // Sometimes path includes package name e.g. "my-pkg/index.js", we might need to strip it if tree was weird
  // But JSDelivr expects just "index.js"
  // We'll trust cleanPath is relative to package root for now.
  
  // Strategy 1: JSDelivr
  const jsDelivrUrl = `${JSDELIVR_CDN_URL}/npm/${packageName}@${ver}/${cleanPath}`;
  
  try {
      const response = await fetch(jsDelivrUrl);
      if (response.ok) {
          return await response.text();
      }
      
      // Strategy 2: Unpkg (Fallback)
      const unpkgUrl = `${UNPKG_CDN_URL}/${packageName}@${ver}/${cleanPath}`;
      console.warn(`JSDelivr failed for ${cleanPath}, trying Unpkg: ${unpkgUrl}`);
      
      const unpkgResponse = await fetch(unpkgUrl);
      if (unpkgResponse.ok) {
          return await unpkgResponse.text();
      }

      // Strategy 3: Try 'latest' if version specific failed
      if (ver !== 'latest') {
           const fallbackUrl = `${JSDELIVR_CDN_URL}/npm/${packageName}@latest/${cleanPath}`;
           const fallbackRes = await fetch(fallbackUrl);
           if (fallbackRes.ok) return await fallbackRes.text();
      }

      return `// Error loading file: ${cleanPath}\n// Sources tried:\n// 1. ${jsDelivrUrl}\n// 2. ${unpkgUrl}\n// Status: ${response.status}`;
  } catch (e) {
      return `// Failed to fetch content.\n// Error: ${e instanceof Error ? e.message : String(e)}`;
  }
}

function buildTreeFromFlatList(files: JsDelivrFile[]): FileTreeNode[] {
    const root: FileTreeNode = { name: 'root', path: '/', type: 'directory', children: [] };

    files.forEach(file => {
        // JSDelivr paths usually start with /
        const rawPath = file.name.startsWith('/') ? file.name.substring(1) : file.name;
        if (!rawPath) return;

        const parts = rawPath.split('/');
        let currentNode = root;
        let currentPath = '';

        parts.forEach((part, index) => {
            currentPath += `/${part}`;
            // Remove double slashes for clean path usage in selectFile
            const cleanNodePath = currentPath.replace(/^\/+/, '').replace(/\/+/g, '/');
            
            const isLastPart = index === parts.length - 1;
            let childNode = currentNode.children?.find(child => child.name === part);

            if (!childNode) {
                childNode = {
                    name: part,
                    path: cleanNodePath, 
                    type: isLastPart && file.type === 'file' ? 'file' : 'directory',
                    children: (isLastPart && file.type === 'file') ? undefined : [],
                    size: (isLastPart && file.type === 'file') ? file.size : undefined
                };
                currentNode.children?.push(childNode);
            }
            if (childNode.type === 'directory' && !childNode.children) {
              childNode.children = [];
            }
            currentNode = childNode;
        });
    });
    
    const sortNodes = (nodes: FileTreeNode[]) => {
      nodes.sort((a, b) => {
        if (a.type === 'directory' && b.type === 'file') return -1;
        if (a.type === 'file' && b.type === 'directory') return 1;
        return a.name.localeCompare(b.name);
      });
      nodes.forEach(node => {
        if (node.children) {
          sortNodes(node.children);
        }
      });
    };

    if (root.children) {
        sortNodes(root.children);
        return root.children;
    }
    return [];
}
