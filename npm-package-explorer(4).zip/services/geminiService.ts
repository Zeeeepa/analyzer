
import { GoogleGenAI, Tool, Type } from "@google/genai";
import { GithubConfig, ChatContext, ViewedResource, LibraryContext } from "../types";
import { getFileContent, getRepoTree } from "./githubService";
import { fetchFileTree, fetchFileContent } from "./npmService";

if (!process.env.API_KEY) {
  console.warn("Gemini API key not found. Make sure to set the API_KEY environment variable.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

// --- Interface Controller for Agent ---
export interface StudioController {
    navigate: (tab: 'swarm' | 'github' | 'npm' | 'knowledge' | 'variables') => void;
    openResource: (name: string, type: 'github' | 'npm') => Promise<void>;
    closeResource: () => void;
    selectFile: (path: string) => Promise<void>;
    triggerScan: () => Promise<void>;
    getState: () => any;
    getLibraryContext: () => LibraryContext | null;
    searchSymbols: (query: string) => string[];
    queryGraph: (query: string) => string[]; // New: Graph Querying
    delegateToSwarm: (task: string) => void; // New: Delegation
}

// --- Tool Definitions ---

const listFilesTool = {
    name: "list_files",
    description: "List all files in the project to understand the structure.",
    parameters: { type: Type.OBJECT, properties: {} }
};

const readFileTool = {
    name: "read_file",
    description: "Read the content of a specific file. Use this to inspect code, logic, or configuration.",
    parameters: {
        type: Type.OBJECT,
        properties: {
            path: { type: Type.STRING, description: "The full path of the file to read (e.g., 'src/App.tsx')" }
        },
        required: ["path"]
    }
};

const getProjectIntelTool = {
    name: "get_project_intel",
    description: "Get pre-computed intelligence about the project, including exports, tech stack, and structure. USE THIS FIRST.",
    parameters: { type: Type.OBJECT, properties: {} }
};

const searchSymbolsTool = {
    name: "search_codebase_symbols",
    description: "Semantically search for symbols (classes, functions, variables) in the codebase. Use this to find WHERE functionality is defined without reading every file.",
    parameters: {
        type: Type.OBJECT,
        properties: {
            query: { type: Type.STRING, description: "The symbol name or keyword to search for (e.g., 'AuthService', 'login', 'User')" }
        },
        required: ["query"]
    }
};

const querySemanticGraphTool = {
    name: "query_semantic_graph",
    description: "Query the semantic dependency graph to find relationships between files and symbols. E.g., 'What calls login?' or 'Dependencies of AuthService'. Only works after Deep Analyze.",
    parameters: {
        type: Type.OBJECT,
        properties: {
            query: { type: Type.STRING, description: "Relationship query (e.g. 'calls to X', 'dependencies of Y')" }
        },
        required: ["query"]
    }
};

const delegateToSwarmTool = {
    name: "delegate_to_swarm",
    description: "Delegate a complex, multi-step analysis task to the Autonomous Agent Swarm. Use this for broad 'Analyze everything' or 'Find all bugs' requests.",
    parameters: {
        type: Type.OBJECT,
        properties: {
            task_description: { type: Type.STRING, description: "Detailed description of the task for the swarm." }
        },
        required: ["task_description"]
    }
};

// UI Control Tools
const uiNavigateTool = {
    name: "ui_navigate",
    description: "Switch the application tab.",
    parameters: {
        type: Type.OBJECT,
        properties: {
            tab: { type: Type.STRING, description: "Tab to switch to: 'swarm', 'github', 'npm', 'knowledge', 'variables'" }
        },
        required: ["tab"]
    }
};

const uiViewResourceTool = {
    name: "ui_view_resource",
    description: "Open a specific resource (GitHub Repo or NPM Package) in the Project Explorer modal.",
    parameters: {
        type: Type.OBJECT,
        properties: {
            name: { type: Type.STRING, description: "Name of the resource (e.g. 'facebook/react' or 'lodash')" },
            type: { type: Type.STRING, description: "'github' or 'npm'" }
        },
        required: ["name", "type"]
    }
};

const uiSelectFileTool = {
    name: "ui_select_file",
    description: "Select and display a file in the active Project Explorer.",
    parameters: {
        type: Type.OBJECT,
        properties: {
            path: { type: Type.STRING, description: "File path to open" }
        },
        required: ["path"]
    }
};

const uiPerformScanTool = {
    name: "ui_perform_scan",
    description: "Trigger a Deep Analyze scan on the currently open resource.",
    parameters: { type: Type.OBJECT, properties: {} }
};

const uiCloseViewerTool = {
    name: "ui_close_viewer",
    description: "Close the Project Explorer modal.",
    parameters: { type: Type.OBJECT, properties: {} }
};

const uiGetStateTool = {
    name: "ui_get_state",
    description: "Get the current UI state (active tab, viewed resource, selected file). Use this to see what the user sees.",
    parameters: { type: Type.OBJECT, properties: {} }
};

const tools: Tool[] = [
    { functionDeclarations: [
        listFilesTool, readFileTool, getProjectIntelTool, searchSymbolsTool, querySemanticGraphTool, delegateToSwarmTool,
        uiNavigateTool, uiViewResourceTool, uiSelectFileTool, uiPerformScanTool, uiCloseViewerTool, uiGetStateTool
    ] }
];

export interface AgentStep {
    type: 'thought' | 'action' | 'observation' | 'response';
    content: string;
}

export const runAutonomousAgent = async function* (
    query: string, 
    context: ChatContext | null, 
    config: GithubConfig,
    controller?: StudioController // New controller argument
): AsyncGenerator<AgentStep> {
    
    yield { type: 'thought', content: `Initializing Neural Interface for: ${context?.name || 'Global Studio'}...` };

    // Inject Library Context into System Prompt
    let libContextStr = "";
    const lib = controller?.getLibraryContext();
    if (lib && lib.isHydrated) {
        libContextStr = `
        [ACTIVE LIBRARY CONTEXT]
        The following key files are pre-loaded in your memory. You do NOT need to call read_file for these:
        ${Object.entries(lib.files).map(([k, v]) => `--- FILE: ${k} ---\n${v.slice(0, 1000)}${v.length > 1000 ? '...[truncated]' : ''}`).join('\n')}
        
        [FILE STRUCTURE SUMMARY]
        Top files: ${lib.structure.slice(0, 50).join(', ')}
        `;
    }

    const systemInstruction = `
    You are the "System Core" of Link2Ink Studio, an advanced engineering environment.
    You have DIRECT and INDEPENDENT access to the full codebase structure and file contents.
    
    CAPABILITIES:
    - **Codebase Navigation**: You can list all files (list_files) and read any file (read_file).
    - **Semantic Retrieval**: USE 'search_codebase_symbols' or 'query_semantic_graph' to find definitions and relationships. Do NOT iterate files manually to find a function. Search for it first.
    - **Swarm Delegation**: If a task is complex (e.g. "Analyze entire architecture"), delegate it using 'delegate_to_swarm'.
    - **UI Control**: You can navigate the interface, open resources, and select files to show the user.
    
    CONTEXT:
    Current Resource: ${context ? `${context.name} (${context.type})` : 'None (Global Mode)'}
    ${libContextStr}
    
    PROTOCOL:
    1. If you have the file content in [ACTIVE LIBRARY CONTEXT], use it directly.
    2. To "retrieve contexts" or "find flows", start with 'query_semantic_graph' or 'search_codebase_symbols'.
    3. If the user asks to "open" or "show" something, use ui_view_resource.
    4. If the user asks to "analyze", use ui_perform_scan first, then query the results.
    5. Always verify your state with ui_get_state if unsure.
    `;

    const history: { role: string, parts: any[] }[] = [
        { role: "user", parts: [{ text: `User Query: ${query}` }] }
    ];

    let iteration = 0;
    const MAX_ITERATIONS = 12;

    while (iteration < MAX_ITERATIONS) {
        iteration++;
        
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: history,
            config: {
                tools: tools,
                systemInstruction: systemInstruction,
                temperature: 0.2,
            }
        });

        const candidates = response.candidates;
        if (!candidates || candidates.length === 0) break;

        const content = candidates[0].content;
        const parts = content.parts || [];
        
        const textPart = parts.find(p => p.text);
        
        if (textPart && textPart.text) {
             if (!parts.some(p => p.functionCall)) {
                 yield { type: 'response', content: textPart.text };
                 return;
             }
             yield { type: 'thought', content: textPart.text };
        }

        const functionCallPart = parts.find(p => p.functionCall);
        if (functionCallPart && functionCallPart.functionCall) {
            const fc = functionCallPart.functionCall;
            const functionName = fc.name;
            const args = fc.args as any;

            yield { type: 'action', content: `Executing: ${functionName}` };

            let functionResult = "";
            try {
                // --- Interface Control Tools ---
                if (functionName.startsWith('ui_') && controller) {
                     if (functionName === 'ui_navigate') {
                         controller.navigate(args.tab);
                         functionResult = `Navigated to ${args.tab}.`;
                     } else if (functionName === 'ui_view_resource') {
                         await controller.openResource(args.name, args.type);
                         functionResult = `Opened ${args.type} resource: ${args.name}.`;
                     } else if (functionName === 'ui_select_file') {
                         await controller.selectFile(args.path);
                         functionResult = `Selected and displayed file: ${args.path}.`;
                     } else if (functionName === 'ui_perform_scan') {
                         await controller.triggerScan();
                         functionResult = `Deep analysis scan triggered. Results will appear in UI.`;
                     } else if (functionName === 'ui_close_viewer') {
                         controller.closeResource();
                         functionResult = `Resource viewer closed.`;
                     } else if (functionName === 'ui_get_state') {
                         const state = controller.getState();
                         functionResult = JSON.stringify(state);
                     }
                }
                // --- Semantic & Data Tools ---
                else if (functionName === 'delegate_to_swarm' && controller) {
                    controller.delegateToSwarm(args.task_description);
                    functionResult = `Task delegated to Swarm Orchestrator. View the 'Swarm' tab for progress.`;
                }
                else if (functionName === 'query_semantic_graph' && controller) {
                    const results = controller.queryGraph(args.query);
                    if (results.length > 0) {
                        functionResult = `Graph Query Results:\n${results.slice(0, 10).join('\n')}`;
                    } else {
                        functionResult = "No relationships found. Ensure Deep Analyze has been run.";
                    }
                }
                else if (functionName === 'search_codebase_symbols' && controller) {
                    const results = controller.searchSymbols(args.query);
                    if (results.length > 0) {
                        functionResult = `Found matching symbols:\n${results.slice(0, 20).join('\n')}${results.length > 20 ? '\n...and more' : ''}`;
                    } else {
                        functionResult = "No symbols found matching that query. Try broader terms or check if Deep Analysis has been run.";
                    }
                }
                else if (functionName === 'get_project_intel') {
                    if (context?.analysisData) {
                         functionResult = `[INTEL REPORT]:\n${context.analysisData}`;
                    } else {
                         functionResult = `[INTEL REPORT]: No pre-computed intelligence available. Run 'ui_perform_scan' to generate it.`;
                    }
                } else if (functionName === 'list_files') {
                    let paths: string[] = [];
                    const liveState = controller?.getState();
                    if (liveState?.explorerTree?.length > 0) {
                        const flatten = (nodes: any[]): string[] => {
                             let res: string[] = [];
                             nodes.forEach(n => {
                                 res.push(n.path);
                                 if (n.children) res = res.concat(flatten(n.children));
                             });
                             return res;
                        }
                        paths = flatten(liveState.explorerTree);
                    } else {
                        if (context?.type === 'github') {
                             const tree = await getRepoTree({ ...config, owner: context.owner!, repo: context.name });
                             if (tree) paths = tree.map(t => t.path);
                        } else if (context?.type === 'npm') {
                             const tree = await fetchFileTree(context!.name, context!.version || 'latest');
                             const flatten = (nodes: any[]): string[] => {
                                 let res: string[] = [];
                                 nodes.forEach(n => { res.push(n.path); if (n.children) res = res.concat(flatten(n.children)); });
                                 return res;
                             }
                             paths = flatten(tree);
                        }
                    }
                    functionResult = `Found ${paths.length} files. Top 50: ${paths.slice(0, 50).join(', ')}`;

                } else if (functionName === 'read_file') {
                    // Check Library Context First!
                    const lib = controller?.getLibraryContext();
                    if (lib && lib.files[args.path]) {
                        functionResult = `[FROM MEMORY] Content of ${args.path}:\n${lib.files[args.path]}`;
                    } else {
                        let content: string | null = null;
                        if (context?.type === 'github') {
                             content = await getFileContent({ ...config, owner: context.owner!, repo: context.name }, args.path);
                        } else if (context?.type === 'npm') {
                             content = await fetchFileContent(context!.name, context!.version || 'latest', args.path);
                        }
                        if (content) {
                            functionResult = `Content of ${args.path}:\n${content.slice(0, 5000)}`;
                        } else {
                            functionResult = "File not found or empty.";
                        }
                    }
                }
            } catch (e: any) {
                functionResult = `[SYSTEM ERROR]: ${e.message}`;
            }

            yield { type: 'observation', content: `Result: ${functionResult.slice(0, 200)}...` };

            history.push({ role: "model", parts: parts }); 
            history.push({
                role: "user",
                parts: [{
                    functionResponse: {
                        name: functionName,
                        response: { result: functionResult }
                    }
                }]
            });
        } else {
            if (textPart) return;
        }
    }
};

export const summarizeText = async (text: string, context: 'readme' | 'code'): Promise<string> => {
  if (!process.env.API_KEY) return "API Key missing";
  const prompt = context === 'readme'
    ? `Summarize this README:\n\n${text}`
    : `Explain this code:\n\n${text}`;
  const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
  });
  return response.text || "No summary generated";
};

export const analyzeMcpSourceContent = async (text: string): Promise<any[]> => {
  if (!process.env.API_KEY) return [];
  const prompt = `
  Analyze the following text and identify any MCP server configurations.
  Extract them as a JSON array of objects with fields: name, url, type, description.
  Return ONLY the JSON array.
  Text: ${text.substring(0, 20000)} 
  `;

  try {
      const response = await ai.models.generateContent({
          model: "gemini-2.5-flash",
          contents: prompt,
          config: { responseMimeType: "application/json" }
      });
      return JSON.parse(response.text || "[]");
  } catch (e) {
      console.error("Gemini analysis failed", e);
      return [];
  }
};

export const generateInfographic = async (
  repoName: string, 
  fileTree: any[], 
  style: string, 
  is3D: boolean, 
  language: string
): Promise<string | null> => {
  if (!process.env.API_KEY) return null;
  
  const fileSummary = fileTree.slice(0, 50).map(f => f.path).join('\n');
  const type = is3D ? "3D holographic architectural model" : "Technical architectural blueprint infographic";
  
  const prompt = `
  Create a ${type} for a software project named "${repoName}".
  
  The image should visually represent the codebase structure, with modules connected by data flow lines.
  
  Style: ${style}
  Language of labels: ${language}
  
  Key components from file structure:
  ${fileSummary}
  
  Make it look futuristic, professional, and detailed. High resolution.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts: [{ text: prompt }] }
    });

    if (response.candidates && response.candidates.length > 0) {
        for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
                return part.inlineData.data;
            }
        }
    }
    return null;
  } catch (e) {
    console.error("Image generation failed", e);
    return null; 
  }
};

export const generateSetupScript = async (
    repoName: string,
    fileTree: string[],
    packageJson: string | null,
    readme: string | null,
    detectedVars: string[],
    knownVariables: Record<string, string>
): Promise<string> => {
    if (!process.env.API_KEY) return "# API Key Missing";

    const prompt = `
    You are a DevOps engineer. Create a robust \`setup.sh\` script to bootstrap the "${repoName}" project.
    
    1. Check if the directory "${repoName}" exists. If yes, cd into it and git pull. If no, git clone (assume HTTPS URL based on name).
    2. Detect package manager from files (npm, yarn, pnpm, cargo, pip, go mod) and install dependencies.
    3. Create a \`.env\` file.
       - I have detected these potential variables in the code: ${detectedVars.join(', ')}
       - I have these known secrets provided by the user (inject these values): ${JSON.stringify(knownVariables)}
       - For other detected vars not in known secrets, add them with empty values or comments.
    4. Output the script commands.

    Context:
    - Files: ${fileTree.slice(0, 100).join(', ')}
    - Package.json scripts: ${packageJson ? JSON.parse(packageJson).scripts : 'None'}
    - README snippet: ${readme ? readme.slice(0, 1000) : 'None'}

    Return ONLY the bash script content. No markdown code blocks.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
        });
        return response.text?.replace(/```bash/g, '').replace(/```/g, '').trim() || "# No script generated";
    } catch (e) {
        return "# Failed to generate script via AI.";
    }
}
