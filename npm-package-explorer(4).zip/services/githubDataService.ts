import { GithubConfig } from '../types';
import { getFileContent, updateFile } from './githubService';
import { csvToJson, jsonToCsv } from '../utils/csv';

async function loadData<T>(config: GithubConfig, path: string): Promise<T[]> {
    try {
        const csvContent = await getFileContent(config, path);
        if (!csvContent) {
            console.warn(`No content found at ${path}, returning empty array.`);
            return []; // File doesn't exist or is empty
        }
        return csvToJson<T>(csvContent);
    } catch (error) {
        console.error(`Error loading data from ${path}:`, error);
        throw new Error(`Failed to load data from GitHub path: ${path}.`);
    }
}

async function saveData<T extends Record<string, any>>(
    config: GithubConfig,
    path: string,
    data: T[],
    commitMessage: string
): Promise<void> {
    try {
        const csvContent = jsonToCsv(data);
        await updateFile(config, path, csvContent, commitMessage);
    } catch (error) {
        console.error(`Error saving data to ${path}:`, error);
        throw new Error(`Failed to save data to GitHub path: ${path}.`);
    }
}

export const githubDataService = {
    loadData,
    saveData,
};
