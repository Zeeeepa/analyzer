


export const DEFAULT_GITHUB_CONFIG = {
    token: "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",
    owner: "zeeeepa",
    repo: "analyzer"
};

export const STORAGE_PATHS = {
    NPM: 'DATA/NPM/packages.csv',
    USERS: 'DATA/NPM/users.csv',
    GIT: 'DATA/GIT/projects.csv',
    KNOWLEDGE: 'DATA/KNOW/items.csv',
    MCP_SOURCES: 'DATA/KNOW/MCP/sources.csv',
    MCP_PACKAGES: 'DATA/KNOW/MCP/packages.csv',
    MCP_SERVERS: 'DATA/KNOW/MCP/servers.csv',
    API_DEFINITIONS: 'DATA/KNOW/API/endpoints.csv',
    VARIABLES: 'DATA/VAR/variables.csv'
};