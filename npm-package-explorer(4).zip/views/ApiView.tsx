
import React, { useState, useEffect } from 'react';
import { ApiDefinition } from '../types';
import { useGithubData } from '../hooks/useGithubData';
import { useStudio } from '../contexts/StudioContext';
import DataSyncControls from '../components/DataSyncControls';
import Spinner from '../components/Spinner';
import ApiDefModal from '../components/modals/ApiDefModal';
import { PlusCircleIcon, SettingsIcon, CloseIcon, ServerStackIcon } from '../components/icons';
import { STORAGE_PATHS } from '../constants/config';

const ApiView: React.FC = () => {
  const { githubConfig, isGithubConfigured } = useStudio();
  const { data: apiDefs, isLoading, isSyncing, error, load, save, add, update, remove } = useGithubData<ApiDefinition>(
    githubConfig,
    isGithubConfigured,
    STORAGE_PATHS.API_DEFINITIONS,
    'API Definitions'
  );
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingApiDef, setEditingApiDef] = useState<ApiDefinition | null>(null);

  useEffect(() => {
    if (isGithubConfigured) {
      load();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isGithubConfigured]);

  const renderContent = () => {
      if (isLoading) return <div className="flex justify-center p-8"><Spinner text="Loading API Definitions..." /></div>;
      if (error) return <p className="text-center text-red-400 p-8">{error}</p>;
      if (apiDefs.length === 0) return (
          <div className="text-center text-gray-500 p-8 bg-gray-800/50 rounded-lg">
              <p>No API definitions found. Add your first endpoint.</p>
          </div>
      );

      return (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {apiDefs.map(api => (
                  <div key={api.id} className="bg-gray-800 border border-gray-700 rounded-lg p-3 flex flex-col justify-between hover:bg-gray-700 transition-all shadow-lg group relative">
                       <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button onClick={() => { setEditingApiDef(api); setIsModalOpen(true); }} className="p-1 hover:bg-gray-600 rounded text-yellow-400" title="Edit">
                                <SettingsIcon className="w-4 h-4" />
                            </button>
                            <button onClick={() => { if(window.confirm('Delete?')) remove(api.id!); }} className="p-1 hover:bg-gray-600 rounded text-red-400" title="Delete">
                                <CloseIcon className="w-4 h-4" />
                            </button>
                       </div>
                       
                       <div>
                            <div className="flex items-center gap-2 mb-2">
                                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                                    api.method === 'GET' ? 'bg-blue-900 text-blue-300' :
                                    api.method === 'POST' ? 'bg-green-900 text-green-300' :
                                    api.method === 'DELETE' ? 'bg-red-900 text-red-300' :
                                    'bg-yellow-900 text-yellow-300'
                                }`}>{api.method}</span>
                                <h3 className="font-bold text-yellow-400 truncate" title={api.name}>{api.name}</h3>
                            </div>
                            <p className="text-xs text-gray-400 font-mono bg-gray-900/50 p-1 rounded truncate mb-2" title={api.endpointUrl}>{api.endpointUrl}</p>
                            <p className="text-sm text-gray-400 line-clamp-2">{api.description || 'No description.'}</p>
                       </div>
                       {api.tags && api.tags.length > 0 && (
                           <div className="flex flex-wrap gap-1 mt-2">
                               {(Array.isArray(api.tags) ? api.tags : String(api.tags).split(';')).map(t => (
                                   t && <span key={t} className="text-[10px] bg-gray-900 text-gray-500 px-1 rounded">{t}</span>
                               ))}
                           </div>
                       )}
                  </div>
              ))}
          </div>
      );
  };

  return (
      <div className="flex flex-col gap-4">
          <div className="flex justify-between items-center bg-gray-900/30 p-2 rounded">
              <h3 className="text-lg font-bold text-gray-200 flex items-center gap-2">
                  <ServerStackIcon className="w-5 h-5 text-yellow-500" />
                  API Endpoints
              </h3>
              <div className="flex items-center gap-4">
                  <button onClick={() => { setEditingApiDef(null); setIsModalOpen(true); }} className="bg-yellow-600 hover:bg-yellow-500 text-white px-4 py-2 rounded-md transition-colors text-sm font-medium flex items-center gap-2">
                      <PlusCircleIcon className="w-4 h-4" /> Add API
                  </button>
                  <DataSyncControls 
                      onLoad={load}
                      onSave={save}
                      isLoading={isLoading}
                      isSyncing={isSyncing}
                      isConfigured={isGithubConfigured}
                      saveColor="yellow"
                  />
              </div>
          </div>

          <div className="mt-2">
             {!isGithubConfigured 
                ? <p className="text-center text-yellow-400 mt-8">Please configure your GitHub connection in the settings.</p>
                : renderContent()
             }
          </div>

          <ApiDefModal 
            isOpen={isModalOpen}
            onClose={() => setIsModalOpen(false)}
            onSave={(apiDef) => {
                if (editingApiDef) update(editingApiDef.id!, apiDef);
                else add(apiDef);
                setIsModalOpen(false);
            }}
            initialData={editingApiDef}
          />
      </div>
  );
};

export default ApiView;
