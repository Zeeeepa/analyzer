
import React, { useState } from 'react';
import { useStudio } from '../contexts/StudioContext';
import { useToast } from '../components/Toast';
import { PlusCircleIcon, CloseIcon, SyncIcon, SettingsIcon } from '../components/icons';
import Spinner from '../components/Spinner';
import { UserVariable } from '../types';
import { variableService } from '../services/variableService';
import { STORAGE_PATHS } from '../constants/config';

const VariablesView: React.FC = () => {
    const { variables, refreshVariables, githubConfig, isGithubConfigured } = useStudio();
    const { addToast } = useToast();
    const [isSyncing, setIsSyncing] = useState(false);
    const [newKey, setNewKey] = useState('');
    const [newValue, setNewValue] = useState('');

    const handleAddVariable = async () => {
        if (!newKey.trim() || !newValue.trim()) return;
        
        const newVar: UserVariable = {
            id: crypto.randomUUID(),
            key: newKey.trim(),
            value: newValue.trim(),
            updatedAt: new Date().toISOString()
        };

        const updatedVars = [...variables, newVar];
        
        // Optimistic update
        // We actually need to save to persist because StudioContext refreshes from source
        // But for better UX we might show it immediately. However, saving is async.
        
        setIsSyncing(true);
        try {
            await variableService.saveVariables(githubConfig, STORAGE_PATHS.VARIABLES, updatedVars);
            await refreshVariables();
            setNewKey('');
            setNewValue('');
            addToast({ message: "Variable saved securely.", type: 'success' });
        } catch (e) {
            addToast({ message: "Failed to save variable.", type: 'error' });
        } finally {
            setIsSyncing(false);
        }
    };

    const handleDelete = async (id: string) => {
        if (!window.confirm("Are you sure you want to delete this variable?")) return;
        const updatedVars = variables.filter(v => v.id !== id);
        setIsSyncing(true);
        try {
             await variableService.saveVariables(githubConfig, STORAGE_PATHS.VARIABLES, updatedVars);
             await refreshVariables();
             addToast({ message: "Variable deleted.", type: 'info' });
        } catch (e) {
             addToast({ message: "Failed to delete variable.", type: 'error' });
        } finally {
            setIsSyncing(false);
        }
    };

    if (!isGithubConfigured) {
        return (
             <div className="flex flex-col items-center justify-center h-full text-gray-500">
                <SettingsIcon className="w-16 h-16 opacity-20 mb-4" />
                <p>Configure GitHub to manage environment variables.</p>
             </div>
        );
    }

    return (
        <div className="flex flex-col gap-6 h-full max-w-4xl mx-auto">
             <div className="flex items-center justify-between bg-black/40 border border-white/10 p-4 rounded-xl backdrop-blur-md">
                 <div>
                     <h2 className="text-xl font-bold text-white neon-text">ENVIRONMENT VARIABLES</h2>
                     <p className="text-xs text-gray-400 font-mono">
                         SECURE STORAGE • SCATTERED ENCRYPTION • AUTO-INJECTION
                     </p>
                 </div>
                 <button 
                    onClick={refreshVariables} 
                    disabled={isSyncing}
                    className="p-2 hover:bg-white/10 rounded-full text-gray-400 hover:text-white transition-colors"
                 >
                     <SyncIcon className={`w-5 h-5 ${isSyncing ? 'animate-spin' : ''}`} />
                 </button>
             </div>

             {/* Add Form */}
             <div className="bg-gray-900/50 p-4 rounded-lg border border-gray-700 flex flex-col sm:flex-row gap-4 items-end">
                 <div className="flex-1 w-full">
                     <label className="text-xs font-bold text-gray-500 uppercase block mb-1">Key</label>
                     <input 
                        type="text" 
                        value={newKey}
                        onChange={(e) => setNewKey(e.target.value)}
                        placeholder="e.g. OPENAI_API_KEY"
                        className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-sm text-green-400 font-mono focus:border-green-500 outline-none"
                     />
                 </div>
                 <div className="flex-1 w-full">
                     <label className="text-xs font-bold text-gray-500 uppercase block mb-1">Value</label>
                     <input 
                        type="password" 
                        value={newValue}
                        onChange={(e) => setNewValue(e.target.value)}
                        placeholder="sk-..."
                        className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-sm text-white font-mono focus:border-green-500 outline-none"
                     />
                 </div>
                 <button 
                    onClick={handleAddVariable}
                    disabled={isSyncing || !newKey || !newValue}
                    className="bg-green-600 hover:bg-green-500 text-white px-4 py-2 rounded font-bold text-sm h-10 flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed w-full sm:w-auto justify-center"
                 >
                     {isSyncing ? <Spinner className="w-4 h-4" /> : <PlusCircleIcon className="w-5 h-5" />}
                     SAVE
                 </button>
             </div>

             {/* List */}
             <div className="flex-1 overflow-y-auto bg-gray-900/30 rounded-xl border border-gray-800">
                 {variables.length === 0 ? (
                     <div className="text-center text-gray-500 p-12">
                         No variables stored. Add keys to auto-inject them into generated scripts.
                     </div>
                 ) : (
                     <table className="w-full text-left border-collapse">
                         <thead className="bg-gray-800 text-xs text-gray-400 uppercase font-mono sticky top-0">
                             <tr>
                                 <th className="p-4">Key</th>
                                 <th className="p-4">Last Updated</th>
                                 <th className="p-4 text-right">Action</th>
                             </tr>
                         </thead>
                         <tbody className="divide-y divide-gray-800">
                             {variables.map(v => (
                                 <tr key={v.id} className="hover:bg-white/5 transition-colors">
                                     <td className="p-4 font-mono text-sm text-green-400">{v.key}</td>
                                     <td className="p-4 text-xs text-gray-500">{new Date(v.updatedAt).toLocaleDateString()}</td>
                                     <td className="p-4 text-right">
                                         <button 
                                            onClick={() => handleDelete(v.id)}
                                            className="text-gray-500 hover:text-red-400 transition-colors"
                                         >
                                             <CloseIcon className="w-4 h-4" />
                                         </button>
                                     </td>
                                 </tr>
                             ))}
                         </tbody>
                     </table>
                 )}
             </div>
        </div>
    );
};

export default VariablesView;
