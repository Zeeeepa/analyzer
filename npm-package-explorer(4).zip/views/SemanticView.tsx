// DEPRECATED
export default function SemanticView() { return null; }