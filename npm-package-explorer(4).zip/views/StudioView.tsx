// DEPRECATED
export default function StudioView() { return null; }