// DEPRECATED
export default function MetadataView() { return null; }