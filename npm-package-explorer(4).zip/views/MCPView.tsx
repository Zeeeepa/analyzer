
import React, { useState, useEffect } from 'react';
import { McpSource, McpPackage, McpServer } from '../types';
import { useGithubData } from '../hooks/useGithubData';
import { useStudio } from '../contexts/StudioContext';
import DataSyncControls from '../components/DataSyncControls';
import Spinner from '../components/Spinner';
import McpCard from '../components/McpCard';
import { STORAGE_PATHS } from '../constants/config';

// Edit Modals
import McpSourceModal from '../components/modals/McpSourceModal';
import McpPackageModal from '../components/modals/McpPackageModal';
import McpServerModal from '../components/modals/McpServerModal';

// Detail View Modals
import McpSourceDetailModal from '../components/modals/McpSourceDetailModal';
import McpPackageDetailModal from '../components/modals/McpPackageDetailModal';

type SubView = 'sources' | 'packages' | 'servers';

const MCPView: React.FC = () => {
  const { githubConfig, isGithubConfigured } = useStudio();
  const [subView, setSubView] = useState<SubView>('sources');
  
  // Edit/Add Modal States
  const [isSourceModalOpen, setIsSourceModalOpen] = useState(false);
  const [editingSource, setEditingSource] = useState<McpSource | null>(null);
  
  const [isPackageModalOpen, setIsPackageModalOpen] = useState(false);
  const [editingPackage, setEditingPackage] = useState<McpPackage | null>(null);
  
  const [isServerModalOpen, setIsServerModalOpen] = useState(false);
  const [editingServer, setEditingServer] = useState<McpServer | null>(null);

  // Detail View Modal States
  const [detailSource, setDetailSource] = useState<McpSource | null>(null);
  const [detailPackage, setDetailPackage] = useState<McpPackage | null>(null);

  // Data Hooks - Updated Paths
  const sourcesData = useGithubData<McpSource>(
    githubConfig, isGithubConfigured, STORAGE_PATHS.MCP_SOURCES, 'MCP Sources'
  );
  const packagesData = useGithubData<McpPackage>(
    githubConfig, isGithubConfigured, STORAGE_PATHS.MCP_PACKAGES, 'MCP Packages'
  );
  const serversData = useGithubData<McpServer>(
    githubConfig, isGithubConfigured, STORAGE_PATHS.MCP_SERVERS, 'MCP Servers'
  );

  useEffect(() => {
    if (isGithubConfigured) {
        sourcesData.load();
        packagesData.load();
        serversData.load();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isGithubConfigured]);

  // --- Handlers ---
  
  // Sources
  const handleOpenAddSource = () => { setEditingSource(null); setIsSourceModalOpen(true); };
  const handleOpenEditSource = (source: McpSource) => { setEditingSource(source); setIsSourceModalOpen(true); };
  const handleSaveSource = (source: McpSource) => {
    if (editingSource) sourcesData.update(editingSource.id!, source);
    else sourcesData.add(source);
    setIsSourceModalOpen(false);
  };
  const handleDeleteSource = (id: string) => { if (window.confirm('Delete this source?')) sourcesData.remove(id); };
  
  // Packages
  const handleOpenAddPackage = () => { setEditingPackage(null); setIsPackageModalOpen(true); };
  const handleOpenEditPackage = (pkg: McpPackage) => { setEditingPackage(pkg); setIsPackageModalOpen(true); };
  const handleSavePackage = (pkg: McpPackage) => {
    if (editingPackage) packagesData.update(editingPackage.id!, pkg);
    else packagesData.add(pkg);
    setIsPackageModalOpen(false);
  };
  const handleDeletePackage = (id: string) => { if (window.confirm('Delete this package?')) packagesData.remove(id); };

  // Servers
  const handleOpenAddServer = () => { setEditingServer(null); setIsServerModalOpen(true); };
  const handleOpenEditServer = (server: McpServer) => { setEditingServer(server); setIsServerModalOpen(true); };
  const handleSaveServer = (server: McpServer) => {
    if (editingServer) serversData.update(editingServer.id!, server);
    else serversData.add(server);
    setIsServerModalOpen(false);
  };
  const handleDeleteServer = (id: string) => { if (window.confirm('Delete this server?')) serversData.remove(id); };


  const renderContent = () => {
      let data: any[] = [];
      let isLoading = false;
      let error = null;
      let type: 'source' | 'package' | 'server' = 'source';
      let onEdit: (item: any) => void = () => {};
      let onDelete: (id: string) => void = () => {};
      let onSelect: (item: any) => void = () => {};

      if (subView === 'sources') {
          data = sourcesData.data; isLoading = sourcesData.isLoading; error = sourcesData.error; type = 'source';
          onEdit = handleOpenEditSource; onDelete = handleDeleteSource;
          onSelect = setDetailSource;
      } else if (subView === 'packages') {
          data = packagesData.data; isLoading = packagesData.isLoading; error = packagesData.error; type = 'package';
          onEdit = handleOpenEditPackage; onDelete = handleDeletePackage;
          onSelect = setDetailPackage;
      } else {
          data = serversData.data; isLoading = serversData.isLoading; error = serversData.error; type = 'server';
          onEdit = handleOpenEditServer; onDelete = handleDeleteServer;
          // Servers don't have a detail view yet, just edit
          onSelect = handleOpenEditServer; 
      }

      if (isLoading) return <div className="flex justify-center p-8"><Spinner text={`Loading ${subView}...`} /></div>;
      if (error) return <p className="text-center text-red-400 p-8">{error}</p>;
      if (data.length === 0) return (
          <div className="text-center text-gray-500 p-8 bg-gray-800/50 rounded-lg">
              <p>No {subView} found. Add your first {subView.slice(0, -1)}.</p>
          </div>
      );

      return (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {data.map(item => (
                  <McpCard 
                    key={item.id} 
                    item={item} 
                    type={type} 
                    onSelect={() => onSelect(item)}
                    onEdit={(e) => onEdit(item)}
                    onDelete={(e) => onDelete(item.id)}
                  />
              ))}
          </div>
      );
  };

  const getActiveDataHook = () => {
      if (subView === 'sources') return sourcesData;
      if (subView === 'packages') return packagesData;
      return serversData;
  };
  const activeData = getActiveDataHook();

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-gray-900/30 p-2 rounded">
        <div className="bg-gray-800/50 rounded-lg p-1 inline-flex gap-2">
            <button onClick={() => setSubView('sources')} className={`px-4 py-1.5 text-sm rounded-md transition-colors ${subView === 'sources' ? 'bg-orange-600 text-white' : 'hover:bg-gray-700'}`}>
                Sources
            </button>
            <button onClick={() => setSubView('packages')} className={`px-4 py-1.5 text-sm rounded-md transition-colors ${subView === 'packages' ? 'bg-blue-600 text-white' : 'hover:bg-gray-700'}`}>
                Packages
            </button>
            <button onClick={() => setSubView('servers')} className={`px-4 py-1.5 text-sm rounded-md transition-colors ${subView === 'servers' ? 'bg-purple-600 text-white' : 'hover:bg-gray-700'}`}>
                Servers
            </button>
        </div>
        <div className="flex items-center gap-4 ml-auto">
            <button 
                onClick={
                    subView === 'sources' ? handleOpenAddSource : 
                    subView === 'packages' ? handleOpenAddPackage : 
                    handleOpenAddServer
                } 
                className={`text-white px-4 py-2 rounded-md transition-colors text-sm font-medium shadow-sm ${
                    subView === 'sources' ? 'bg-orange-600 hover:bg-orange-500' : 
                    subView === 'packages' ? 'bg-blue-600 hover:bg-blue-500' : 
                    'bg-purple-600 hover:bg-purple-500'
                }`}
            >
                Add {subView.slice(0, -1).charAt(0).toUpperCase() + subView.slice(0, -1).slice(1)}
            </button>
            <DataSyncControls 
                onLoad={activeData.load}
                onSave={activeData.save}
                isLoading={activeData.isLoading}
                isSyncing={activeData.isSyncing}
                isConfigured={isGithubConfigured}
                saveColor={subView === 'sources' ? 'orange' : subView === 'packages' ? 'blue' : 'purple'}
            />
        </div>
      </div>
      
       <div className="mt-2">
         {!isGithubConfigured 
            ? <p className="text-center text-yellow-400 mt-8">Please configure your GitHub connection in the settings.</p>
            : renderContent()
         }
       </div>

        {/* Edit Modals */}
       <McpSourceModal 
          isOpen={isSourceModalOpen}
          onClose={() => setIsSourceModalOpen(false)}
          onSave={handleSaveSource}
          initialData={editingSource}
        />
        <McpPackageModal
            isOpen={isPackageModalOpen}
            onClose={() => setIsPackageModalOpen(false)}
            onSave={handleSavePackage}
            initialData={editingPackage}
            sources={sourcesData.data}
        />
        <McpServerModal
            isOpen={isServerModalOpen}
            onClose={() => setIsServerModalOpen(false)}
            onSave={handleSaveServer}
            initialData={editingServer}
        />

        {/* Detail Views */}
        <McpSourceDetailModal
            isOpen={!!detailSource}
            onClose={() => setDetailSource(null)}
            source={detailSource}
            onAddServer={(server) => {
                serversData.add(server);
                setSubView('servers'); // Switch to servers tab to see it
                setDetailSource(null); // Close modal
            }}
        />
        <McpPackageDetailModal
            isOpen={!!detailPackage}
            onClose={() => setDetailPackage(null)}
            pkg={detailPackage}
        />
    </div>
  );
};

export default MCPView;
