
import React, { useState, useEffect } from 'react';
import { EnrichedPackageInfo, NpmUser } from '../types';
import PackageCard from '../components/PackageCard';
import UserCard from '../components/UserCard';
import Spinner from '../components/Spinner';
import { useGithubData } from '../hooks/useGithubData';
import { githubDataService } from '../services/githubDataService';
import { useToast } from '../components/Toast';
import { useStudio } from '../contexts/StudioContext';
import { SearchIcon, CubeIcon, SyncIcon, PlusCircleIcon, DatabaseIcon, SortIcon, RefreshIcon, GitHubIcon } from '../components/icons';
import { enrichPackageInfo, getPackagesByMaintainer } from '../services/npmService';
import { getAllPackages, updatePackage } from '../services/dbService';
import AddFavoritesModal from '../components/AddFavoritesModal';
import UserDetailModal from '../components/modals/UserDetailModal';
import { STORAGE_PATHS } from '../constants/config';

interface NPMViewProps {
    onQuickScan?: (pkg: EnrichedPackageInfo) => void;
}

type SortOption = 'name' | 'loc' | 'files';
type ViewMode = 'packages' | 'users';

const NPMView: React.FC<NPMViewProps> = ({ onQuickScan }) => {
  const { db, githubConfig, isGithubConfigured, setViewedResource } = useStudio();
  
  // -- Data Hooks --
  
  // 1. Packages Data
  const { 
    data: githubData, 
    load: loadGithubData,
    setData: setGithubData, // Expose setData
    isLoading: isGithubLoading, 
  } = useGithubData<EnrichedPackageInfo>(
    githubConfig,
    isGithubConfigured,
    STORAGE_PATHS.NPM,
    'NPM Packages'
  );

  // 2. Users Data
  const {
      data: usersData,
      load: loadUsersData,
      setData: setUsersData,
      isLoading: isUsersLoading
  } = useGithubData<NpmUser>(
      githubConfig,
      isGithubConfigured,
      STORAGE_PATHS.USERS,
      'NPM Users'
  );

  const [viewMode, setViewMode] = useState<ViewMode>('packages');
  const [packages, setPackages] = useState<EnrichedPackageInfo[]>([]);
  const [filteredPackages, setFilteredPackages] = useState<EnrichedPackageInfo[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<NpmUser[]>([]);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('name');
  
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);
  const [newUsername, setNewUsername] = useState('');

  const [selectedUser, setSelectedUser] = useState<NpmUser | null>(null);

  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState('');
  const [isLoadingLocal, setIsLoadingLocal] = useState(true);
  
  const { addToast } = useToast();

  // 1. Initial Data Load Strategy
  useEffect(() => {
    const init = async () => {
        setIsLoadingLocal(true);
        if (isGithubConfigured) {
             await Promise.all([loadGithubData(), loadUsersData()]);
        } else if (db) {
             const local = await getAllPackages(db);
             setPackages(local);
        }
        setIsLoadingLocal(false);
    };
    init();
  }, [isGithubConfigured, db, loadGithubData, loadUsersData]);

  // 2. Sync GitHub Data to View State
  useEffect(() => {
      if (isGithubConfigured && githubData.length > 0) {
          const unique = githubData.reduce((acc, current) => {
              const x = acc.find(item => item.name === current.name);
              if (!x) return acc.concat([current]);
              return acc;
          }, [] as EnrichedPackageInfo[]);
          
          setPackages(unique);
          if(db) unique.forEach(p => updatePackage(db, p));
      }
  }, [githubData, isGithubConfigured, db]);

  // 3. Filter & Sort Logic (Packages)
  useEffect(() => {
      let result = packages;
      if (searchQuery && viewMode === 'packages') {
          const q = searchQuery.toLowerCase();
          result = result.filter(p => 
              p.name.toLowerCase().includes(q) || 
              (p.description && p.description.toLowerCase().includes(q))
          );
      }
      result = [...result].sort((a, b) => {
          if (sortBy === 'loc') return (b.totalLinesOfCode || 0) - (a.totalLinesOfCode || 0);
          if (sortBy === 'files') return (b.fileCount || 0) - (a.fileCount || 0);
          return a.name.localeCompare(b.name);
      });
      setFilteredPackages(result);
  }, [packages, searchQuery, sortBy, viewMode]);

  // 4. Filter Logic (Users)
  useEffect(() => {
      let result = usersData;
      if (searchQuery && viewMode === 'users') {
          const q = searchQuery.toLowerCase();
          result = result.filter(u => u.username.toLowerCase().includes(q));
      }
      setFilteredUsers(result);
  }, [usersData, searchQuery, viewMode]);
  
  const handleToggleFavorite = async (packageName: string) => {
      const exists = packages.find(p => p.name === packageName);
      
      if (exists) {
          if (window.confirm(`Remove ${packageName} from tracking?`)) {
              // Atomically update both local packages and hook data to prevent reversion
              const newList = packages.filter(p => p.name !== packageName);
              
              setPackages(newList);
              setGithubData(newList); 

              if (isGithubConfigured) {
                  try {
                      // Fire and forget save, UI is already updated
                      githubDataService.saveData(githubConfig, STORAGE_PATHS.NPM, newList, `Remove ${packageName}`);
                      addToast({ message: "Removed from GitHub.", type: 'info' });
                  } catch (e) {
                      addToast({ message: "Failed to update GitHub.", type: 'error' });
                      // We don't revert UI here to keep it snappy, user can reload if critical
                  }
              }
          }
      } else {
          await handleAddPackages([packageName]);
      }
  };

  const handleUpdatePackages = async () => {
      if (isSyncing) return;
      setIsSyncing(true);
      setSyncStatus('CHECKING REGISTRY FOR UPDATES...');
      let updatedCount = 0;
      const updatedList: EnrichedPackageInfo[] = [];
      const batchSize = 5;

      try {
          for (let i = 0; i < packages.length; i += batchSize) {
              const batch = packages.slice(i, i + batchSize);
              const batchResults = await Promise.all(batch.map(async (pkg) => {
                  try {
                      const fresh = await enrichPackageInfo(pkg.name);
                      if (fresh && (fresh.version !== pkg.version || pkg.status !== 'enriched')) {
                          updatedCount++;
                          return { ...pkg, ...fresh, status: 'enriched' } as EnrichedPackageInfo;
                      }
                      return pkg;
                  } catch (e) { return pkg; }
              }));
              updatedList.push(...batchResults);
              setSyncStatus(`PROCESSED ${Math.min(i + batchSize, packages.length)}/${packages.length}...`);
          }

          if (updatedCount > 0) {
              setPackages(updatedList);
              setGithubData(updatedList);
              if (isGithubConfigured) {
                  setSyncStatus('SAVING UPDATES...');
                  await githubDataService.saveData(githubConfig, STORAGE_PATHS.NPM, updatedList, `Auto-Update ${updatedCount} packages`);
              }
              if (db) updatedList.forEach(p => updatePackage(db, p));
              addToast({ message: `Updated ${updatedCount} packages.`, type: 'success' });
          } else {
              addToast({ message: "All packages up to date.", type: 'info' });
          }
      } catch (e) {
          console.error(e);
          addToast({ message: "Update failed.", type: 'error' });
      } finally {
          setIsSyncing(false);
          setSyncStatus('');
      }
  };

  const handleMaintainerClick = async (username: string) => {
      // 1. Check Local Cache
      const existingUser = usersData.find(u => u.username === username);
      if (existingUser) {
          setSelectedUser(existingUser);
          return;
      }

      setIsSyncing(true);
      setSyncStatus(`DISCOVERING USER: ${username}...`);
      try {
          const newUser = await getPackagesByMaintainer(username);
          if (newUser && newUser.packageCount > 0) {
              const newItem = { ...newUser, id: crypto.randomUUID() };
              const newUsersList = [...usersData, newItem];
              
              setUsersData(newUsersList);
              
              if (isGithubConfigured) {
                  setSyncStatus(`SAVING USER ${username}...`);
                  await githubDataService.saveData(githubConfig, STORAGE_PATHS.USERS, newUsersList, `Discovered user ${username}`);
                  addToast({ message: `User ${username} discovered and saved.`, type: 'success' });
              } else {
                  addToast({ message: `User ${username} cached locally.`, type: 'info' });
              }
              setSelectedUser(newItem);
          } else {
              addToast({ message: `User '${username}' not found.`, type: 'error' });
          }
      } catch(e) {
          console.error(e);
          addToast({ message: "Failed to fetch user.", type: 'error' });
      } finally {
          setIsSyncing(false);
          setSyncStatus('');
      }
  };

  const handleAddUser = async () => {
      if (!newUsername.trim()) return;
      await handleMaintainerClick(newUsername);
      setNewUsername('');
      setIsAddUserModalOpen(false);
  };

  const handleUpdateAllUsers = async () => {
      if (isSyncing || usersData.length === 0) return;
      setIsSyncing(true);
      setSyncStatus('UPDATING USERS...');
      
      const updatedUsers: NpmUser[] = [];
      try {
          for (let i = 0; i < usersData.length; i++) {
              const user = usersData[i];
              setSyncStatus(`FETCHING: ${user.username}...`);
              const fresh = await getPackagesByMaintainer(user.username);
              updatedUsers.push(fresh ? { ...fresh, id: user.id } : user);
          }
          
          setUsersData(updatedUsers);
          if (isGithubConfigured) {
              setSyncStatus('SAVING DATA...');
              await githubDataService.saveData(githubConfig, STORAGE_PATHS.USERS, updatedUsers, "Update all users");
              addToast({ message: "All users updated.", type: 'success' });
          }
      } catch (e) {
          addToast({ message: "Failed to update users.", type: 'error' });
      } finally {
          setIsSyncing(false);
          setSyncStatus('');
      }
  };

  const handleAddPackages = async (names: string[]): Promise<{ success: string[]; failed: string[] }> => {
      const successNames: string[] = [];
      const failedNames: string[] = [];
      const newPackages: EnrichedPackageInfo[] = [];

      setIsSyncing(true);
      setSyncStatus('ENRICHING MODULES...');

      const existingNames = new Set(packages.map(p => p.name));
      const uniqueNames = [...new Set(names)].filter(name => !existingNames.has(name));
      
      for (const name of uniqueNames) {
          try {
              setSyncStatus(`FETCHING: ${name}...`);
              const enriched = await enrichPackageInfo(name);
              if (enriched) {
                  const newPkg = { ...enriched, isFavorite: 1, status: 'enriched', id: crypto.randomUUID() } as EnrichedPackageInfo;
                  newPackages.push(newPkg);
                  if (db) await updatePackage(db, newPkg);
                  successNames.push(name);
              } else {
                  failedNames.push(name);
              }
          } catch (e) { failedNames.push(name); }
      }

      if (newPackages.length > 0) {
          const updatedList = [...packages, ...newPackages];
          setPackages(updatedList);
          setGithubData(updatedList);
          
          if (isGithubConfigured) {
              setSyncStatus('SAVING TO GITHUB...');
              try {
                  await githubDataService.saveData(githubConfig, STORAGE_PATHS.NPM, updatedList, `Add ${newPackages.length} new packages`);
                  addToast({ message: "New packages saved.", type: 'success' });
              } catch (e) { addToast({ message: "Failed to save.", type: 'error' }); }
          }
      }
      setIsSyncing(false);
      setSyncStatus('');
      return { success: successNames, failed: failedNames };
  };

  const openDetails = async (pkg: EnrichedPackageInfo | Partial<EnrichedPackageInfo>) => {
      // 1. Initial State Set (Optimistic)
      setViewedResource({
          type: 'npm',
          name: pkg.name!,
          version: pkg.version || 'latest',
          description: pkg.description,
          data: pkg as any
      });

      // 2. Fetch Full Details if needed
      if (pkg.status !== 'enriched') {
          setIsSyncing(true);
          try {
              const fresh = await enrichPackageInfo(pkg.name!);
              if (fresh) {
                  const fullPkg = { ...pkg, ...fresh, status: 'enriched' } as EnrichedPackageInfo;
                  // Update the viewed resource with full data
                  setViewedResource({
                      type: 'npm',
                      name: fullPkg.name,
                      version: fullPkg.version,
                      description: fullPkg.description,
                      data: fullPkg
                  });
              }
          } catch(e) {
              console.warn("Details fetch failed, viewing partial data", e);
          } finally {
              setIsSyncing(false);
          }
      }
  };

  const handleSearchKeyDown = (e: React.KeyboardEvent) => {
      if (e.key === 'Enter' && searchQuery.trim() && viewMode === 'users') {
          handleMaintainerClick(searchQuery.trim());
      }
  };

  if (isLoadingLocal || (isGithubConfigured && isGithubLoading && packages.length === 0)) {
    return (
        <div className="flex flex-col items-center justify-center h-full gap-4">
            <Spinner className="w-8 h-8 text-red-500" />
            <div className="text-red-400 font-mono animate-pulse">LOADING MODULE DATABASE...</div>
        </div>
    );
  }

  return (
    <div className="flex flex-col gap-6 h-full">
      <div className="flex items-center justify-between bg-black/40 border border-white/10 p-4 rounded-xl backdrop-blur-md shadow-[0_0_30px_rgba(0,0,0,0.5)] shrink-0">
         <div className="flex items-center gap-4">
            <div className="bg-red-500/10 p-2.5 rounded-lg border border-red-500/20 shadow-[0_0_10px_rgba(239,68,68,0.2)]">
                <CubeIcon className="w-6 h-6 text-red-500" />
            </div>
            <div>
                <h2 className="text-xl font-bold text-white tracking-tight neon-text">MODULE REGISTRY</h2>
                <div className="flex items-center gap-2 text-[10px] text-red-400/70 font-mono tracking-wider">
                    <span className="flex items-center gap-1">
                        <DatabaseIcon className="w-3 h-3" />
                        {isGithubConfigured ? 'GITHUB SYNC ACTIVE' : 'LOCAL STORAGE ONLY'}
                    </span>
                    <span className="w-1 h-1 rounded-full bg-red-500"></span>
                    <span>{viewMode === 'packages' ? packages.length : usersData.length} ENTRIES</span>
                </div>
            </div>
         </div>
         
         <div className="flex items-center gap-4">
             <div className="flex bg-gray-900 rounded-lg p-1 border border-white/10">
                 <button onClick={() => setViewMode('packages')} className={`px-3 py-1.5 rounded text-xs font-bold transition-all ${viewMode === 'packages' ? 'bg-red-600 text-white' : 'text-gray-400 hover:text-white'}`}>MODULES</button>
                 <button onClick={() => setViewMode('users')} className={`px-3 py-1.5 rounded text-xs font-bold transition-all ${viewMode === 'users' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'}`}>USERS</button>
             </div>

             <div className="relative group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-red-500 to-orange-500 rounded-lg blur opacity-20 group-hover:opacity-40 transition duration-1000 group-hover:duration-200"></div>
                <div className="relative flex items-center bg-black border border-white/10 rounded-lg px-3 py-2">
                    <SearchIcon className="w-4 h-4 text-gray-400 mr-2" />
                    <input 
                        type="text" 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        onKeyDown={handleSearchKeyDown}
                        placeholder={viewMode === 'packages' ? "SEARCH MODULES..." : "SEARCH USER & ENTER..."}
                        className="bg-transparent border-none outline-none text-sm text-white placeholder-gray-600 w-48 font-mono focus:w-64 transition-all"
                    />
                </div>
             </div>

             {viewMode === 'packages' && (
                 <div className="flex items-center bg-black border border-white/10 rounded-lg px-3 py-2">
                     <SortIcon className="w-4 h-4 text-gray-400 mr-2" />
                     <select 
                        value={sortBy} 
                        onChange={(e) => setSortBy(e.target.value as SortOption)}
                        className="bg-transparent border-none outline-none text-sm text-gray-300 font-mono cursor-pointer hover:text-white transition-colors"
                     >
                         <option value="name">Name</option>
                         <option value="loc">LOC</option>
                         <option value="files">Files</option>
                     </select>
                 </div>
             )}

             {isSyncing && (
                 <div className="flex items-center gap-3 bg-red-900/20 px-4 py-2 rounded-lg border border-red-500/30">
                     <Spinner className="w-4 h-4 text-red-400" />
                     <span className="text-xs font-mono text-red-400 animate-pulse tracking-widest truncate max-w-[150px]">{syncStatus}</span>
                 </div>
             )}

             <button 
                onClick={viewMode === 'packages' ? handleUpdatePackages : handleUpdateAllUsers}
                disabled={isSyncing}
                className={`relative overflow-hidden px-4 py-2.5 rounded-lg font-bold text-sm uppercase tracking-widest transition-all ${isSyncing ? 'bg-gray-800 text-gray-500 border border-gray-700 cursor-not-allowed' : viewMode === 'packages' ? 'bg-orange-900/20 text-orange-400 border border-orange-500/50 hover:bg-orange-500 hover:text-black' : 'bg-purple-900/20 text-purple-400 border border-purple-500/50 hover:bg-purple-500 hover:text-white'}`}
                title="Update metadata from Registry"
             >
                 <div className="flex items-center gap-2"><RefreshIcon className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} /> UPDATE ALL</div>
             </button>

             <button 
                onClick={() => viewMode === 'packages' ? setIsImportModalOpen(true) : setIsAddUserModalOpen(true)}
                className="bg-white/5 hover:bg-white/10 text-white p-2.5 rounded-lg border border-white/10 transition-colors"
                title={viewMode === 'packages' ? "Add Package" : "Add User"}
            >
                <PlusCircleIcon className="w-5 h-5" />
            </button>
         </div>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar pr-2">
          {viewMode === 'packages' ? (
              filteredPackages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-64 text-gray-600 p-12 bg-black/20 rounded-xl border border-white/5 border-dashed">
                  <CubeIcon className="w-16 h-16 opacity-20 mb-4" />
                  <p className="font-mono text-sm tracking-widest">NO MODULES FOUND</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4 pb-4">
                    {filteredPackages.map(pkg => (
                        <PackageCard 
                            key={pkg.name} 
                            pkg={pkg} 
                            onSelect={openDetails} 
                            onToggleFavorite={handleToggleFavorite}
                            onQuickScan={onQuickScan}
                            onMaintainerClick={handleMaintainerClick}
                        />
                    ))}
                </div>
              )
          ) : (
              filteredUsers.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-64 text-gray-600 p-12 bg-black/20 rounded-xl border border-white/5 border-dashed">
                  <GitHubIcon className="w-16 h-16 opacity-20 mb-4" />
                  <p className="font-mono text-sm tracking-widest">NO USERS FOUND</p>
                  {searchQuery && <p className="text-xs mt-2 text-purple-400">Press ENTER to search registry for "{searchQuery}"</p>}
                  <button onClick={() => setIsAddUserModalOpen(true)} className="mt-4 text-purple-500 hover:text-purple-400 text-sm hover:underline">ADD USER MANUAL</button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 pb-4">
                    {filteredUsers.map(user => (
                        <UserCard key={user.username} user={user} onSelect={setSelectedUser} />
                    ))}
                </div>
              )
          )}
      </div>

      {isImportModalOpen && <AddFavoritesModal onClose={() => setIsImportModalOpen(false)} onAdd={handleAddPackages} />}

      {isAddUserModalOpen && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
              <div className="bg-gray-800 border border-gray-700 rounded-lg shadow-2xl w-full max-w-sm flex flex-col">
                  <header className="p-4 border-b border-gray-700 font-bold text-purple-400">Track New User</header>
                  <div className="p-6">
                      <label className="text-sm text-gray-400 mb-2 block">NPM Username</label>
                      <input type="text" value={newUsername} onChange={e => setNewUsername(e.target.value)} className="w-full bg-black border border-gray-600 rounded p-2 text-white outline-none focus:border-purple-500" placeholder="e.g. sindresorhus" autoFocus />
                  </div>
                  <footer className="p-4 border-t border-gray-700 flex justify-end gap-3">
                      <button onClick={() => setIsAddUserModalOpen(false)} className="px-4 py-2 text-gray-400 hover:text-white">Cancel</button>
                      <button onClick={handleAddUser} disabled={!newUsername} className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-500 disabled:opacity-50">Add User</button>
                  </footer>
              </div>
          </div>
      )}

      <UserDetailModal
          isOpen={!!selectedUser}
          onClose={() => setSelectedUser(null)}
          user={selectedUser}
          onSelectPackage={(pkg) => {
              setSelectedUser(null);
              setTimeout(() => openDetails(pkg), 100);
          }}
          onToggleFavorite={handleToggleFavorite}
          trackedPackages={packages}
      />
    </div>
  );
};

export default NPMView;
