// DEPRECATED
export default function SavedView() { return null; }