// DEPRECATED
export default function SearchView() { return null; }