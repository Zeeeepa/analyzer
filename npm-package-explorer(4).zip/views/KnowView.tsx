
import React, { useState, useEffect } from 'react';
import { KnowledgeItem } from '../types';
import { useGithubData } from '../hooks/useGithubData';
import { useStudio } from '../contexts/StudioContext';
import DataSyncControls from '../components/DataSyncControls';
import Spinner from '../components/Spinner';
import KnowledgeItemModal from '../components/modals/KnowledgeItemModal';
import { STORAGE_PATHS } from '../constants/config';

// Sub Views
import MCPView from './MCPView';
import ApiView from './ApiView';
import { DatabaseIcon, CubeIcon, SyncIcon } from '../components/icons';

type SubView = 'knowledge' | 'mcp' | 'api';

const KnowView: React.FC = () => {
  const { githubConfig, isGithubConfigured } = useStudio();
  const [subView, setSubView] = useState<SubView>('knowledge');

  // --- Knowledge Items Logic ---
  const { data: items, isLoading, isSyncing, error, load, save, add, update, remove } = useGithubData<KnowledgeItem>(
    githubConfig,
    isGithubConfigured,
    STORAGE_PATHS.KNOWLEDGE,
    'Knowledge Items'
  );

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<KnowledgeItem | null>(null);

  useEffect(() => {
    if (isGithubConfigured && subView === 'knowledge') {
      load();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isGithubConfigured, subView]);

  const handleOpenAddModal = () => {
    setEditingItem(null);
    setIsModalOpen(true);
  };
  
  const handleOpenEditModal = (item: KnowledgeItem) => {
    setEditingItem(item);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingItem(null);
  };

  const handleSaveItem = (item: KnowledgeItem) => {
    if (editingItem) {
      update(editingItem.id!, item);
    } else {
      add(item);
    }
    handleCloseModal();
  };

  const handleDeleteItem = (itemId: string) => {
    if (window.confirm('Are you sure you want to delete this item? This action only takes effect locally until you save.')) {
        remove(itemId);
    }
  };

  const renderKnowledgeContent = () => {
    if (isLoading) {
        return <div className="flex justify-center"><Spinner text="Loading items..." /></div>;
    }
    if (error) {
        return <p className="text-center text-red-400">{error}</p>;
    }
    if (items.length === 0 && !isLoading) {
      return (
         <div className="text-center text-gray-500 p-8 bg-gray-800/50 rounded-lg">
            <p>No knowledge items found. Try loading from GitHub or add your first item.</p>
             <button onClick={handleOpenAddModal} className="mt-4 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-500">
                Add New Item
            </button>
        </div>
      );
    }
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map(item => (
            <div key={item.id} className="bg-gray-800 border border-gray-700 rounded-lg p-4 flex flex-col gap-2 shadow-md">
                <div className="flex justify-between items-start">
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full self-start ${
                        item.type === 'url' ? 'bg-blue-900 text-blue-300' :
                        item.type === 'file' ? 'bg-purple-900 text-purple-300' :
                        'bg-gray-700 text-gray-300'
                    }`}>{item.type}</span>
                    <div className="flex gap-2">
                        <button onClick={() => handleOpenEditModal(item)} className="text-xs text-yellow-400 hover:text-yellow-300">Edit</button>
                        <button onClick={() => handleDeleteItem(item.id!)} className="text-xs text-red-400 hover:text-red-300">Delete</button>
                    </div>
                </div>
                <h3 className="font-bold text-blue-300 line-clamp-1" title={item.title}>{item.title}</h3>
                <p className="text-sm text-gray-400 break-all line-clamp-2" title={item.source}>{item.source}</p>
                 {item.tags && item.tags.length > 0 && String(item.tags) !== '' && (
                    <div className="flex flex-wrap gap-2 mt-2">
                        {(Array.isArray(item.tags) ? item.tags : String(item.tags).split(';')).map(tag => (
                             tag && <span key={tag} className="text-xs bg-gray-700 px-2 py-0.5 rounded-full text-gray-300">{tag}</span>
                        ))}
                    </div>
                )}
            </div>
        ))}
      </div>
    );
  };
  
  return (
    <div className="flex flex-col gap-6">
       {/* Top Tabs */}
       <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-gray-800 p-2 rounded-lg border border-gray-700">
            <div className="flex gap-2 overflow-x-auto w-full sm:w-auto">
                <button onClick={() => setSubView('knowledge')} className={`px-4 py-2 text-sm font-bold rounded-md transition-colors flex items-center gap-2 ${subView === 'knowledge' ? 'bg-blue-600 text-white' : 'hover:bg-gray-700 text-gray-300'}`}>
                    <DatabaseIcon className="w-4 h-4" /> Knowledge
                </button>
                <button onClick={() => setSubView('mcp')} className={`px-4 py-2 text-sm font-bold rounded-md transition-colors flex items-center gap-2 ${subView === 'mcp' ? 'bg-orange-600 text-white' : 'hover:bg-gray-700 text-gray-300'}`}>
                    <CubeIcon className="w-4 h-4" /> MCP
                </button>
                 <button onClick={() => setSubView('api')} className={`px-4 py-2 text-sm font-bold rounded-md transition-colors flex items-center gap-2 ${subView === 'api' ? 'bg-yellow-600 text-white' : 'hover:bg-gray-700 text-gray-300'}`}>
                    <SyncIcon className="w-4 h-4" /> API
                </button>
            </div>
            
            {/* Actions for Knowledge View Only */}
            {subView === 'knowledge' && (
                 <div className="flex items-center gap-4 ml-auto">
                    <button onClick={handleOpenAddModal} className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-500 text-sm font-medium shadow-sm">
                        Add Item
                    </button>
                    <DataSyncControls
                        onLoad={load}
                        onSave={save}
                        isLoading={isLoading}
                        isSyncing={isSyncing}
                        isConfigured={isGithubConfigured}
                        saveColor="blue"
                    />
                </div>
            )}
        </div>

        {/* Content Area */}
        <div className="min-h-[400px]">
            {!isGithubConfigured ? (
                 <div className="flex flex-col items-center justify-center h-64 text-gray-500 bg-gray-800/30 rounded-lg border border-gray-700/50 border-dashed">
                     <p className="mb-2">GitHub connection required.</p>
                     <p className="text-xs">Please configure your token in Settings.</p>
                 </div>
            ) : (
                <>
                    {subView === 'knowledge' && renderKnowledgeContent()}
                    {subView === 'mcp' && <MCPView />}
                    {subView === 'api' && <ApiView />}
                </>
            )}
        </div>

        <KnowledgeItemModal
            isOpen={isModalOpen}
            onClose={handleCloseModal}
            onSave={handleSaveItem}
            initialData={editingItem}
        />
    </div>
  );
};

export default KnowView;
