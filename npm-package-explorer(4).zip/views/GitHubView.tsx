

import React, { useState, useEffect } from 'react';
import { GitProject, DiffResult } from '../types';
import { useGithubData } from '../hooks/useGithubData';
import { useStudio } from '../contexts/StudioContext';
import Spinner from '../components/Spinner';
import { useToast } from '../components/Toast';
import { CodeBracketIcon, SyncIcon, SettingsIcon, SortIcon } from '../components/icons';
import { getRepoTree, listUserRepos, getCodeFrequency, getCompareData, parseGitHubUrl, getRepoDetails } from '../services/githubService';
import { githubDataService } from '../services/githubDataService';
import SettingsModal from '../components/SettingsModal';
import ProjectCard from '../components/ProjectCard';
import DiffModal from '../components/modals/DiffModal';
import { STORAGE_PATHS } from '../constants/config';

interface GitHubViewProps {
    onQuickScan?: (project: GitProject) => void;
}

type SortOption = 'updated' | 'loc' | 'files' | 'name';

const GitHubView: React.FC<GitHubViewProps> = ({ onQuickScan }) => {
  const { githubConfig, isGithubConfigured, setViewedResource } = useStudio();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  
  // Use projects.csv as source of truth
  const { 
      data: projects, 
      load: loadProjects, 
      setData: setProjects,
      update: updateProject,
      isLoading: isProjectsLoading
  } = useGithubData<GitProject>(
      githubConfig, 
      isGithubConfigured, 
      STORAGE_PATHS.GIT, 
      'Projects'
  );

  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('updated');
  const [filteredProjects, setFilteredProjects] = useState<GitProject[]>([]);
  
  // Diff Modal State
  const [diffModalOpen, setDiffModalOpen] = useState(false);
  const [activeDiff, setActiveDiff] = useState<DiffResult | null>(null);
  const [activeUpstreamName, setActiveUpstreamName] = useState('');

  const { addToast } = useToast();

  useEffect(() => {
      // Only attempt load if fully configured to avoid error spam
      if(isGithubConfigured) loadProjects();
  }, [isGithubConfigured, loadProjects]);

  // Sort and Filter Logic
  useEffect(() => {
      let result = [...projects];
      
      result.sort((a, b) => {
          if (sortBy === 'loc') {
              return (b.totalLinesOfCode || 0) - (a.totalLinesOfCode || 0);
          }
          if (sortBy === 'files') {
              return (b.fileCount || 0) - (a.fileCount || 0);
          }
          if (sortBy === 'name') {
              return a.projectName.localeCompare(b.projectName);
          }
          // Default: Updated At
          const dateA = a.updatedAt ? new Date(a.updatedAt).getTime() : 0;
          const dateB = b.updatedAt ? new Date(b.updatedAt).getTime() : 0;
          return dateB - dateA;
      });

      setFilteredProjects(result);
  }, [projects, sortBy]);

  const openDetails = (project: GitProject) => {
      setViewedResource({
          type: 'github',
          name: project.projectName,
          description: project.description,
          data: project
      });
  };

  const handleOpenDiff = async (project: GitProject) => {
      // Use originUrl as the source of truth for the upstream, or fall back to parsing
      const upstream = parseGitHubUrl(project.originUrl || '');
      
      if (!upstream || !isGithubConfigured) return;

      addToast({ message: "Fetching comparison data...", type: 'info' });
      // We assume main for fallback if not stored, getCompareData will attempt to resolve if needed
      const diff = await getCompareData(githubConfig.token, project.owner, project.projectName, upstream.owner, upstream.repo);
      
      if (diff) {
          setActiveDiff(diff);
          setActiveUpstreamName(`${upstream.owner}/${upstream.repo}`);
          setDiffModalOpen(true);
      } else {
          addToast({ message: "Failed to compare repositories. Check permissions or branch names.", type: 'error' });
      }
  };

  // Helper to analyze repo stats (LoC, file counts, etc) without full deep content scan
  const analyzeRepoStats = async (
      owner: string, 
      repo: string, 
      defaultBranch?: string, 
      upstream?: { owner: string, repo: string, defaultBranch?: string }
    ) => {
    try {
        // Pass defaultBranch if known to optimize fetching
        const treeConfig = { ...githubConfig, owner, repo };
        const tree = await getRepoTree(treeConfig, defaultBranch);
        
        // 1. Basic Stats from Tree
        let fileCount = 0;
        let codeFileCount = 0;
        let docFileCount = 0;
        let totalLinesOfCode = 0;
        let entrypoints: string[] = [];
        
        if (tree) {
            const files = tree.filter(t => t.type === 'blob');
            fileCount = files.length;
            
            const codeExtensions = new Set(['js', 'ts', 'jsx', 'tsx', 'py', 'go', 'rs', 'java', 'c', 'cpp', 'h', 'css', 'html', 'json', 'sql']);
            const docExtensions = new Set(['md', 'txt', 'doc', 'docx', 'pdf']);
            
            const codeFiles = files.filter(f => codeExtensions.has(f.path.split('.').pop()?.toLowerCase() || ''));
            const docFiles = files.filter(f => docExtensions.has(f.path.split('.').pop()?.toLowerCase() || ''));
            
            codeFiles.forEach(f => {
                if (f.size) {
                    totalLinesOfCode += Math.round(f.size / 30); // Rough estimate
                }
            });
            codeFileCount = codeFiles.length;
            docFileCount = docFiles.length;
            
            entrypoints = files.filter(f => 
                ['package.json', 'main.py', 'index.js', 'index.ts', 'App.tsx', 'main.go', 'Cargo.toml'].includes(f.path.split('/').pop() || '')
            ).map(f => f.path);
        }

        // 2. LCPM (Lines Committed Per Month)
        const lcpm = await getCodeFrequency(githubConfig.token, owner, repo);

        // 3. Commits Behind (Fork Check)
        let commitsBehind = 0;
        
        if (upstream && (upstream.owner !== owner || upstream.repo !== repo)) {
            const diff = await getCompareData(
                githubConfig.token, 
                owner, repo, 
                upstream.owner, upstream.repo,
                defaultBranch, // Local branch
                upstream.defaultBranch // Upstream branch
            );
            
            if (diff) {
                // "Ahead by" from Local->Upstream perspective means Upstream is Ahead, so Local is Behind.
                commitsBehind = diff.ahead_by; 
            }
        }

        return {
            fileCount,
            codeFileCount,
            docFileCount,
            totalLinesOfCode,
            entrypoints,
            lcpm,
            commitsBehind
        };
    } catch (e) {
        console.error("Analysis Failed", e);
        return {};
    }
  };

  const handleSyncProtocol = async () => {
      if (!isGithubConfigured) {
          setIsSettingsOpen(true);
          return;
      }
      setIsSyncing(true);
      setSyncStatus('INITIALIZING UPLINK...');
      
      try {
          // 1. Fetch Remote
          setSyncStatus('FETCHING REPO MANIFEST...');
          const remoteRepos = await listUserRepos(githubConfig.token, githubConfig.owner);
          
          // 2. Analyze Differences
          const localMap = new Map<string, GitProject>(projects.map(p => [p.projectName, p]));
          
          const newProjects: GitProject[] = [];
          const updatedList: GitProject[] = [];
          
          // Process Remote List
          for (const repo of remoteRepos) {
              const local = localMap.get(repo.name);
              
              // Identify upstream if fork
              let upstream: { owner: string, repo: string, defaultBranch?: string } | undefined = undefined;
              let originUrl = repo.html_url;

              if (repo.fork) {
                  try {
                      // Fetch full details to get 'parent'. List response doesn't always have it.
                      const details = await getRepoDetails(githubConfig.token, repo.owner.login, repo.name);
                      if (details.parent) {
                          upstream = { 
                              owner: details.parent.owner.login, 
                              repo: details.parent.name,
                              defaultBranch: details.parent.default_branch 
                          };
                          originUrl = details.parent.html_url; // Use upstream as originUrl for "Original Source"
                      }
                  } catch (e) {
                      console.warn("Failed to fetch fork details for", repo.name);
                  }
              }

              // Use detected upstream, or fall back to what we stored locally if sync fails to detect it again (rare)
              const effectiveUpstream = upstream || (local?.originUrl ? parseGitHubUrl(local.originUrl) : undefined) || undefined;
              
              // Ensure we pass a properly structured object if falling back to parseGitHubUrl which doesn't give defaultBranch
              const upstreamArg = effectiveUpstream ? {
                  owner: effectiveUpstream.owner,
                  repo: effectiveUpstream.repo,
                  defaultBranch: 'defaultBranch' in effectiveUpstream ? (effectiveUpstream as any).defaultBranch : undefined
              } : undefined;


              if (!local) {
                  // NEW PROJECT FOUND
                  setSyncStatus(`ANALYZING NEW VECTOR: ${repo.name}...`);
                  
                  const stats = await analyzeRepoStats(repo.owner.login, repo.name, repo.default_branch, upstreamArg);
                  
                  newProjects.push({
                      id: crypto.randomUUID(),
                      projectName: repo.name,
                      owner: repo.owner.login,
                      description: repo.description || '',
                      originUrl: originUrl,
                      stars: repo.stargazers_count,
                      updatedAt: repo.updated_at,
                      language: repo.language || 'Unknown',
                      fileCount: stats.fileCount || 0,
                      codeFileCount: stats.codeFileCount || 0,
                      totalLinesOfCode: stats.totalLinesOfCode || 0,
                      entrypoints: stats.entrypoints,
                      lcpm: stats.lcpm || 0,
                      commitsBehind: stats.commitsBehind || 0,
                      mermaidGraph: undefined 
                  });
              } else {
                  // EXISTING PROJECT - Refresh Stats
                  setSyncStatus(`REFRESHING STATS: ${repo.name}...`);
                  
                  const stats = await analyzeRepoStats(repo.owner.login, repo.name, repo.default_branch, upstreamArg);

                  updatedList.push({
                      ...local,
                      stars: repo.stargazers_count,
                      updatedAt: repo.updated_at,
                      description: repo.description || local.description,
                      originUrl: originUrl, 
                      // Update computed stats if we got them (or keep old if fetch failed, but not for 0)
                      lcpm: stats.lcpm !== undefined ? stats.lcpm : local.lcpm,
                      commitsBehind: stats.commitsBehind !== undefined ? stats.commitsBehind : local.commitsBehind,
                      totalLinesOfCode: stats.totalLinesOfCode !== undefined ? stats.totalLinesOfCode : local.totalLinesOfCode,
                  });
              }
          }
          
          const finalList = [...updatedList, ...newProjects];
          
          // 3. Save to GitHub
          if (finalList.length > 0) {
              setSyncStatus('UPLOADING NEURAL SNAPSHOT...');
              await githubDataService.saveData(githubConfig, STORAGE_PATHS.GIT, finalList, "Auto-Sync Project List & Stats");
              
              // Update local view
              setProjects(finalList);
              addToast({ message: `Sync Complete. Projects updated.`, type: 'success' });
          } else {
              addToast({ message: `Systems Nominal. No changes detected.`, type: 'info' });
          }
          
      } catch (e) {
          console.error(e);
          addToast({ message: 'Sync Protocol Failed. Check credentials.', type: 'error' });
      } finally {
          setIsSyncing(false);
          setSyncStatus('');
      }
  }

  return (
    <div className="flex flex-col gap-6 h-full">
      {/* Toolbar */}
      <div className="flex items-center justify-between bg-black/40 border border-white/10 p-4 rounded-xl backdrop-blur-md shadow-[0_0_30px_rgba(0,0,0,0.5)]">
         <div className="flex items-center gap-4">
            <div className="bg-green-500/10 p-2.5 rounded-lg border border-green-500/20 shadow-[0_0_10px_rgba(34,197,94,0.2)]">
                <CodeBracketIcon className="w-6 h-6 text-green-400" />
            </div>
            <div>
                <h2 className="text-xl font-bold text-white tracking-tight neon-text">PROJECT DATABASE</h2>
                <p className="text-[10px] text-green-400/70 font-mono tracking-wider">{STORAGE_PATHS.GIT}</p>
            </div>
         </div>
         
         <div className="flex items-center gap-4">
             <div className="flex items-center bg-black border border-white/10 rounded-lg px-3 py-2">
                 <SortIcon className="w-4 h-4 text-gray-400 mr-2" />
                 <select 
                    value={sortBy} 
                    onChange={(e) => setSortBy(e.target.value as SortOption)}
                    className="bg-transparent border-none outline-none text-sm text-gray-300 font-mono cursor-pointer hover:text-white transition-colors"
                 >
                     <option value="updated">Updated</option>
                     <option value="loc">LOC</option>
                     <option value="files">Files</option>
                     <option value="name">Name</option>
                 </select>
             </div>

             {isSyncing && (
                 <div className="flex items-center gap-3 bg-green-900/20 px-4 py-2 rounded-lg border border-green-500/30">
                     <Spinner className="w-4 h-4 text-green-400" />
                     <span className="text-xs font-mono text-green-400 animate-pulse tracking-widest">{syncStatus}</span>
                 </div>
             )}

             <button 
                onClick={handleSyncProtocol}
                className={`
                    relative overflow-hidden px-6 py-2.5 rounded-lg font-bold text-sm uppercase tracking-widest transition-all
                    ${isSyncing 
                        ? 'bg-gray-800 text-gray-500 border border-gray-700 cursor-not-allowed' 
                        : 'bg-green-900/20 text-green-400 border border-green-500/50 hover:bg-green-500 hover:text-black hover:shadow-[0_0_20px_rgba(34,197,94,0.6)]'}
                `}
             >
                 <div className="flex items-center gap-2">
                     <SyncIcon className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                     {isGithubConfigured ? 'SYNC PROTOCOL' : 'CONNECT GITHUB'}
                 </div>
             </button>
         </div>
      </div>

      {/* Grid */}
      {isProjectsLoading ? (
          <div className="flex-1 flex flex-col items-center justify-center">
              <Spinner className="w-8 h-8 text-green-500" />
              <p className="mt-4 text-green-400 font-mono text-sm animate-pulse">ESTABLISHING DATA LINK...</p>
          </div>
      ) : projects.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center border border-dashed border-gray-800 rounded-xl bg-black/20 p-12 text-center">
              <CodeBracketIcon className="w-16 h-16 text-gray-700 mb-6" />
              <p className="text-gray-400 mb-2 font-bold text-lg">NO DATA DETECTED</p>
              
              {!isGithubConfigured ? (
                  <>
                    <p className="text-gray-500 max-w-md mb-6">
                        Connect your GitHub account to sync your projects. You need to provide a Token, Username, and a Storage Repository name.
                    </p>
                    <button 
                        onClick={() => setIsSettingsOpen(true)}
                        className="bg-green-600 hover:bg-green-500 text-white px-6 py-2 rounded-lg font-bold transition-all shadow-lg shadow-green-900/20 flex items-center gap-2"
                    >
                        <SettingsIcon className="w-5 h-5" />
                        CONFIGURE CONNECTION
                    </button>
                  </>
              ) : (
                  <>
                     <p className="text-gray-500 max-w-md mb-6">
                        Your configuration is active but no projects were found in your local cache or remote CSV.
                     </p>
                     <button onClick={handleSyncProtocol} className="text-green-400 hover:text-green-300 hover:underline font-mono text-sm">
                        INITIATE SYNC PROTOCOL
                     </button>
                  </>
              )}
          </div>
      ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-4 pb-6">
              {filteredProjects.map((proj, idx) => (
                  <ProjectCard 
                    key={idx}
                    project={proj}
                    onSelect={openDetails}
                    onQuickScan={onQuickScan}
                    onShowDiff={() => handleOpenDiff(proj)}
                  />
              ))}
          </div>
      )}
      
      <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
      
      <DiffModal 
        isOpen={diffModalOpen}
        onClose={() => setDiffModalOpen(false)}
        diffData={activeDiff}
        upstreamName={activeUpstreamName}
      />
    </div>
  );
};

export default GitHubView;
