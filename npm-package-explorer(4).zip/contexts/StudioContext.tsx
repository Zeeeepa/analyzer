


import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode, useCallback } from 'react';
import { GithubConfig, StudioResource, GitProject, ChatContext, ViewedResource, FileTreeNode, AnalysisResult, D3Node, D3Link, EnrichedPackageInfo, UserVariable, LibraryContext } from '../types';
import { SwarmOrchestrator } from '../services/swarmService';
import { openDB, getAllPackages, updatePackage } from '../services/dbService';
import { githubDataService } from '../services/githubDataService';
import { DEFAULT_GITHUB_CONFIG, STORAGE_PATHS } from '../constants/config';
import { getRepoTree, getFileContent, fetchFilesParallel } from '../services/githubService';
import { fetchFileTree, fetchFileContent, enrichPackageInfo } from '../services/npmService';
import { buildTreeFromPathList } from '../utils/tree';
import { extractSymbols, generateMermaidGraph } from '../services/analysisService';
import { generateInfographic } from '../services/geminiService';
import { variableService } from '../services/variableService';

export type TabType = 'swarm' | 'github' | 'npm' | 'knowledge' | 'variables';

interface StudioContextType {
    db: IDBDatabase | null;
    githubConfig: GithubConfig;
    updateGithubConfig: (config: GithubConfig) => void;
    isGithubConfigured: boolean;
    activeTab: TabType;
    setActiveTab: (tab: TabType) => void;
    orchestrator: SwarmOrchestrator;
    executeSwarmQuery: (query: string) => void;
    chatContext: ChatContext | null;
    setChatContext: (context: ChatContext | null) => void;
    
    // Global Explorer State
    viewedResource: ViewedResource | null;
    setViewedResource: (resource: ViewedResource | null) => void;
    explorerTree: FileTreeNode[];
    isExplorerScanning: boolean;
    explorerAnalysis: AnalysisResult | null;
    selectedFile: { path: string, name: string } | null;
    fileContent: string;
    
    // Advanced Library Context
    libraryContext: LibraryContext | null;
    isHydrating: boolean; // True when pre-fetching files

    // Variables
    variables: UserVariable[];
    refreshVariables: () => Promise<void>;

    // Actions
    triggerDeepScan: () => Promise<void>;
    selectFile: (path: string) => Promise<void>;
    openResource: (name: string, type: 'github' | 'npm') => Promise<void>;
    closeResource: () => void;
    searchSymbols: (query: string) => string[];
    queryGraph: (query: string) => string[];
}

const StudioContext = createContext<StudioContextType | undefined>(undefined);

export const StudioProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [db, setDb] = useState<IDBDatabase | null>(null);
    const [activeTab, setActiveTab] = useState<TabType>('npm'); 
    const [chatContext, setChatContext] = useState<ChatContext | null>(null);
    
    // Explorer State
    const [viewedResource, setViewedResource] = useState<ViewedResource | null>(null);
    const [explorerTree, setExplorerTree] = useState<FileTreeNode[]>([]);
    const [isExplorerScanning, setIsExplorerScanning] = useState(false);
    const [explorerAnalysis, setExplorerAnalysis] = useState<AnalysisResult | null>(null);
    const [selectedFile, setSelectedFile] = useState<{ path: string, name: string } | null>(null);
    const [fileContent, setFileContent] = useState<string>('');
    
    // Advanced Library Loading
    const [libraryContext, setLibraryContext] = useState<LibraryContext | null>(null);
    const [isHydrating, setIsHydrating] = useState(false);

    // Variables State
    const [variables, setVariables] = useState<UserVariable[]>([]);

    // Load config from localStorage
    const [githubConfig, setGithubConfig] = useState<GithubConfig>(() => {
        const saved = localStorage.getItem('studio_github_config');
        return saved ? JSON.parse(saved) : DEFAULT_GITHUB_CONFIG;
    });

    const isGithubConfigured = !!githubConfig.token && !!githubConfig.owner && !!githubConfig.repo;

    const updateGithubConfig = (config: GithubConfig) => {
        setGithubConfig(config);
        localStorage.setItem('studio_github_config', JSON.stringify(config));
    };
    
    const orchestrator = useMemo(() => new SwarmOrchestrator(process.env.API_KEY || ''), []);

    // Load Resources for Swarm Context
    useEffect(() => {
        const init = async () => {
            try {
                const database = await openDB();
                setDb(database);
                
                const npmPackages = await getAllPackages(database);
                let gitProjects: GitProject[] = [];

                if (isGithubConfigured) {
                    try {
                        gitProjects = await githubDataService.loadData<GitProject>(githubConfig, STORAGE_PATHS.GIT);
                        // Load variables initially too
                        refreshVariables();
                    } catch (e) {
                        console.warn("Swarm context: Failed to load git projects", e);
                    }
                }
                
                const resources: StudioResource[] = [
                    ...npmPackages.map(p => ({ 
                        id: p.name, type: 'npm_package' as const, name: p.name, tags: p.keywords || [], metadata: p 
                    })),
                    ...gitProjects.map(p => ({
                        id: p.projectName, type: 'github_repo' as const, name: p.projectName, owner: p.owner, tags: [p.language || 'unknown'], metadata: p
                    }))
                ];
                orchestrator.setResources(resources);
            } catch (error) {
                console.error("Studio Context Initialization Failed:", error);
            }
        };
        init();
    }, [orchestrator, isGithubConfigured, githubConfig]);

    const refreshVariables = useCallback(async () => {
        if (!isGithubConfigured) return;
        try {
            const vars = await variableService.loadVariables(githubConfig, STORAGE_PATHS.VARIABLES);
            setVariables(vars);
        } catch (e) {
            console.error("Failed to refresh variables", e);
        }
    }, [isGithubConfigured, githubConfig]);

    // Hydrate Context (Prefetch Critical Files)
    const hydrateLibrary = async (resource: ViewedResource, tree: { path: string; sha?: string }[]) => {
        setIsHydrating(true);
        const importantFiles: string[] = [];
        
        // 1. Identify Critical Files
        tree.forEach(f => {
            const name = f.path.split('/').pop()?.toLowerCase();
            const isRoot = !f.path.includes('/');
            if (
                name === 'package.json' || 
                name === 'tsconfig.json' || 
                name === 'readme.md' ||
                name === 'cargo.toml' ||
                (isRoot && /\.(js|ts|go|py|rs)$/.test(name || '')) ||
                (name && ['app.tsx', 'index.tsx', 'main.ts', 'server.js'].includes(name))
            ) {
                importantFiles.push(f.path);
            }
        });

        // Limit to top 20 critical files to be safe
        const fetchList = tree.filter(f => importantFiles.includes(f.path)).slice(0, 20);
        
        try {
            let fetchedContent: Record<string, string> = {};

            if (resource.type === 'github') {
                const config = { token: githubConfig.token, owner: (resource.data as any).owner, repo: (resource.data as any).projectName };
                fetchedContent = await fetchFilesParallel(config, fetchList);
            } else {
                // For NPM, just simple sequential for now (CDN is fast)
                for (const f of fetchList) {
                    try {
                        const c = await fetchFileContent(resource.name, resource.version || 'latest', f.path);
                        fetchedContent[f.path] = c;
                    } catch {}
                }
            }

            setLibraryContext({
                isHydrated: true,
                files: fetchedContent,
                structure: tree.map(f => f.path).slice(0, 500), // simplified structure for AI
                importantPaths: Object.keys(fetchedContent)
            });

        } catch (e) {
            console.warn("Hydration failed", e);
        } finally {
            setIsHydrating(false);
        }
    };

    // React to ViewedResource Change: Load Tree & Context
    useEffect(() => {
        if (!viewedResource) {
            setExplorerTree([]);
            setExplorerAnalysis(null);
            setChatContext(null);
            setSelectedFile(null);
            setFileContent('');
            setLibraryContext(null);
            return;
        }

        const loadResourceTree = async () => {
            try {
                if (viewedResource.type === 'github') {
                    const project = viewedResource.data as GitProject;
                    setChatContext({
                        type: 'github', name: project.projectName, owner: project.owner, description: project.description,
                        analysisData: project.analysisData, language: project.language
                    });
                    if (project.analysisData) setExplorerAnalysis(JSON.parse(project.analysisData));
                    else if (project.mermaidGraph) {
                         setExplorerAnalysis({
                             exports: { moduleFormat: 'unknown', entryPoints: {} },
                             structure: { languages: [project.language || 'Unknown'], frameworks: [], hasTests: false, hasTypes: false },
                             dependencyGraph: {} as any, mermaidGraph: project.mermaidGraph, d3Graph: project.d3Graph ? JSON.parse(project.d3Graph) : undefined, infographic: project.infographic
                         });
                    }
                    const config = { token: githubConfig.token, owner: project.owner, repo: project.projectName };
                    const treeData = await getRepoTree(config);
                    if (treeData) {
                        setExplorerTree(buildTreeFromPathList(treeData));
                        hydrateLibrary(viewedResource, treeData);
                    }

                } else if (viewedResource.type === 'npm') {
                    const pkg = viewedResource.data as EnrichedPackageInfo;
                    setChatContext({
                        type: 'npm', name: pkg.name, version: pkg.version, description: pkg.description,
                        analysisData: pkg.analysisData, language: 'TypeScript'
                    });
                    if (pkg.analysisData) setExplorerAnalysis(JSON.parse(pkg.analysisData));
                    const tree = await fetchFileTree(pkg.name, pkg.version || 'latest');
                    setExplorerTree(tree);
                    
                    const flatTree = (nodes: FileTreeNode[]): {path: string}[] => {
                        let res: {path: string}[] = [];
                        nodes.forEach(n => { res.push({path: n.path}); if(n.children) res = res.concat(flatTree(n.children)); });
                        return res;
                    }
                    hydrateLibrary(viewedResource, flatTree(tree));
                }
            } catch (e) {
                console.error("Failed to load resource tree:", e);
            }
        };
        loadResourceTree();
    }, [viewedResource, githubConfig]);

    // --- Actions ---

    const executeSwarmQuery = (query: string) => {
         if (!query.trim()) return;
         setActiveTab('swarm');
         orchestrator.processQuery(query);
    };

    const triggerDeepScan = useCallback(async () => {
        if (!viewedResource) throw new Error("No resource");
        setIsExplorerScanning(true);
        try {
            if (viewedResource.type === 'github') {
                const project = viewedResource.data as GitProject;
                const config = { token: githubConfig.token, owner: project.owner, repo: project.projectName };
                const tree = await getRepoTree(config);
                if (!tree) throw new Error("Tree fetch failed");

                const codeFiles = tree.filter(f => /\.(js|ts|jsx|tsx|py|go|java|c|cpp|rs)$/.test(f.path));
                const filesToScan = codeFiles.slice(0, 20); 
                
                // Use parallel fetch for Deep Scan too!
                const fileMap = await fetchFilesParallel(config, filesToScan);
                const symbols = [];
                
                for (const [path, content] of Object.entries(fileMap)) {
                    symbols.push(...extractSymbols(content, path.endsWith('.d.ts')));
                }

                const mermaidGraph = generateMermaidGraph(symbols);
                
                // D3 Gen
                const d3Nodes: D3Node[] = [];
                const d3Links: D3Link[] = [];
                const nodeSet = new Set<string>();
                filesToScan.forEach(f => {
                    if(!nodeSet.has(f.path)) { d3Nodes.push({ id: f.path, label: f.path.split('/').pop() || f.path, group: 1 }); nodeSet.add(f.path); }
                });
                symbols.forEach(s => {
                    const id = `sym-${s.name}`;
                    if (!nodeSet.has(id)) { d3Nodes.push({ id, label: s.name, group: 2 }); nodeSet.add(id); }
                    s.usage?.forEach(u => { if (nodeSet.has(`sym-${u}`)) d3Links.push({ source: id, target: `sym-${u}`, value: 1 }); });
                });

                let infographic = project.infographic;
                if (!infographic) {
                    try { infographic = await generateInfographic(project.projectName, tree.slice(0, 50).map(t => ({ path: t.path, type: t.type, sha: t.sha })), "Modern Data Flow", false, "English") || undefined; } catch {}
                }

                const result: AnalysisResult = {
                    exports: { moduleFormat: 'unknown', entryPoints: {} }, 
                    structure: { languages: [project.language || 'Unknown'], frameworks: [], hasTests: false, hasTypes: false },
                    dependencyGraph: {} as any, mermaidGraph, d3Graph: { nodes: d3Nodes, links: d3Links }, infographic
                };
                setExplorerAnalysis(result);
            } else {
                const pkg = viewedResource.data as EnrichedPackageInfo;
                const tree = await fetchFileTree(pkg.name, pkg.version || 'latest');
                const flatten = (nodes: FileTreeNode[]): FileTreeNode[] => { let res: FileTreeNode[] = []; nodes.forEach(n => { res.push(n); if(n.children) res = res.concat(flatten(n.children)); }); return res; };
                const flatFiles = flatten(tree);
                const limitedFiles = flatFiles.slice(0, 200);

                const d3Nodes: D3Node[] = [];
                const d3Links: D3Link[] = [];
                const nodeIds = new Set<string>();
                const addNode = (id: string, label: string, group: number) => { if (!nodeIds.has(id)) { d3Nodes.push({ id, label, group }); nodeIds.add(id); } };
                
                addNode('/', pkg.name, 1);
                limitedFiles.forEach(f => {
                    const fullPath = f.path.startsWith('/') ? f.path : `/${f.path}`;
                    addNode(fullPath, f.name, f.type === 'directory' ? 1 : 2);
                    const parts = fullPath.split('/').filter(p => p); parts.pop();
                    let parentPath = parts.length > 0 ? '/' + parts.join('/') : '/';
                    let currentWalkPath = '';
                    parts.forEach(part => {
                         const parentWalk = currentWalkPath === '' ? '/' : currentWalkPath;
                         currentWalkPath = currentWalkPath + '/' + part;
                         addNode(currentWalkPath, part, 1);
                         if (parentWalk !== currentWalkPath) d3Links.push({ source: parentWalk, target: currentWalkPath, value: 1 });
                    });
                    d3Links.push({ source: parentPath, target: fullPath, value: 1 });
                });
                const uniqueLinks = d3Links.filter((link, index, self) => index === self.findIndex((t) => (t.source === link.source && t.target === link.target)));

                let infographic = pkg.infographic;
                if (!infographic) {
                     try { infographic = await generateInfographic(pkg.name, limitedFiles.map(t => ({ path: t.path, type: t.type, sha: 'n/a' })), "Modern Data Flow", false, "English") || undefined; } catch {}
                }
                const result: AnalysisResult = {
                    exports: { moduleFormat: 'unknown', entryPoints: {} }, 
                    structure: { languages: [], frameworks: [], hasTests: false, hasTypes: false },
                    dependencyGraph: {} as any, mermaidGraph: undefined, d3Graph: { nodes: d3Nodes, links: uniqueLinks }, infographic
                };
                if (db) {
                     await updatePackage(db, { ...pkg, infographic, d3Graph: JSON.stringify(result.d3Graph), analysisData: JSON.stringify(result) });
                }
                setExplorerAnalysis(result);
            }
        } catch(e) { console.error(e) } finally { setIsExplorerScanning(false); }
    }, [viewedResource, githubConfig, db]);

    const selectFile = useCallback(async (path: string) => {
        if (!viewedResource) return;
        const name = path.split('/').pop() || path;
        setSelectedFile({ path, name });
        setFileContent('');
        
        // 1. Check Library Context (Hot Cache)
        if (libraryContext && libraryContext.files[path]) {
            setFileContent(libraryContext.files[path]);
            return;
        }

        try {
            let content = '';
            if (viewedResource.type === 'github') {
                const project = viewedResource.data as GitProject;
                const config = { token: githubConfig.token, owner: project.owner, repo: project.projectName };
                content = await getFileContent(config, path) || "";
            } else {
                const pkg = viewedResource.data as EnrichedPackageInfo;
                content = await fetchFileContent(pkg.name, pkg.version || 'latest', path);
            }
            if(!content) throw new Error("Content empty or not found");
            setFileContent(content);
        } catch (e: any) {
            console.error("Failed to select file", e);
            setFileContent(`// ERROR: Failed to load file content: ${path}\n// Reason: ${e.message}\n// Please check network connection or file existence.`);
        }
    }, [viewedResource, githubConfig, libraryContext]);

    const openResource = useCallback(async (name: string, type: 'github' | 'npm') => {
        if (type === 'npm') {
            const info = await enrichPackageInfo(name);
            if (info) {
                 setViewedResource({ type: 'npm', name: info.name!, version: info.version, description: info.description, data: info as EnrichedPackageInfo });
            }
        } else {
             const [owner, repo] = name.split('/');
             if (owner && repo) {
                 setViewedResource({
                     type: 'github', name, description: 'Agent Opened', 
                     data: { projectName: repo, owner, description: 'Agent Opened', originUrl: `https://github.com/${name}`, language: 'Unknown' } as GitProject 
                 });
             }
        }
    }, []);
    
    const closeResource = useCallback(() => {
        setViewedResource(null);
    }, []);

    const searchSymbols = useCallback((query: string) => {
        if (!explorerAnalysis?.d3Graph?.nodes) return [];
        const lowerQ = query.toLowerCase();
        
        const matches = explorerAnalysis.d3Graph.nodes
            .filter(node => node.label.toLowerCase().includes(lowerQ) && node.group === 2)
            .map(node => `Symbol: ${node.label} (ID: ${node.id})`);
            
        return matches;
    }, [explorerAnalysis]);

    const queryGraph = useCallback((query: string) => {
        if (!explorerAnalysis?.d3Graph) return ["Graph data not available."];
        
        const { nodes, links } = explorerAnalysis.d3Graph;
        const q = query.toLowerCase();
        const results: string[] = [];

        // Basic relationship finder: find nodes matching query, then find connected nodes
        const relevantNodes = nodes.filter(n => n.label.toLowerCase().includes(q));
        
        relevantNodes.forEach(node => {
            const nodeId = node.id;
            
            // Find inputs (who calls me)
            const callers = links
                .filter(l => (typeof l.target === 'object' ? (l.target as any).id === nodeId : l.target === nodeId))
                .map(l => (typeof l.source === 'object' ? (l.source as any).label : l.source));
            
            // Find outputs (who I call)
            const calls = links
                .filter(l => (typeof l.source === 'object' ? (l.source as any).id === nodeId : l.source === nodeId))
                .map(l => (typeof l.target === 'object' ? (l.target as any).label : l.target));

            results.push(`Node: ${node.label}`);
            if(callers.length > 0) results.push(`  <- Called by: ${callers.join(', ')}`);
            if(calls.length > 0) results.push(`  -> Calls/Uses: ${calls.join(', ')}`);
        });

        return results.length > 0 ? results : ["No relationships found for query."];
    }, [explorerAnalysis]);

    return (
        <StudioContext.Provider value={{
            db, githubConfig, updateGithubConfig, isGithubConfigured,
            activeTab, setActiveTab, orchestrator, executeSwarmQuery,
            chatContext, setChatContext, viewedResource, setViewedResource,
            explorerTree, isExplorerScanning, explorerAnalysis,
            selectedFile, fileContent, variables, refreshVariables,
            triggerDeepScan, selectFile, openResource, closeResource,
            libraryContext, isHydrating, searchSymbols, queryGraph
        }}>
            {children}
        </StudioContext.Provider>
    );
};

export const useStudio = () => {
    const context = useContext(StudioContext);
    if (!context) throw new Error("useStudio must be used within StudioProvider");
    return context;
};
