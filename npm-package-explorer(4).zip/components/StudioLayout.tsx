
import React, { useState } from 'react';
import { useStudio, TabType } from '../contexts/StudioContext';
import { Layers, Sparkles, GitHubIcon, CubeIcon, DatabaseIcon, SettingsIcon, CodeBracketIcon } from './icons';
import SwarmVisualizer from './SwarmVisualizer';
import GitHubView from '../views/GitHubView';
import NPMView from '../views/NPMView';
import KnowView from '../views/KnowView';
import VariablesView from '../views/VariablesView';
import ChatWidget from './ChatWidget';
import SettingsModal from './SettingsModal';
import ProjectExplorer from './ProjectExplorer';
import { GitProject, EnrichedPackageInfo } from '../types';
import { enrichPackageInfo } from '../services/npmService';

const StudioLayout: React.FC = () => {
    const { 
        activeTab, setActiveTab, executeSwarmQuery, orchestrator, 
        viewedResource, setViewedResource, explorerTree, openResource
    } = useStudio();
    
    const [query, setQuery] = useState('');
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);

    const handleQuickScan = (resource: any, type: 'github' | 'npm') => {
        // Just open it, the state management handles the view.
        // The explorer itself has a Deep Analyze button the user (or agent) can click.
        // Or we could trigger it automatically, but explicit is better for now.
        if (type === 'github') {
             setViewedResource({
                type, name: resource.projectName, description: resource.description, data: resource
             });
        } else {
             setViewedResource({
                type, name: resource.name, version: resource.version, description: resource.description, data: resource
             });
        }
    };

    // --- Command Handling ---

    const handleExecute = async () => {
        const input = query.trim();
        if (!input) return;

        // 1. Check GitHub URL or "owner/repo"
        let ghOwner = '', ghRepo = '';
        const ghUrlMatch = input.match(/github\.com\/([^\/]+)\/([^\/]+)/);
        const ghShortMatch = input.match(/^([a-zA-Z0-9-]+\/[a-zA-Z0-9-_.]+)$/);

        if (ghUrlMatch) { [, ghOwner, ghRepo] = ghUrlMatch; }
        else if (ghShortMatch) { [ghOwner, ghRepo] = ghShortMatch[1].split('/'); }

        if (ghOwner && ghRepo) {
            await openResource(`${ghOwner}/${ghRepo}`, 'github');
            setQuery('');
            return;
        }

        // 2. Check NPM "npm:name" or "name" (simple)
        let npmName = '';
        if (input.startsWith('npm:')) npmName = input.replace('npm:', '');
        else if (/^[a-zA-Z0-9-@/._]+$/.test(input)) npmName = input;

        if (npmName) {
            try {
                const info = await enrichPackageInfo(npmName);
                if (info) {
                     await openResource(info.name!, 'npm');
                     setQuery('');
                     return;
                }
            } catch (e) {
                // If failed, fallthrough to swarm
            }
        }

        // 3. Fallback to Swarm
        executeSwarmQuery(input);
        setQuery('');
    };

    const tabs: { id: TabType; icon: React.ElementType; label: string }[] = [
        { id: 'swarm', icon: Sparkles, label: 'Swarm' },
        { id: 'github', icon: GitHubIcon, label: 'Repos' },
        { id: 'npm', icon: CubeIcon, label: 'Packages' },
        { id: 'knowledge', icon: DatabaseIcon, label: 'Knowledge' },
        { id: 'variables', icon: CodeBracketIcon, label: 'Variables' },
    ];

    return (
        <div className="h-screen w-screen flex flex-col bg-[#050505] text-gray-200 font-sans overflow-hidden">
            {/* Top Command Bar */}
            <header className="h-16 border-b border-white/10 bg-[#0a0a0a] flex items-center px-6 gap-6 shrink-0 z-20">
                <div className="flex items-center gap-2 text-xl font-bold tracking-tighter">
                    <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded flex items-center justify-center shadow-lg shadow-purple-500/20">
                        <Layers className="w-5 h-5 text-white" />
                    </div>
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">LINK2INK</span>
                </div>

                <div className="flex-1 max-w-2xl relative">
                    <input 
                        type="text" 
                        value={query}
                        onChange={e => setQuery(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && handleExecute()}
                        placeholder="Command swarm or paste URL (e.g. facebook/react, npm:lodash)..."
                        className="w-full bg-[#151515] border border-white/10 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-all font-mono"
                    />
                    <button 
                        onClick={handleExecute}
                        className="absolute right-1.5 top-1.5 p-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded transition-colors"
                    >
                        <Sparkles className="w-3.5 h-3.5" />
                    </button>
                </div>

                <div className="flex gap-4 items-center">
                    <div className="flex gap-1 bg-[#151515] p-1 rounded-lg border border-white/5">
                        {tabs.map(tab => (
                            <button
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-bold uppercase tracking-wider transition-all ${
                                    activeTab === tab.id 
                                    ? 'bg-white/10 text-white shadow-sm' 
                                    : 'text-gray-500 hover:text-gray-300 hover:bg-white/5'
                                }`}
                            >
                                <tab.icon className="w-3.5 h-3.5" />
                                {tab.label}
                            </button>
                        ))}
                    </div>

                    <button 
                        onClick={() => setIsSettingsOpen(true)}
                        className="p-2 text-gray-500 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                        title="Settings"
                    >
                        <SettingsIcon className="w-5 h-5" />
                    </button>
                </div>
            </header>

            {/* Main Workspace */}
            <main className="flex-1 overflow-hidden relative">
                
                <div className={`absolute inset-0 transition-opacity duration-300 ${activeTab === 'swarm' ? 'opacity-100 z-10' : 'opacity-0 pointer-events-none'}`}>
                    <SwarmVisualizer orchestrator={orchestrator} />
                </div>

                <div className={`absolute inset-0 bg-[#020617] transition-opacity duration-300 p-6 overflow-y-auto ${activeTab === 'github' ? 'opacity-100 z-10' : 'opacity-0 pointer-events-none'}`}>
                     <GitHubView onQuickScan={(p) => handleQuickScan(p, 'github')} />
                </div>

                <div className={`absolute inset-0 bg-[#020617] transition-opacity duration-300 p-6 overflow-y-auto ${activeTab === 'npm' ? 'opacity-100 z-10' : 'opacity-0 pointer-events-none'}`}>
                     <NPMView onQuickScan={(p) => handleQuickScan(p, 'npm')} />
                </div>

                 <div className={`absolute inset-0 bg-[#020617] transition-opacity duration-300 p-6 overflow-y-auto ${activeTab === 'knowledge' ? 'opacity-100 z-10' : 'opacity-0 pointer-events-none'}`}>
                     <KnowView />
                </div>

                <div className={`absolute inset-0 bg-[#020617] transition-opacity duration-300 p-6 overflow-y-auto ${activeTab === 'variables' ? 'opacity-100 z-10' : 'opacity-0 pointer-events-none'}`}>
                     <VariablesView />
                </div>

            </main>

            {/* Global Resource Explorer Modal */}
            {viewedResource && (
                 <ProjectExplorer
                    title={viewedResource.name}
                    version={viewedResource.version || 'HEAD'}
                    description={viewedResource.description || ''}
                    fileTree={explorerTree}
                    onClose={() => setViewedResource(null)}
                    stats={
                        viewedResource.type === 'npm' 
                        ? { 
                            unpackedSize: (viewedResource.data as EnrichedPackageInfo).unpackedSize,
                            fileCount: (viewedResource.data as EnrichedPackageInfo).fileCount,
                            publishDate: (viewedResource.data as EnrichedPackageInfo).lastPublished
                          }
                        : {
                             fileCount: (viewedResource.data as GitProject).fileCount,
                             publishDate: (viewedResource.data as GitProject).updatedAt
                          }
                    }
                 />
            )}

            {/* Global Chat Widget */}
            <ChatWidget />
            
            {/* Settings Modal */}
            <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
        </div>
    );
};

export default StudioLayout;
