
import React from 'react';
import { EnrichedPackageInfo } from '../types';
import { HeartIcon, Sparkles } from './icons';

interface PackageCardProps {
  pkg: EnrichedPackageInfo;
  onSelect: (pkg: EnrichedPackageInfo) => void;
  onToggleFavorite: (packageName: string) => void;
  onQuickScan?: (pkg: EnrichedPackageInfo) => void;
  onMaintainerClick?: (username: string) => void;
}

const colorScales = {
    orange: ['#fed7aa', '#f97316'], // orange-200 to orange-500
    blue: ['#bfdbfe', '#2563eb'],   // blue-200 to blue-600
    yellow: ['#fef08a', '#eab308'], // yellow-200 to yellow-500
    purple: ['#e9d5ff', '#a855f7'], // purple-200 to purple-500
};

function hexToRgb(hex: string): [number, number, number] {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? [parseInt(result[1], 16), parseInt(result[2], 16), parseInt(result[3], 16)] : [0, 0, 0];
}

function lerp(a: number, b: number, t: number): number {
    return a * (1 - t) + b * t;
}

function valueToColorStyle(value: number | string | undefined, max: number, scale: keyof typeof colorScales): React.CSSProperties {
    if (value === undefined) return {};
    let numericValue: number;
    let ratio: number;

    if (typeof value === 'string') {
        const dateValue = new Date(value).getTime();
        if (isNaN(dateValue)) return {};
        const oneYearAgo = Date.now() - (365 * 24 * 60 * 60 * 1000);
        ratio = (dateValue - oneYearAgo) / (Date.now() - oneYearAgo);
        numericValue = Math.max(0, ratio);
    } else {
        numericValue = value;
        ratio = Math.log1p(numericValue) / Math.log1p(max || 1);
    }
    
    const t = Math.min(Math.max(ratio, 0), 1);
    const [startHex, endHex] = colorScales[scale];
    const [r1, g1, b1] = hexToRgb(startHex);
    const [r2, g2, b2] = hexToRgb(endHex);
    
    const r = Math.round(lerp(r1, r2, t));
    const g = Math.round(lerp(g1, g2, t));
    const b = Math.round(lerp(b1, b2, t));

    return { color: `rgb(${r}, ${g}, ${b})` };
}

const Stat = ({ label, value, style }: { label: string, value: string | number, style?: React.CSSProperties }) => (
    <div className="text-center overflow-hidden flex flex-col items-center">
        <p className="text-[9px] uppercase tracking-wider text-gray-500 truncate mb-0.5">{label}</p>
        <p className="text-xs font-mono font-bold text-gray-200 truncate" style={style}>{value}</p>
    </div>
);

const PackageCard: React.FC<PackageCardProps> = ({ pkg, onSelect, onToggleFavorite, onQuickScan, onMaintainerClick }) => {
  const formatSize = (bytes: number = 0) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const formatNumber = (num: number = 0) => {
      if (num > 1000000) return (num / 1000000).toFixed(1) + 'M';
      if (num > 1000) return (num / 1000).toFixed(1) + 'k';
      return num.toString();
  };

  const isEnriched = pkg.status === 'enriched';

  const handleCardClick = () => {
    if (isEnriched) {
      onSelect(pkg);
    }
  };

  // Ensure maintainers is treated as an array even if data is inconsistent
  const maintainers = Array.isArray(pkg.maintainers) ? pkg.maintainers : (pkg.maintainers ? [pkg.maintainers] : []);

  // Deduplicate maintainers by name
  const uniqueMaintainers = Array.from(new Set(maintainers.map(m => m.name)))
    .map(name => maintainers.find(m => m.name === name));

  return (
    <div
      onClick={handleCardClick}
      className={`bg-gray-800 border border-gray-700 rounded-lg p-3 flex flex-col justify-between
        ${isEnriched ? 'hover:bg-gray-700 hover:border-red-500 cursor-pointer' : 'opacity-70'}
        transition-all duration-200 shadow-lg h-full relative group min-h-[200px]`}
    >
      <div className="flex-1 flex flex-col">
        {/* Row 1: Title and Actions */}
        <div className="flex justify-between items-start mb-1">
            <div className="flex-1 overflow-hidden">
                <h3 className="text-sm font-bold text-red-400 truncate pr-2" title={pkg.name}>{pkg.name}</h3>
            </div>
            <div className="flex items-center gap-1 shrink-0">
                 {isEnriched && onQuickScan && (
                     <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); onQuickScan(pkg); }}
                        className="text-gray-500 hover:text-yellow-400 p-0.5 rounded transition-colors"
                        title="Quick Deep Scan"
                     >
                         <Sparkles className="w-3.5 h-3.5" />
                     </button>
                 )}
                 <button 
                      type="button"
                      onClick={(e) => { e.stopPropagation(); onToggleFavorite(pkg.name); }}
                      className="text-gray-500 hover:text-red-400 transition-colors p-0.5"
                      aria-label={pkg.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
                  >
                      <HeartIcon className="w-4 h-4" solid={!!pkg.isFavorite} />
                  </button>
            </div>
        </div>
        
        {/* Row 2: Version */}
        <p className="text-[10px] text-gray-500 font-mono mb-2">v{pkg.version || 'N/A'}</p>
        
        {/* Row 3: Maintainers List (Dedicated Row) */}
        {uniqueMaintainers.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mb-3">
                {uniqueMaintainers.slice(0, 3).map((m: any, i: number) => (
                    <button
                        key={i}
                        type="button"
                        onClick={(e) => {
                            e.stopPropagation();
                            if (onMaintainerClick) onMaintainerClick(m.name);
                        }}
                        className="text-[10px] bg-gray-900/80 px-2 py-0.5 rounded-full border border-gray-600 text-gray-400 hover:text-purple-300 hover:border-purple-500/50 cursor-pointer transition-all flex items-center gap-1.5 shadow-sm"
                        title={`View packages by ${m.name}`}
                    >
                        <span className="w-1 h-1 rounded-full bg-green-500"></span>
                        {m.name}
                    </button>
                ))}
                {uniqueMaintainers.length > 3 && (
                    <span className="text-[9px] text-gray-500 self-center font-mono">+{uniqueMaintainers.length - 3}</span>
                )}
            </div>
        )}
        
        {/* Row 4: Description */}
        <p className="text-xs text-gray-300 mb-3 h-10 overflow-hidden text-ellipsis line-clamp-2 leading-relaxed">
            {pkg.description || <span className="text-gray-600 italic">No description available.</span>}
        </p>
      </div>
      
      {/* Stats Grid - Fixed at bottom */}
      <div className="grid grid-cols-3 gap-1 pt-2 border-t border-gray-700/50 bg-gray-900/30 -mx-3 px-3 pb-2 mt-auto">
          <Stat label="Size" value={isEnriched ? formatSize(pkg.unpackedSize) : '-'} style={valueToColorStyle(pkg.unpackedSize, 50 * 1024 * 1024, 'orange')} />
          <Stat label="Files" value={isEnriched ? pkg.fileCount ?? '-' : '-'} style={valueToColorStyle(pkg.fileCount, 500, 'yellow')} />
          <Stat label="LOC" value={isEnriched ? formatNumber(pkg.totalLinesOfCode) : '-'} style={valueToColorStyle(pkg.totalLinesOfCode, 50000, 'blue')} />
      </div>
    </div>
  );
};

export default PackageCard;
