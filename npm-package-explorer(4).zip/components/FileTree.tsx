// DEPRECATED: Replaced by internal tree component in ProjectExplorer.tsx
export default function FileTree() { return null; }