// DEPRECATED: Replaced by ProjectExplorer.tsx
export default function RepoDetailView() { return null; }