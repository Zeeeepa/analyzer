
import React, { useState, useRef, useEffect } from 'react';
import { FileTreeNode, SymbolData, AnalysisResult, D3Node, D3Link, EnrichedPackageInfo, GitProject } from '../types';
import { extractSymbols, analyzeWithTsMorph } from '../services/analysisService';
import Spinner from './Spinner';
import { CloseIcon, CodeBracketIcon, SymbolClassIcon, SymbolMethodIcon, SymbolVariableIcon, SymbolInterfaceIcon, Layers, Box, Sparkles, ChartBarIcon, GitHubIcon, NpmIcon } from './icons';
import D3FlowChart from './D3FlowChart';
import ImageViewer from './ImageViewer';
import MermaidViewer from './MermaidViewer';
import FileContent from './FileContent';
import { useStudio } from '../contexts/StudioContext';
import { generateSetupScript } from '../services/geminiService';
import { getFileContent, parseGitHubUrl, formatRelativeTime, getRepoDetails } from '../services/githubService';
import UserProfileModal from './modals/UserProfileModal';

interface ProjectExplorerProps {
    title: string;
    version: string;
    description: string;
    fileTree: FileTreeNode[];
    onClose: () => void;
    stats?: {
        unpackedSize?: number;
        fileCount?: number;
        publishDate?: string;
    }
}

// --- Enhanced Icon Logic ---
const getFileEmoji = (name: string, isDirectory: boolean, isExpanded: boolean) => {
    const lowerName = name.toLowerCase();
    
    if (isDirectory) {
        if (['src', 'lib', 'app', 'source', 'pkg'].includes(lowerName)) return isExpanded ? '📂' : '📁';
        if (['components', 'pages', 'views', 'containers'].includes(lowerName)) return '🧩';
        if (['test', 'tests', '__tests__', 'spec', 'specs', 'e2e'].includes(lowerName)) return '🧪';
        if (['assets', 'public', 'images', 'icons', 'media', 'static', 'res', 'fonts'].includes(lowerName)) return '🖼️';
        if (['api', 'server', 'backend', 'routes', 'controllers', 'middlewares', 'services'].includes(lowerName)) return '🖥️';
        if (['hooks', 'utils', 'helpers', 'common', 'shared', 'core', 'lib'].includes(lowerName)) return '🛠️';
        if (['dist', 'build', 'out', 'target', 'release', '.next', '.nuxt', 'coverage'].includes(lowerName)) return '📦';
        if (['docs', 'documentation', 'examples', 'guides'].includes(lowerName)) return '📝';
        if (['node_modules', 'vendor', 'bower_components', 'packages'].includes(lowerName)) return '🧱';
        if (['.github', '.vscode', '.idea', 'config', '.husky', '.circleci', '.git', 'workflows'].includes(lowerName)) return '⚙️';
        if (['styles', 'css', 'scss', 'theme', 'ui'].includes(lowerName)) return '🎨';
        if (['db', 'database', 'migrations', 'models', 'prisma', 'sql'].includes(lowerName)) return '🗄️';
        if (['typings', 'types', 'interfaces', '@types'].includes(lowerName)) return '📐';
        if (['scripts', 'bin', 'tools', 'cmd'].includes(lowerName)) return '📜';
        if (['locales', 'i18n', 'lang', 'translations'].includes(lowerName)) return '🌍';
        if (['auth', 'login', 'security'].includes(lowerName)) return '🔒';
        return isExpanded ? '📂' : '📁';
    }

    // Exact matches
    if (lowerName === 'package.json') return '📦';
    if (lowerName === 'package-lock.json' || lowerName === 'yarn.lock' || lowerName === 'pnpm-lock.yaml' || lowerName === 'bun.lockb') return '🔐';
    if (lowerName === 'tsconfig.json' || lowerName === 'jsconfig.json' || lowerName === 'deno.json') return '⚙️';
    if (lowerName === 'readme.md') return '📖';
    if (lowerName === 'license' || lowerName === 'license.md' || lowerName === 'license.txt') return '⚖️';
    if (lowerName === 'changelog.md' || lowerName === 'history.md') return '📜';
    if (lowerName === '.gitignore' || lowerName === '.npmignore' || lowerName === '.dockerignore' || lowerName === '.editorconfig') return '🚫';
    if (lowerName.startsWith('.env')) return '🔒';
    if (lowerName === 'dockerfile' || lowerName === 'docker-compose.yml') return '🐳';
    if (lowerName === 'makefile' || lowerName === 'gemfile' || lowerName === 'rakefile') return '🐘';
    if (lowerName === 'cargo.toml') return '🦀';
    if (lowerName === 'go.mod' || lowerName === 'go.sum') return '🐹';
    if (lowerName === 'requirements.txt' || lowerName === 'pipfile' || lowerName === 'pyproject.toml') return '🐍';
    if (lowerName === 'composer.json') return '🐘';
    if (lowerName === 'mix.exs') return '💧';
    if (lowerName === 'maven.xml' || lowerName === 'pom.xml' || lowerName === 'build.gradle') return '☕';
    if (lowerName === 'vercel.json' || lowerName === 'netlify.toml') return '☁️';
    
    // Partial matches
    if (lowerName.includes('eslint')) return '🛡️';
    if (lowerName.includes('prettier')) return '🖌️';
    if (lowerName.includes('babel')) return '🐠';
    if (lowerName.includes('webpack')) return '🧊';
    if (lowerName.includes('rollup')) return '🌯';
    if (lowerName.includes('vite')) return '⚡';
    if (lowerName.includes('tailwind') || lowerName.includes('postcss')) return '🎨';
    if (lowerName.includes('jest') || lowerName.includes('vitest') || lowerName.includes('cypress') || lowerName.includes('mocha')) return '🧪';
    if (lowerName === 'next.config.js' || lowerName === 'nuxt.config.js' || lowerName === 'remix.config.js') return '▲';

    const ext = name.split('.').pop()?.toLowerCase();

    switch (ext) {
        case 'ts': 
            if(lowerName.endsWith('.d.ts')) return '📐';
            if(lowerName.endsWith('.test.ts') || lowerName.endsWith('.spec.ts')) return '🧪';
            if(lowerName === 'main.ts' || lowerName === 'index.ts') return '🚀';
            return '📘';
        case 'tsx': return '⚛️';
        case 'js': case 'mjs': case 'cjs': 
            if(lowerName.endsWith('.test.js') || lowerName.endsWith('.spec.js')) return '🧪';
            if(lowerName === 'index.js' || lowerName === 'main.js') return '🚀';
            return '📒';
        case 'jsx': return '⚛️';
        case 'py': return '🐍';
        case 'go': return '🐹';
        case 'rs': return '🦀';
        case 'java': return '☕';
        case 'c': return '🇨';
        case 'cpp': case 'cc': case 'cxx': return '🇨';
        case 'h': case 'hpp': return '📋';
        case 'cs': return '♯';
        case 'rb': return '💎';
        case 'php': return '🐘';
        case 'swift': return '🐦';
        case 'kt': case 'kts': return '🤖';
        case 'dart': return '🎯';
        case 'ex': case 'exs': return '💧';
        case 'clj': case 'cljs': return '🌀';
        case 'css': case 'scss': case 'less': case 'sass': case 'styl': return '🎨';
        case 'html': case 'htm': return '🌐';
        case 'json': case 'json5': return '🔧';
        case 'yml': case 'yaml': return '⚙️';
        case 'toml': case 'ini': case 'conf': case 'config': return '⚙️';
        case 'xml': case 'svg': return '🖼️';
        case 'md': case 'txt': case 'rst': case 'adoc': return '📝';
        case 'png': case 'jpg': case 'jpeg': case 'gif': case 'ico': case 'webp': case 'avif': return '🖼️';
        case 'sql': case 'db': case 'sqlite': case 'prisma': return '🗄️';
        case 'sh': case 'bat': case 'ps1': case 'bash': case 'zsh': return '🐚';
        case 'zip': case 'tar': case 'gz': case '7z': case 'rar': return '🤐';
        case 'lock': return '🔒';
        case 'map': return '🗺️';
        case 'ttf': case 'otf': case 'woff': case 'woff2': return '🔤';
        case 'vue': return '🟢';
        case 'svelte': return '🟠';
        case 'astro': return '🚀';
        case 'graphql': case 'gql': return '⚛️';
        case 'sol': return '⛓️';
        case 'env': return '🔒';
        default: return '📄';
    }
};

const TreeItem = ({ node, level, onSelect, expandedPaths, togglePath, symbolsMap, onScrollToLine, selectedPath }: any) => {
    const isExpanded = expandedPaths.has(node.path);
    const nodeSymbols = node.type === 'file' ? symbolsMap[node.path] : undefined;
    const isSelected = node.path === selectedPath;
    
    // Estimate LOC
    const loc = node.type === 'file' && node.size ? Math.ceil(node.size / 30) : null;
    const emoji = getFileEmoji(node.name, node.type === 'directory', isExpanded);

    return (
        <div>
            <div 
                className={`
                    flex items-center gap-2 py-1 px-2 cursor-pointer text-sm select-none truncate group transition-all relative border-l-2
                    ${isSelected 
                        ? 'bg-blue-900/30 text-blue-300 border-blue-500 font-medium' 
                        : (node.type === 'file' ? 'hover:bg-blue-900/10 border-transparent hover:border-blue-500/30' : 'hover:bg-gray-900/50 border-transparent hover:border-gray-600')
                    }
                `}
                style={{ paddingLeft: `${level * 16 + 8}px` }}
                onClick={(e) => {
                    e.stopPropagation();
                    if (node.type === 'file') onSelect(node.path);
                    else togglePath(node.path);
                }}
            >
                <span className="w-5 flex-none text-center transform transition-transform duration-200 text-base" style={{ opacity: node.type === 'directory' ? 1 : 0.8 }}>
                    {emoji}
                </span>
                
                <span className={`
                    truncate font-mono tracking-tight
                    ${isSelected ? 'text-blue-200' : (node.type === 'file' ? 'text-gray-400 group-hover:text-blue-300' : 'text-gray-300 font-bold group-hover:text-white')}
                `}>
                    {node.name}
                </span>
                
                {node.type === 'file' && (
                    <span className="ml-auto flex items-center gap-3 text-[9px] font-mono opacity-0 group-hover:opacity-100 transition-opacity">
                        {loc !== null && <span className="text-blue-500">{loc}L</span>}
                        {node.size && <span className="text-gray-600">{(node.size / 1024).toFixed(1)}K</span>}
                    </span>
                )}
            </div>

            {isExpanded && (
                <>
                    {nodeSymbols && nodeSymbols.length > 0 && (
                        <div className="border-l border-gray-800 ml-4 my-0.5 bg-gray-900/20">
                            {nodeSymbols.map((s: SymbolData, i: number) => (
                                <div 
                                    key={i} 
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        onSelect(node.path);
                                        setTimeout(() => onScrollToLine(s.line), 100);
                                    }}
                                    className="text-[10px] text-gray-500 py-0.5 pl-8 hover:text-cyan-400 hover:bg-white/5 cursor-pointer flex items-center gap-2 transition-colors border-l-2 border-transparent hover:border-cyan-500/50"
                                >
                                    {s.type === 'class' && <SymbolClassIcon className="w-3 h-3 text-yellow-500" />}
                                    {s.type === 'method' && <SymbolMethodIcon className="w-3 h-3 text-purple-400" />}
                                    {s.type === 'func' && <SymbolMethodIcon className="w-3 h-3 text-purple-400" />}
                                    {s.type === 'var' && <SymbolVariableIcon className="w-3 h-3 text-blue-400" />}
                                    {s.type === 'interface' && <SymbolInterfaceIcon className="w-3 h-3 text-green-400" />}
                                    <span className="truncate">{s.name}</span>
                                </div>
                            ))}
                        </div>
                    )}
                    {node.children && (
                        <div>
                            {node.children.map((child: any) => (
                                <TreeItem 
                                    key={child.path} 
                                    node={child} 
                                    level={level + 1} 
                                    onSelect={onSelect} 
                                    expandedPaths={expandedPaths} 
                                    togglePath={togglePath}
                                    symbolsMap={symbolsMap}
                                    onScrollToLine={onScrollToLine}
                                    selectedPath={selectedPath}
                                />
                            ))}
                        </div>
                    )}
                </>
            )}
        </div>
    );
};

const ProjectExplorer: React.FC<ProjectExplorerProps> = ({ 
    title, version, description, fileTree, onClose, stats 
}) => {
    const { 
        selectedFile, fileContent, selectFile, 
        triggerDeepScan, isExplorerScanning, explorerAnalysis,
        githubConfig, viewedResource, variables,
        isHydrating, libraryContext
    } = useStudio();
    
    const [expandedPaths, setExpandedPaths] = useState<Set<string>>(new Set());
    const [symbolsMap, setSymbolsMap] = useState<Record<string, SymbolData[]>>({});
    const [viewMode, setViewMode] = useState<'code' | 'visuals' | 'intel'>('code');
    const [visualSubMode, setVisualSubMode] = useState<'graph' | 'flow' | 'poster'>('graph');
    
    const [sidebarWidth, setSidebarWidth] = useState(300);
    const [fullScreenImage, setFullScreenImage] = useState<string | null>(null);

    const [setupScript, setSetupScript] = useState('');
    const [isGeneratingScript, setIsGeneratingScript] = useState(false);
    
    const [userModalOpen, setUserModalOpen] = useState(false);
    const [targetUsername, setTargetUsername] = useState('');

    const [upstreamOwner, setUpstreamOwner] = useState<string | null>(null);

    // Auto-select README.md on load
    useEffect(() => {
        // Try multiple variations of readme
        const trySelectReadme = async () => {
            if (fileTree.length > 0 && !selectedFile) {
                const flatten = (nodes: any[]): any[] => {
                    let res: any[] = [];
                    nodes.forEach(n => {
                        res.push(n);
                        if (n.children) res = res.concat(flatten(n.children));
                    });
                    return res;
                };
                const allFiles = flatten(fileTree);
                const readme = allFiles.find(f => 
                    f.type === 'file' && /readme\.md$/i.test(f.name)
                );
                
                if (readme) {
                    await selectFile(readme.path);
                }
            }
        }
        trySelectReadme();
    }, [fileTree, selectedFile, selectFile]);

    // Generate symbols when content changes for supported files
    useEffect(() => {
        let active = true;
        const analyze = async () => {
             if(selectedFile && fileContent && !fileContent.startsWith('// ERROR') && /\.(js|ts|jsx|tsx|mjs|cjs|vue|java|py|go)$/.test(selectedFile.name) || selectedFile?.name.endsWith('.d.ts')) {
                const symbols = await analyzeWithTsMorph(fileContent);
                if (active) {
                    setSymbolsMap(prev => ({ ...prev, [selectedFile.path]: symbols }));
                    if(symbols.length > 0) setExpandedPaths(prev => new Set(prev).add(selectedFile.path));
                }
            }
        }
        analyze();
        return () => { active = false; };
    }, [selectedFile, fileContent]);

    useEffect(() => {
        if (viewedResource?.type === 'github') {
            const data = viewedResource.data as GitProject;
            const currentOwner = data.owner;
            const currentRepo = data.projectName;
            
            if (data.originUrl) {
                const parsed = parseGitHubUrl(data.originUrl);
                if (parsed && parsed.owner !== currentOwner) {
                    setUpstreamOwner(parsed.owner);
                }
            }

            if (githubConfig.token) {
                getRepoDetails(githubConfig.token, currentOwner, currentRepo)
                    .then(details => {
                        if (details.parent) {
                            setUpstreamOwner(details.parent.owner.login);
                        } else if (details.fork === false) {
                            setUpstreamOwner(null);
                        }
                    })
                    .catch(e => console.warn("Failed to fetch repo details for fork check", e));
            }
        } else {
            setUpstreamOwner(null);
        }
    }, [viewedResource, githubConfig]);

    const handleFileSelect = (path: string) => {
        if (viewMode !== 'code') setViewMode('code');
        selectFile(path);
    };

    const togglePath = (path: string) => {
        setExpandedPaths(prev => {
            const next = new Set(prev);
            if (next.has(path)) next.delete(path);
            else next.add(path);
            return next;
        });
    };

    const scrollToLine = (line: number) => {
        // Placeholder for future Monaco line scroll
    };

    const handleOpenUserModal = (username: string) => {
        setTargetUsername(username);
        setUserModalOpen(true);
    };

    let githubUrl = null;
    let maintainers: { name: string, email?: string }[] = [];
    let npmUrl = null;
    let displayOwner = '';
    let displayLabel = 'BY';

    if (viewedResource?.type === 'github') {
        const data = viewedResource.data as any;
        displayOwner = upstreamOwner || data.owner;
        displayLabel = upstreamOwner ? "FORKED FROM" : "BY";
        if (data.originUrl) {
            githubUrl = data.originUrl;
        } else {
             githubUrl = `https://github.com/${data.owner}/${data.projectName}`;
        }
    } else if (viewedResource?.type === 'npm') {
        const data = viewedResource.data as EnrichedPackageInfo;
        npmUrl = `https://www.npmjs.com/package/${data.name}`;
        
        // Ensure robust access to maintainers array from enriched info
        const rawMaintainers = data.maintainers;
        if (Array.isArray(rawMaintainers)) {
            // Deduplicate logic just in case
            const seen = new Set();
            maintainers = rawMaintainers.filter(m => {
                const k = m.name;
                return seen.has(k) ? false : seen.add(k);
            });
        } else if (rawMaintainers) {
            maintainers = [rawMaintainers as any]; 
        } else {
            maintainers = [];
        }
        
        if (data.repositoryUrl) {
            githubUrl = data.repositoryUrl.startsWith('http') ? data.repositoryUrl : `https://github.com/${data.repositoryUrl}`;
        }
    }

    const handleGenerateSetup = async () => {
        if (!viewedResource) return;
        setIsGeneratingScript(true);
        setSetupScript('');

        try {
            const flatten = (nodes: any[]): string[] => {
                let res: string[] = [];
                nodes.forEach(n => { res.push(n.path); if (n.children) res = res.concat(flatten(n.children)); });
                return res;
            };
            const allFiles = flatten(fileTree);
            
            let packageJson = null;
            let readme = null;
            
            if (viewedResource.type === 'github') {
                const config = { token: githubConfig.token, owner: (viewedResource.data as any).owner, repo: (viewedResource.data as any).projectName };
                packageJson = await getFileContent(config, 'package.json');
                readme = await getFileContent(config, 'README.md');
            }
            
            const knownVars: Record<string, string> = {};
            variables.forEach(v => knownVars[v.key] = v.value);
            
            const script = await generateSetupScript(
                viewedResource.name,
                allFiles,
                packageJson,
                readme,
                [], 
                knownVars
            );

            setSetupScript(script);

        } catch (e) {
            setSetupScript("# Error generating script");
        } finally {
            setIsGeneratingScript(false);
        }
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-in fade-in zoom-in-95 duration-200">
            {fullScreenImage && (
                <ImageViewer src={fullScreenImage} alt="Visualization" onClose={() => setFullScreenImage(null)} />
            )}
            
            <UserProfileModal 
                isOpen={userModalOpen} 
                onClose={() => setUserModalOpen(false)} 
                username={targetUsername} 
            />
            
            <div className="glass-panel w-full max-w-[95vw] h-[95vh] rounded-xl flex flex-col overflow-hidden relative border border-gray-700 shadow-2xl">
                
                {/* Header */}
                <header className="bg-[#0a0a0a]/95 backdrop-blur p-4 border-b border-gray-800 flex justify-between items-start shrink-0">
                    <div className="flex flex-col gap-1 w-full">
                        <div className="flex items-center gap-3">
                            <h2 className="text-2xl font-bold text-white neon-text tracking-tight">{title}</h2>
                            <span className="bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs px-2 py-0.5 rounded-full font-mono">v{version}</span>
                            
                            {/* Render Owner for GitHub */}
                            {viewedResource?.type === 'github' && displayOwner && (
                                <button
                                    onClick={() => handleOpenUserModal(displayOwner)}
                                    className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-purple-900/30 border border-purple-500/30 hover:bg-purple-900/50 hover:border-purple-400 transition-all group"
                                    title={`View ${displayOwner}'s Profile`}
                                >
                                    <span className="text-[10px] text-purple-400 font-bold tracking-widest uppercase group-hover:text-purple-300">{displayLabel} {displayOwner}</span>
                                    <GitHubIcon className="w-3 h-3 text-purple-400 group-hover:text-white" />
                                </button>
                            )}

                            <div className="flex items-center gap-2 ml-2 border-l border-gray-700 pl-2">
                                {githubUrl && (
                                    <a href={githubUrl} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-white transition-colors p-1 rounded-full hover:bg-white/10" title="Open in GitHub">
                                        <GitHubIcon className="w-5 h-5" />
                                    </a>
                                )}
                                {npmUrl && (
                                    <a href={npmUrl} target="_blank" rel="noopener noreferrer" className="text-red-500 hover:text-red-400 transition-colors p-1 rounded-full hover:bg-white/10" title="Open in NPM">
                                        <NpmIcon className="w-5 h-5" />
                                    </a>
                                )}
                            </div>
                        </div>
                        
                        <p className="text-gray-400 text-sm truncate max-w-3xl font-light">{description}</p>
                        
                        {/* Explicit Maintainer Rendering for NPM - Always visible if data exists */}
                        {maintainers.length > 0 && (
                            <div className="flex items-center gap-2 mt-2 flex-wrap">
                                <span className="text-[10px] uppercase text-gray-500 font-bold tracking-wider">Maintainers:</span>
                                {maintainers.map((m, i) => (
                                    <button 
                                        key={i} 
                                        onClick={() => handleOpenUserModal(m.name)}
                                        className="text-[11px] text-gray-300 bg-gray-800/80 px-2 py-1 rounded border border-gray-600 hover:text-white hover:bg-gray-700 hover:border-cyan-500 transition-all flex items-center gap-1.5 shadow-sm group"
                                    >
                                        <span className="w-1.5 h-1.5 rounded-full bg-green-500 group-hover:animate-pulse"></span>
                                        {m.name}
                                    </button>
                                ))}
                            </div>
                        )}

                        {stats && (
                            <div className="flex gap-6 mt-2 pt-2 border-t border-gray-800/50 text-[10px] font-mono text-gray-500 tracking-wider items-center">
                                {stats.unpackedSize ? <div>SIZE: <span className="text-gray-300">{(stats.unpackedSize / 1024).toFixed(0)} KB</span></div> : null}
                                {stats.fileCount ? <div>FILES: <span className="text-gray-300">{stats.fileCount}</span></div> : null}
                                {stats.publishDate && <div>UPDATED: <span className="text-gray-300">{formatRelativeTime(stats.publishDate)}</span></div>}
                                
                                {isHydrating ? (
                                    <div className="flex items-center gap-2 text-yellow-500 animate-pulse bg-yellow-900/10 px-2 py-0.5 rounded">
                                        <Spinner className="w-3 h-3 text-yellow-500" />
                                        <span>INDEXING LIBRARY...</span>
                                    </div>
                                ) : libraryContext?.isHydrated ? (
                                    <div className="flex items-center gap-2 text-green-500 bg-green-900/10 px-2 py-0.5 rounded">
                                        <div className="w-2 h-2 bg-green-500 rounded-full shadow-[0_0_8px_rgba(34,197,94,0.8)]"></div>
                                        <span>LIBRARY HOT-CACHED</span>
                                    </div>
                                ) : null}
                            </div>
                        )}
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-red-900/30 rounded-full text-gray-400 hover:text-red-400 transition-colors">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </header>

                {/* Main Content */}
                <div className="flex flex-1 overflow-hidden">
                    {/* Sidebar */}
                    <div style={{ width: sidebarWidth }} className="bg-[#050505] border-r border-gray-800 flex flex-col flex-none">
                        <div className="grid grid-cols-3 border-b border-gray-800 shrink-0">
                            {[
                                { id: 'code', label: 'Code', icon: CodeBracketIcon },
                                { id: 'visuals', label: 'Visualize', icon: Layers },
                                { id: 'intel', label: 'Intel', icon: ChartBarIcon }
                            ].map(tab => (
                                <button 
                                    key={tab.id}
                                    onClick={() => setViewMode(tab.id as any)}
                                    className={`py-3 text-[10px] font-bold uppercase tracking-wider transition-all border-b-2 flex flex-col items-center gap-1 ${viewMode === tab.id 
                                        ? 'text-cyan-400 bg-cyan-900/10 border-cyan-500' 
                                        : 'text-gray-600 hover:text-gray-300 border-transparent'}`}
                                >
                                    <tab.icon className="w-4 h-4" />
                                    {tab.label}
                                </button>
                            ))}
                        </div>

                        <div className="flex-1 overflow-y-auto custom-scrollbar p-2 bg-[#050505]">
                            <div className="mb-2">
                                <button 
                                    onClick={triggerDeepScan}
                                    disabled={isExplorerScanning}
                                    className={`w-full py-2.5 text-xs font-bold uppercase tracking-wider rounded transition-colors flex items-center justify-center gap-2 disabled:opacity-50 neon-border ${
                                        isExplorerScanning 
                                            ? 'bg-cyan-900/10 text-cyan-600 cursor-wait' 
                                            : 'bg-cyan-900/20 text-cyan-400 hover:bg-cyan-900/40 hover:text-cyan-300'
                                    }`}
                                >
                                    {isExplorerScanning ? (
                                        <><Spinner className="w-3 h-3" /> ANALYZING...</>
                                    ) : (
                                        <><Sparkles className="w-3 h-3" /> DEEP ANALYZE</>
                                    )}
                                </button>
                            </div>

                            {viewMode === 'code' && (
                                <div className="space-y-0.5">
                                    {fileTree.map(node => (
                                        <TreeItem 
                                            key={node.path} 
                                            node={node} 
                                            level={0} 
                                            onSelect={handleFileSelect} 
                                            expandedPaths={expandedPaths}
                                            togglePath={togglePath}
                                            symbolsMap={symbolsMap}
                                            onScrollToLine={scrollToLine}
                                            selectedPath={selectedFile?.path}
                                        />
                                    ))}
                                </div>
                            )}

                            {viewMode === 'visuals' && (
                                <div className="p-4 text-center text-xs text-gray-500">
                                    <Layers className="w-12 h-12 mx-auto mb-3 opacity-20" />
                                    <p>Select visualization mode in the main view.</p>
                                    <p className="mt-2 text-[10px]">
                                        Available modes:<br/>
                                        • Interactive Graph<br/>
                                        • Logic Flow<br/>
                                        • Blueprint
                                    </p>
                                </div>
                            )}

                            {viewMode === 'intel' && (
                                <div className="space-y-4 p-2">
                                    {explorerAnalysis ? (
                                        <>
                                            <div className="bg-gray-900/40 p-3 rounded border border-gray-800">
                                                <h4 className="text-[10px] uppercase font-bold text-gray-500 mb-2 tracking-widest">Structure</h4>
                                                <div className="grid grid-cols-1 gap-2 text-xs text-gray-400 font-mono">
                                                    <div>Langs: <span className="text-white">{explorerAnalysis.structure?.languages?.join(', ') || '-'}</span></div>
                                                    <div>Frameworks: <span className="text-white">{explorerAnalysis.structure?.frameworks?.join(', ') || '-'}</span></div>
                                                    <div className={explorerAnalysis.structure?.hasTests ? "text-green-400" : ""}>Tests: {explorerAnalysis.structure?.hasTests ? 'DETECTED' : 'NONE'}</div>
                                                    <div className={explorerAnalysis.structure?.hasTypes ? "text-green-400" : ""}>Types: {explorerAnalysis.structure?.hasTypes ? 'DETECTED' : 'NONE'}</div>
                                                </div>
                                            </div>
                                            <div className="bg-gray-900/40 p-3 rounded border border-gray-800">
                                                <h4 className="text-[10px] uppercase font-bold text-gray-500 mb-2 tracking-widest">Exports</h4>
                                                <div className="text-xs text-gray-400 space-y-1 font-mono">
                                                    <div>Format: <span className="text-cyan-400">{explorerAnalysis.exports?.moduleFormat?.toUpperCase() || 'UNKNOWN'}</span></div>
                                                    {explorerAnalysis.exports?.entryPoints && Object.entries(explorerAnalysis.exports.entryPoints).map(([k, v]) => (
                                                        <div key={k} className="truncate"><span className="text-gray-600">{k}:</span> <span className="text-gray-300">{v as string}</span></div>
                                                    ))}
                                                </div>
                                            </div>
                                            <div className="bg-gray-900/40 p-3 rounded border border-gray-800">
                                                <h4 className="text-[10px] uppercase font-bold text-gray-500 mb-2 tracking-widest">DevOps & Deployment</h4>
                                                <p className="text-xs text-gray-400 mb-3">
                                                    Generate a localized setup script. It uses your saved Variables to auto-fill secrets.
                                                </p>
                                                <button 
                                                    onClick={handleGenerateSetup}
                                                    disabled={isGeneratingScript}
                                                    className="w-full py-2 bg-green-600 text-white text-xs font-bold rounded hover:bg-green-500 flex items-center justify-center gap-2"
                                                >
                                                    {isGeneratingScript ? <Spinner className="w-3 h-3 text-white" /> : 'Create Setup Script'}
                                                </button>
                                            </div>
                                        </>
                                    ) : (
                                        <div className="text-center text-gray-600 text-xs py-4">
                                            Run "Deep Analyze" to populate intelligence.
                                        </div>
                                    )}
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Resize Handle */}
                    <div 
                        className="w-1 bg-[#0a0a0a] hover:bg-cyan-500 cursor-col-resize z-10 transition-colors border-r border-gray-800"
                        onMouseDown={(e) => {
                            const startX = e.clientX;
                            const startWidth = sidebarWidth;
                            const handleMouseMove = (ev: MouseEvent) => setSidebarWidth(startWidth + (ev.clientX - startX));
                            const handleMouseUp = () => {
                                document.removeEventListener('mousemove', handleMouseMove);
                                document.removeEventListener('mouseup', handleMouseUp);
                            };
                            document.addEventListener('mousemove', handleMouseMove);
                            document.addEventListener('mouseup', handleMouseUp);
                        }}
                    />

                    {/* Content Area */}
                    <div className="flex-1 flex flex-col bg-[#050505] overflow-hidden relative">
                        {viewMode === 'visuals' && (
                             <div className="h-10 border-b border-gray-800 flex items-center justify-center bg-[#0a0a0a] shrink-0">
                                <div className="flex bg-gray-900 rounded p-0.5">
                                    {[
                                        { id: 'graph', label: 'Interactive Graph' },
                                        { id: 'flow', label: 'Logic Flow' },
                                        { id: 'poster', label: 'Blueprint' }
                                    ].map(sub => (
                                        <button
                                            key={sub.id}
                                            onClick={() => setVisualSubMode(sub.id as any)}
                                            className={`px-4 py-1 text-xs font-medium rounded transition-all ${
                                                visualSubMode === sub.id 
                                                ? 'bg-cyan-600 text-white shadow' 
                                                : 'text-gray-400 hover:text-white'
                                            }`}
                                        >
                                            {sub.label}
                                        </button>
                                    ))}
                                </div>
                             </div>
                        )}

                        {viewMode === 'visuals' ? (
                            <div className="flex-1 overflow-hidden relative bg-[#020617]">
                                {visualSubMode === 'graph' && (
                                    explorerAnalysis?.d3Graph ? (
                                        <D3FlowChart data={explorerAnalysis.d3Graph} onNodeClick={(node) => console.log(node)} />
                                    ) : (
                                        <div className="flex flex-col items-center justify-center h-full text-gray-500">
                                            <Box className="w-16 h-16 opacity-20 mb-4" />
                                            <p className="text-sm">No Graph Data</p>
                                            <p className="text-xs mt-1">Run Deep Analyze to generate the node graph.</p>
                                        </div>
                                    )
                                )}

                                {visualSubMode === 'flow' && (
                                     explorerAnalysis?.mermaidGraph ? (
                                        <MermaidViewer graphDefinition={explorerAnalysis.mermaidGraph} />
                                    ) : (
                                        <div className="flex flex-col items-center justify-center h-full text-gray-500">
                                            <CodeBracketIcon className="w-16 h-16 opacity-20 mb-4" />
                                            <p className="text-sm">No Flow Data</p>
                                            <p className="text-xs mt-1">Run Deep Analyze to generate UML flow.</p>
                                        </div>
                                    )
                                )}

                                {visualSubMode === 'poster' && (
                                    explorerAnalysis?.infographic ? (
                                        <div className="flex-1 flex items-center justify-center p-8 bg-black h-full">
                                            <div className="relative group max-w-full max-h-full">
                                                <img 
                                                    src={`data:image/png;base64,${explorerAnalysis.infographic}`} 
                                                    className="max-w-full max-h-[80vh] object-contain shadow-2xl rounded-lg cursor-pointer" 
                                                    alt="Visualization" 
                                                    onClick={() => setFullScreenImage(`data:image/png;base64,${explorerAnalysis.infographic}`)}
                                                />
                                                <a 
                                                    href={`data:image/png;base64,${explorerAnalysis.infographic}`} 
                                                    download={`${title}-blueprint.png`}
                                                    className="absolute bottom-4 right-4 bg-black/80 text-white px-3 py-1 rounded text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                                                >
                                                    Download
                                                </a>
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="flex flex-col items-center justify-center h-full text-gray-500">
                                            <Layers className="w-16 h-16 opacity-20 mb-4" />
                                            <p className="text-sm">No Blueprint</p>
                                            <p className="text-xs mt-1">Run Deep Analyze to generate an architectural poster.</p>
                                        </div>
                                    )
                                )}
                            </div>
                        ) : viewMode === 'intel' ? (
                             <div className="flex-1 overflow-auto bg-[#050505] p-6 font-mono text-sm relative">
                                 {setupScript ? (
                                     <div>
                                         <div className="flex items-center justify-between mb-4 border-b border-gray-800 pb-2">
                                             <h3 className="text-green-400 font-bold">Generated Setup Script</h3>
                                             <button 
                                                onClick={() => navigator.clipboard.writeText(setupScript)}
                                                className="text-xs bg-gray-800 px-3 py-1 rounded text-gray-300 hover:text-white"
                                             >
                                                 Copy
                                             </button>
                                         </div>
                                         <pre className="text-gray-300 bg-black p-4 rounded-lg border border-gray-800 overflow-x-auto">
                                             {setupScript}
                                         </pre>
                                     </div>
                                 ) : (
                                     <div className="flex flex-col items-center justify-center h-full text-gray-500">
                                         <ChartBarIcon className="w-24 h-24 opacity-10 mb-4" />
                                         <p>Select "Create Setup Script" from the sidebar to generate DevOps assets.</p>
                                     </div>
                                 )}
                             </div>
                        ) : (
                            // CODE VIEW
                            <>
                                <div className="h-8 border-b border-gray-800 flex items-center px-4 bg-[#0a0a0a] text-[10px] text-gray-500 font-mono justify-between shrink-0">
                                    <span>{selectedFile ? selectedFile.path : 'NO FILE SELECTED'}</span>
                                    {selectedFile && <span>{fileContent ? fileContent.split('\n').length : 0} LINES</span>}
                                </div>
                                
                                <div className="flex-1 overflow-hidden relative flex">
                                    {!fileContent && selectedFile && (
                                        <div className="absolute inset-0 flex items-center justify-center bg-black/50 z-20 backdrop-blur-sm">
                                            <Spinner text="LOADING CONTENT..." />
                                        </div>
                                    )}
                                    
                                    {selectedFile ? (
                                        fileContent.startsWith('// ERROR:') ? (
                                            <div className="flex flex-col items-center justify-center h-full w-full bg-red-900/10 text-red-400 p-8 text-center">
                                                <CloseIcon className="w-12 h-12 mb-4 opacity-50" />
                                                <h3 className="font-bold text-lg mb-2">Failed to Load Module</h3>
                                                <pre className="text-xs bg-black/50 p-4 rounded border border-red-900/50 mb-4 max-w-lg whitespace-pre-wrap">
                                                    {fileContent}
                                                </pre>
                                                <button 
                                                    onClick={() => selectFile(selectedFile.path)} 
                                                    className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded text-sm font-bold shadow-lg"
                                                >
                                                    Retry Connection
                                                </button>
                                            </div>
                                        ) : (
                                            <div className="flex-1 flex overflow-hidden">
                                                <div className="flex-1 min-w-0 h-full">
                                                    <FileContent fileName={selectedFile.name} content={fileContent} />
                                                </div>
                                            </div>
                                        )
                                    ) : (
                                        <div className="flex flex-col items-center justify-center h-full w-full text-gray-700">
                                            <CodeBracketIcon className="w-24 h-24 opacity-10 mb-4" />
                                            <p className="font-mono text-xs tracking-widest">SELECT A MODULE TO INSPECT</p>
                                        </div>
                                    )}
                                </div>
                            </>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProjectExplorer;
