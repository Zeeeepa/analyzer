
import React, { useState, useEffect, useRef } from 'react';
import { runAutonomousAgent, AgentStep, StudioController } from '../services/geminiService';
import { GeminiIcon, CloseIcon } from './icons';
import Spinner from './Spinner';
import { useStudio } from '../contexts/StudioContext';

const ChatWidget: React.FC = () => {
  const { 
    chatContext, githubConfig, isGithubConfigured, 
    setActiveTab, openResource, closeResource, selectFile, triggerDeepScan,
    viewedResource, activeTab, selectedFile, explorerTree, libraryContext, searchSymbols,
    executeSwarmQuery, queryGraph
  } = useStudio();
  
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'model'; content: string; steps?: AgentStep[] }[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [currentMessage, setCurrentMessage] = useState('');
  const [currentSteps, setCurrentSteps] = useState<AgentStep[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const context = chatContext;
  const isReady = !!githubConfig && isGithubConfigured;

  useEffect(() => {
    if (isReady && messages.length === 0) {
        setMessages([{
            role: 'model',
            content: `System Core Online. I can operate the Studio interface.\nTry: *"Open react package"*, *"Analyze this repo"*, or *"Find the Auth logic"*`
        }]);
    }
  }, [isReady]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, currentSteps]);

  // Construct Controller for Agent
  const controller: StudioController = {
      navigate: setActiveTab,
      openResource: openResource,
      closeResource: closeResource,
      selectFile: selectFile,
      triggerScan: triggerDeepScan,
      getState: () => ({
          activeTab,
          viewedResource: viewedResource ? { name: viewedResource.name, type: viewedResource.type } : null,
          selectedFile: selectedFile,
          explorerFileCount: explorerTree.length
      }),
      getLibraryContext: () => libraryContext,
      searchSymbols: searchSymbols,
      queryGraph: queryGraph,
      delegateToSwarm: (task) => {
          setActiveTab('swarm');
          executeSwarmQuery(task);
      }
  };

  const handleSend = async () => {
    if (!currentMessage.trim() || !githubConfig || isLoading) return;
    
    const userMsg = currentMessage;
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setCurrentMessage('');
    setIsLoading(true);
    setCurrentSteps([]);

    try {
        const generator = runAutonomousAgent(userMsg, context, githubConfig, controller);
        let finalResponse = "";

        for await (const step of generator) {
            if (step.type === 'response') {
                finalResponse = step.content;
            } else {
                setCurrentSteps(prev => [...prev, step]);
            }
        }

        setMessages(prev => [...prev, { 
            role: 'model', 
            content: finalResponse || "Task completed.",
            steps: currentSteps 
        }]);

    } catch (error) {
        console.error("Agent Error:", error);
        setMessages(prev => [...prev, { role: 'model', content: "Protocol Failure: Agent connection interrupted." }]);
    } finally {
        setIsLoading(false);
        setCurrentSteps([]);
    }
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        disabled={!isReady}
        className={`fixed bottom-6 right-6 w-14 h-14 rounded-full shadow-[0_0_20px_rgba(34,197,94,0.3)] flex items-center justify-center transition-all hover:scale-110 z-[200] ${isReady ? 'bg-green-600 hover:bg-green-500 text-white' : 'bg-gray-800 text-gray-500 cursor-not-allowed'}`}
        title={isReady ? "Open AI Agent" : "Configure GitHub to enable AI"}
      >
        <GeminiIcon className="w-8 h-8" />
      </button>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 w-[90vw] md:w-[500px] h-[700px] max-h-[85vh] bg-[#050505] border border-green-500/30 rounded-xl shadow-2xl flex flex-col z-[200] backdrop-blur-xl animate-in slide-in-from-bottom-5 duration-300 overflow-hidden">
      {/* Header */}
      <header className="flex items-center justify-between p-4 border-b border-green-500/20 bg-green-900/10 shrink-0">
        <div className="flex items-center gap-3">
            <div className="p-2 bg-green-500/20 rounded-lg">
                <GeminiIcon className="w-5 h-5 text-green-400" />
            </div>
            <div>
                <h3 className="font-bold text-green-400 text-sm tracking-wide neon-text">SYSTEM CORE</h3>
                <p className="text-[10px] text-green-600/70 font-mono truncate max-w-[200px]">
                    {context ? `LINKED: ${context.name}` : 'GLOBAL CONTROL MODE'}
                </p>
            </div>
        </div>
        <button onClick={() => setIsOpen(false)} className="text-gray-500 hover:text-white transition-colors p-2 hover:bg-white/10 rounded-full">
            <CloseIcon className="w-5 h-5" />
        </button>
      </header>

      {/* Messages */}
      <main className="flex-1 p-4 overflow-y-auto space-y-6 custom-scrollbar">
        {messages.map((msg, index) => (
          <div key={index} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
            
            {/* Steps Visualization (Mental Scratchpad) */}
            {msg.steps && msg.steps.length > 0 && (
                <div className="mb-2 w-full max-w-[95%] bg-gray-900/50 rounded-lg p-3 border-l-2 border-yellow-500/50 shadow-inner">
                    <div className="text-[10px] text-yellow-500 font-bold mb-2 uppercase tracking-wider flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-yellow-500 animate-pulse"></span>
                        Agent Execution Log
                    </div>
                    <div className="space-y-2">
                        {msg.steps.map((step, sIdx) => (
                            <div key={sIdx} className="text-[11px] font-mono border-b border-gray-800/50 last:border-0 pb-1 last:pb-0">
                                {step.type === 'thought' && (
                                    <div className="text-gray-400 flex gap-2">
                                        <span className="text-yellow-500/70">▶</span> 
                                        <span>{step.content}</span>
                                    </div>
                                )}
                                {step.type === 'action' && (
                                    <div className="text-blue-300 flex gap-2 pl-2">
                                        <span className="text-blue-500">⚡</span>
                                        <span className="font-semibold">{step.content}</span>
                                    </div>
                                )}
                                {step.type === 'observation' && (
                                    <div className="text-green-400/60 flex gap-2 pl-4 italic">
                                        <span>👁️</span> 
                                        <span>{step.content}</span>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Main Message Bubble */}
            <div className={`p-3 rounded-xl max-w-[90%] text-sm leading-relaxed shadow-lg ${
                msg.role === 'user' 
                ? 'bg-gradient-to-br from-green-600 to-green-800 text-white rounded-br-none border border-green-500/30' 
                : 'bg-[#111] text-gray-200 rounded-bl-none border border-gray-700'
            }`}>
              <div className="markdown-body" dangerouslySetInnerHTML={{ __html: msg.content.replace(/\n/g, '<br/>').replace(/\*\*(.*?)\*\*/g, '<b>$1</b>') }} />
            </div>
          </div>
        ))}

        {/* Live Loading State */}
        {isLoading && (
             <div className="flex flex-col items-start w-full animate-pulse">
                <div className="w-full max-w-[95%] bg-gray-900/50 rounded-lg p-3 border-l-2 border-green-500/50 mb-2">
                     <div className="text-[10px] text-green-500 font-bold mb-2 uppercase tracking-wider flex items-center gap-2">
                        <Spinner className="w-3 h-3 text-green-500" />
                        Live System Activity
                     </div>
                     <div className="space-y-2">
                         {currentSteps.map((step, sIdx) => (
                            <div key={sIdx} className="text-[11px] font-mono border-b border-gray-800/50 last:border-0 pb-1 last:pb-0">
                                {step.type === 'thought' && <div className="text-gray-400">▶ {step.content}</div>}
                                {step.type === 'action' && <div className="text-blue-300 pl-2">⚡ {step.content}</div>}
                                {step.type === 'observation' && <div className="text-green-400/60 pl-4">👁️ {step.content}</div>}
                            </div>
                        ))}
                        <div className="text-[10px] text-gray-500 font-mono pl-1">_</div>
                    </div>
                </div>
             </div>
        )}
        <div ref={messagesEndRef} />
      </main>

      {/* Input Area */}
      <footer className="p-3 border-t border-gray-800 bg-black/60 backdrop-blur-md shrink-0">
        <div className="flex gap-2 relative">
          <input
            type="text"
            value={currentMessage}
            onChange={(e) => setCurrentMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Control the system..."
            className="flex-1 bg-gray-900 border border-gray-700 rounded-lg p-3 text-sm text-white focus:outline-none focus:border-green-500 transition-colors font-mono pl-4 shadow-inner"
            disabled={!isReady || isLoading}
          />
          <button 
            onClick={handleSend} 
            disabled={!isReady || isLoading || !currentMessage.trim()} 
            className="bg-green-600 text-white px-4 rounded-lg hover:bg-green-500 disabled:bg-gray-800 disabled:text-gray-600 transition-colors font-bold uppercase text-xs tracking-wider shadow-lg hover:shadow-green-500/20"
          >
            EXECUTE
          </button>
        </div>
      </footer>
    </div>
  );
};

export default ChatWidget;
