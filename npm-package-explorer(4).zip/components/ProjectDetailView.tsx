// DEPRECATED: Replaced by ProjectExplorer.tsx
export default function ProjectDetailView() { return null; }