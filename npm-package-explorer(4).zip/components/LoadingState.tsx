
import React from 'react';
import { Loader2 } from 'lucide-react';

interface LoadingStateProps {
  message: string;
  type?: 'repo' | 'chat';
}

export const LoadingState: React.FC<LoadingStateProps> = ({ message, type = 'repo' }) => (
  <div className="flex flex-col items-center justify-center p-8 space-y-4 animate-in fade-in">
    <div className={`relative ${type === 'repo' ? 'w-16 h-16' : 'w-8 h-8'}`}>
      <div className="absolute inset-0 border-4 border-violet-500/30 rounded-full animate-ping"></div>
      <div className="absolute inset-0 border-4 border-t-violet-500 rounded-full animate-spin"></div>
    </div>
    <div className="text-center">
        <p className="text-violet-400 font-mono text-sm animate-pulse tracking-widest uppercase">{message}</p>
        <p className="text-slate-500 text-xs mt-1">Processing Neural Data...</p>
    </div>
  </div>
);
