// DEPRECATED
export default function ExploreView() { return null; }