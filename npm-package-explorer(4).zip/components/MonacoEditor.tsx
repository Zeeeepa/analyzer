
import React, { useRef, useEffect, useState } from 'react';

interface MonacoEditorProps {
    value: string;
    language?: string;
    readOnly?: boolean;
    fileName?: string;
}

declare global {
    interface Window {
        monaco: any;
        require: any;
    }
}

const MonacoEditor: React.FC<MonacoEditorProps> = ({ value, language, readOnly = true, fileName }) => {
    const editorRef = useRef<HTMLDivElement>(null);
    const [editor, setEditor] = useState<any>(null);

    // Map extensions to Monaco languages
    const getLanguage = (fname: string) => {
        if (language) return language;
        if (!fname) return 'plaintext';
        const ext = fname.split('.').pop()?.toLowerCase();
        switch (ext) {
            case 'js': case 'jsx': return 'javascript';
            case 'ts': case 'tsx': return 'typescript';
            case 'css': return 'css';
            case 'html': return 'html';
            case 'json': return 'json';
            case 'md': return 'markdown';
            case 'py': return 'python';
            case 'go': return 'go';
            case 'rs': return 'rust';
            case 'java': return 'java';
            case 'xml': case 'svg': return 'xml';
            case 'yml': case 'yaml': return 'yaml';
            default: return 'plaintext';
        }
    };

    useEffect(() => {
        let mounted = true;

        const initMonaco = () => {
            if (window.monaco) {
                if (!editorRef.current) return;
                
                // Clean up previous instance if exists (though React key usually handles this)
                if (editor) editor.dispose();

                const newEditor = window.monaco.editor.create(editorRef.current, {
                    value,
                    language: getLanguage(fileName || ''),
                    theme: 'vs-dark',
                    readOnly,
                    minimap: { enabled: true },
                    scrollBeyondLastLine: false,
                    fontSize: 13,
                    fontFamily: 'JetBrains Mono, monospace',
                    automaticLayout: true,
                    padding: { top: 16, bottom: 16 },
                    lineNumbers: 'on',
                    renderLineHighlight: 'all',
                });
                
                setEditor(newEditor);
            } else if (window.require) {
                // Wait for loader if script is present but not ready
                window.require(['vs/editor/editor.main'], () => {
                    if (mounted) initMonaco();
                });
            }
        };

        initMonaco();

        return () => {
            mounted = false;
            if (editor) {
                editor.dispose();
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [fileName]); // Re-init if filename changes to update language properly

    // Update value if it changes externally
    useEffect(() => {
        if (editor && editor.getValue() !== value) {
            editor.setValue(value);
        }
    }, [value, editor]);

    return (
        <div ref={editorRef} className="w-full h-full min-h-[300px]" />
    );
};

export default MonacoEditor;
