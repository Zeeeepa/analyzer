
import React, { useRef, useEffect, useState, useMemo } from 'react';
import * as d3 from 'd3';
import { D3Node, D3Link } from '../types';
import { FilterIcon, ZoomInIcon, ZoomOutIcon, RefreshIcon } from './icons';

interface D3FlowChartProps {
    data: { nodes: D3Node[]; links: D3Link[] };
    onNodeClick: (node: D3Node) => void;
}

type Scope = 'macro' | 'micro';

const D3FlowChart: React.FC<D3FlowChartProps> = ({ data, onNodeClick }) => {
    const svgRef = useRef<SVGSVGElement>(null);
    const wrapperRef = useRef<HTMLDivElement>(null);
    const [scope, setScope] = useState<Scope>('macro');
    const simulationRef = useRef<d3.Simulation<d3.SimulationNodeDatum, undefined> | null>(null);

    // Filter Data Based on Scope
    const { filteredNodes, filteredLinks } = useMemo(() => {
        if (!data || !data.nodes.length) return { filteredNodes: [], filteredLinks: [] };

        let nodes = [];
        if (scope === 'macro') {
            // Group 1 = Dirs, Group 2 = Files/Symbols. Keep only Group 1
            // Exception: Keep nodes that are entry points or root
            nodes = data.nodes.filter(n => n.group === 1 || n.id === '/');
        } else {
            // Micro: Show everything
            nodes = [...data.nodes];
        }

        const nodeIds = new Set(nodes.map(n => n.id));
        const links = data.links.filter(l => 
            nodeIds.has(typeof l.source === 'object' ? (l.source as any).id : l.source) && 
            nodeIds.has(typeof l.target === 'object' ? (l.target as any).id : l.target)
        ).map(l => ({ ...l })); // Clone links for D3 mutation safety

        return { filteredNodes: nodes.map(n => ({...n})), filteredLinks: links };
    }, [data, scope]);

    // UI Zoom Handlers
    const handleZoomIn = () => {
        if (svgRef.current) {
             d3.select(svgRef.current).transition().call(d3.zoom<SVGSVGElement, unknown>().scaleBy, 1.3);
        }
    };
    const handleZoomOut = () => {
        if (svgRef.current) {
             d3.select(svgRef.current).transition().call(d3.zoom<SVGSVGElement, unknown>().scaleBy, 0.7);
        }
    };
    const handleReset = () => {
         if (svgRef.current && wrapperRef.current) {
            const width = wrapperRef.current.clientWidth;
            const height = wrapperRef.current.clientHeight;
             d3.select(svgRef.current).transition().duration(750).call(
                d3.zoom<SVGSVGElement, unknown>().transform, 
                d3.zoomIdentity.translate(width/2, height/2).scale(1).translate(-width/2, -height/2)
             );
        }
    };


    useEffect(() => {
        if (!filteredNodes.length || !svgRef.current || !wrapperRef.current) return;

        const width = wrapperRef.current.clientWidth;
        const height = wrapperRef.current.clientHeight;

        const svg = d3.select(svgRef.current);
        svg.selectAll("*").remove(); // Clear previous

        // --- Definitions for Filters (Glow) ---
        const defs = svg.append("defs");
        
        // Glow Filters
        ['blue', 'purple', 'yellow', 'orange', 'green'].forEach(color => {
            const filter = defs.append("filter").attr("id", `glow-${color}`);
            filter.append("feGaussianBlur").attr("stdDeviation", "2.5").attr("result", "coloredBlur");
            const feMerge = filter.append("feMerge");
            feMerge.append("feMergeNode").attr("in", "coloredBlur");
            feMerge.append("feMergeNode").attr("in", "SourceGraphic");
        });

        // --- Zoom Behavior ---
        const g = svg.append("g");
        
        const zoom = d3.zoom<SVGSVGElement, unknown>()
            .scaleExtent([0.1, 4])
            .on("zoom", (event) => {
                g.attr("transform", event.transform);
            });

        svg.call(zoom);

        // --- Simulation ---
        const simulation = d3.forceSimulation(filteredNodes as any)
            .force("link", d3.forceLink(filteredLinks).id((d: any) => d.id).distance(scope === 'macro' ? 120 : 60))
            .force("charge", d3.forceManyBody().strength(scope === 'macro' ? -500 : -200))
            .force("center", d3.forceCenter(width / 2, height / 2))
            .force("collide", d3.forceCollide().radius(d => (d as any).group === 1 ? 30 : 15));

        simulationRef.current = simulation;

        // Links
        const link = g.append("g")
            .attr("stroke", "#334155")
            .attr("stroke-opacity", 0.6)
            .selectAll("line")
            .data(filteredLinks)
            .join("line")
            .attr("stroke-width", (d) => Math.sqrt(d.value) * (scope === 'macro' ? 2 : 1.5));

        // Nodes Group
        const node = g.append("g")
            .attr("stroke", "#fff")
            .attr("stroke-width", 1.5)
            .selectAll("g")
            .data(filteredNodes)
            .join("g")
            .call(d3.drag<SVGGElement, any>()
                .on("start", dragstarted)
                .on("drag", dragged)
                .on("end", dragended));

        // Helper to determine node color/type
        const getNodeColor = (d: D3Node) => {
            if (d.group === 1) return { fill: "#06b6d4", glow: "blue" }; // Directory
            
            // Analyze extension for files
            const label = d.label.toLowerCase();
            if (label.endsWith('.ts') || label.endsWith('.tsx')) return { fill: "#3b82f6", glow: "blue" }; // TS
            if (label.endsWith('.js') || label.endsWith('.jsx')) return { fill: "#eab308", glow: "yellow" }; // JS
            if (label.endsWith('.json')) return { fill: "#f97316", glow: "orange" }; // JSON
            if (label.endsWith('.css') || label.endsWith('.scss')) return { fill: "#ec4899", glow: "purple" }; // CSS
            if (label.endsWith('.html')) return { fill: "#ef4444", glow: "green" }; // HTML (Using red/green)
            
            if (d.group === 2) return { fill: "#a855f7", glow: "purple" }; // Symbol
            return { fill: "#64748b", glow: "blue" }; // Default
        };

        // Node Circles
        node.append("circle")
            .attr("r", d => d.group === 1 ? (scope === 'macro' ? 16 : 12) : 6)
            .attr("fill", (d) => getNodeColor(d).fill)
            .attr("stroke", "#0f172a")
            .attr("stroke-width", 2)
            .style("filter", (d) => `url(#glow-${getNodeColor(d).glow})`);

        // Labels
        node.append("text")
            .attr("dx", d => d.group === 1 ? 20 : 10)
            .attr("dy", ".35em")
            .text(d => d.label)
            .style("fill", "#cbd5e1")
            .style("font-size", d => d.group === 1 ? (scope === 'macro' ? "14px" : "12px") : "8px")
            .style("font-family", "JetBrains Mono, monospace")
            .style("pointer-events", "none")
            .style("text-shadow", "0 0 3px #000");

        node.on("click", (event, d) => {
            event.stopPropagation();
            onNodeClick(d);
        });

        simulation.on("tick", () => {
            link
                .attr("x1", (d: any) => d.source.x)
                .attr("y1", (d: any) => d.source.y)
                .attr("x2", (d: any) => d.target.x)
                .attr("y2", (d: any) => d.target.y);

            node
                .attr("transform", (d: any) => `translate(${d.x},${d.y})`);
        });

        function dragstarted(event: any, d: any) {
            if (!event.active) simulation.alphaTarget(0.3).restart();
            d.fx = d.x;
            d.fy = d.y;
        }

        function dragged(event: any, d: any) {
            d.fx = event.x;
            d.fy = event.y;
        }

        function dragended(event: any, d: any) {
            if (!event.active) simulation.alphaTarget(0);
            d.fx = null;
            d.fy = null;
        }

    }, [filteredNodes, filteredLinks, onNodeClick, scope]);

    return (
        <div ref={wrapperRef} className="w-full h-full bg-[#050505] relative overflow-hidden group">
            <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-900/20 to-transparent"></div>
            <svg ref={svgRef} className="w-full h-full cursor-move"></svg>
            
            {/* Scope Control (Top Left) */}
            <div className="absolute top-4 left-4 flex bg-gray-900/80 backdrop-blur rounded-lg border border-gray-700 p-1 gap-1 z-10">
                <button 
                    onClick={() => setScope('macro')}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-bold uppercase transition-all ${
                        scope === 'macro' 
                        ? 'bg-cyan-600 text-white shadow' 
                        : 'text-gray-400 hover:text-white hover:bg-gray-800'
                    }`}
                >
                    <FilterIcon className="w-3 h-3" /> Structure
                </button>
                <button 
                    onClick={() => setScope('micro')}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-bold uppercase transition-all ${
                        scope === 'micro' 
                        ? 'bg-purple-600 text-white shadow' 
                        : 'text-gray-400 hover:text-white hover:bg-gray-800'
                    }`}
                >
                    <FilterIcon className="w-3 h-3" /> Detailed
                </button>
            </div>

            {/* Zoom Controls (Bottom Right) */}
            <div className="absolute bottom-6 right-6 flex flex-col gap-2 z-10">
                <button 
                    onClick={handleZoomIn}
                    className="p-2 bg-gray-800/80 backdrop-blur border border-gray-600 rounded-lg text-gray-300 hover:text-white hover:bg-gray-700 hover:border-cyan-500 transition-all shadow-lg"
                    title="Zoom In"
                >
                    <ZoomInIcon className="w-5 h-5" />
                </button>
                <button 
                    onClick={handleZoomOut}
                    className="p-2 bg-gray-800/80 backdrop-blur border border-gray-600 rounded-lg text-gray-300 hover:text-white hover:bg-gray-700 hover:border-cyan-500 transition-all shadow-lg"
                    title="Zoom Out"
                >
                    <ZoomOutIcon className="w-5 h-5" />
                </button>
                <button 
                    onClick={handleReset}
                    className="p-2 bg-gray-800/80 backdrop-blur border border-gray-600 rounded-lg text-gray-300 hover:text-white hover:bg-gray-700 hover:border-cyan-500 transition-all shadow-lg"
                    title="Reset View"
                >
                    <RefreshIcon className="w-5 h-5" />
                </button>
            </div>

            <div className="absolute bottom-4 left-4 text-[10px] text-slate-500 font-mono pointer-events-none opacity-50">
                INTERACTIVE GRAPH
            </div>
        </div>
    );
};

export default D3FlowChart;
