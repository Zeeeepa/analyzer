import React from 'react';
import { NpmUser } from '../types';
import { CubeIcon } from './icons';

interface UserCardProps {
    user: NpmUser;
    onSelect: (user: NpmUser) => void;
}

const UserCard: React.FC<UserCardProps> = ({ user, onSelect }) => {
    // Fallback for avatar
    const avatarUrl = user.avatar || `https://github.com/${user.username}.png`;

    return (
        <div 
            onClick={() => onSelect(user)}
            className="bg-gray-800 border border-gray-700 rounded-lg p-4 flex items-center gap-4 hover:bg-gray-700 hover:border-purple-500 cursor-pointer transition-all duration-200 group shadow-lg"
        >
            <div className="relative">
                <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-gray-600 group-hover:border-purple-400 transition-colors">
                    <img 
                        src={avatarUrl} 
                        alt={user.username} 
                        className="w-full h-full object-cover"
                        onError={(e) => { e.currentTarget.src = `https://ui-avatars.com/api/?name=${user.username}&background=random` }} 
                    />
                </div>
                <div className="absolute -bottom-1 -right-1 bg-gray-900 rounded-full p-0.5 border border-gray-600">
                    <div className="bg-green-500 w-3 h-3 rounded-full"></div>
                </div>
            </div>
            
            <div className="flex-1 overflow-hidden">
                <h3 className="font-bold text-gray-200 text-lg truncate group-hover:text-purple-300">{user.username}</h3>
                <div className="flex items-center gap-2 text-xs text-gray-500 mt-1">
                    <span className="flex items-center gap-1 bg-gray-900 px-2 py-0.5 rounded-full border border-gray-700">
                        <CubeIcon className="w-3 h-3 text-purple-400" />
                        <span className="font-mono font-bold text-gray-300">{user.packageCount}</span> Packages
                    </span>
                </div>
            </div>
            
            <div className="text-right hidden sm:block">
                <p className="text-[9px] text-gray-600 font-mono uppercase tracking-wider">UPDATED</p>
                <p className="text-[10px] text-gray-400">{new Date(user.lastUpdated).toLocaleDateString()}</p>
            </div>
        </div>
    );
};

export default UserCard;
