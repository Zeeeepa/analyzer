
import React, { useState, useEffect } from 'react';
import { useStudio } from '../contexts/StudioContext';
import { CloseIcon, SettingsIcon, DatabaseIcon } from './icons';

interface SettingsModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
    const { githubConfig, updateGithubConfig, isGithubConfigured } = useStudio();
    const [formData, setFormData] = useState(githubConfig);

    useEffect(() => {
        setFormData(githubConfig);
    }, [githubConfig, isOpen]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        updateGithubConfig(formData);
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 animate-in fade-in duration-200">
            <div className="bg-gray-800 border border-gray-700 rounded-lg shadow-2xl w-full max-w-md flex flex-col">
                <header className="flex items-center justify-between p-4 border-b border-gray-700 bg-gray-900/50">
                    <div className="flex items-center gap-2 text-gray-200">
                        <SettingsIcon className="w-5 h-5" />
                        <h2 className="text-xl font-bold">Configuration</h2>
                    </div>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-700">
                        <CloseIcon className="w-6 h-6 text-gray-400" />
                    </button>
                </header>

                <form onSubmit={handleSubmit}>
                    <main className="p-6 flex-1 space-y-5">
                        <div className={`p-3 rounded text-sm flex items-start gap-3 border ${isGithubConfigured ? 'bg-green-900/20 border-green-500/30 text-green-300' : 'bg-red-900/20 border-red-500/30 text-red-300'}`}>
                            <DatabaseIcon className="w-5 h-5 shrink-0 mt-0.5" />
                            <div>
                                <p className="font-bold mb-1">{isGithubConfigured ? 'System Configured' : 'Configuration Missing'}</p>
                                <p className="opacity-80">
                                    {isGithubConfigured 
                                     ? 'Your GitHub connection is active. Data can be synced.'
                                     : 'You must provide a Token, Username, and Repository to enable cloud sync.'}
                                </p>
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-bold text-gray-300 mb-1">Personal Access Token <span className="text-red-500">*</span></label>
                            <input 
                                type="password" 
                                name="token" 
                                value={formData.token} 
                                onChange={handleChange} 
                                placeholder="ghp_..."
                                className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-500 text-white font-mono text-sm" 
                            />
                             <p className="text-[10px] text-gray-500 mt-1">Requires <code>repo</code> scope.</p>
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-gray-300 mb-1">GitHub Username / Owner <span className="text-red-500">*</span></label>
                            <input 
                                type="text" 
                                name="owner" 
                                value={formData.owner} 
                                onChange={handleChange} 
                                placeholder="e.g. facebook"
                                className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-500 text-white" 
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-gray-300 mb-1">Storage Repository <span className="text-red-500">*</span></label>
                            <input 
                                type="text" 
                                name="repo" 
                                value={formData.repo} 
                                onChange={handleChange} 
                                placeholder="e.g. my-studio-data"
                                className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-500 text-white" 
                            />
                            <p className="text-xs text-gray-500 mt-1">
                                This repo must exist. The app will create/update <code>DATA/</code> folder inside it.
                            </p>
                        </div>
                    </main>

                    <footer className="p-4 border-t border-gray-700 flex justify-end gap-3 bg-gray-900/30">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-sm text-gray-300 hover:text-white hover:bg-gray-700 rounded transition-colors">
                            Cancel
                        </button>
                        <button type="submit" className="px-4 py-2 text-sm bg-blue-600 text-white rounded hover:bg-blue-500 transition-colors font-bold shadow-lg shadow-blue-900/20">
                            Save Configuration
                        </button>
                    </footer>
                </form>
            </div>
        </div>
    );
};

export default SettingsModal;
