import React from 'react';
import { UploadCloudIcon, DownloadCloudIcon } from './icons';
import Spinner from './Spinner';

interface DataSyncControlsProps {
    onLoad: () => void;
    onSave?: () => void;
    isLoading: boolean;
    isSyncing: boolean;
    isConfigured: boolean;
    loadLabel?: string;
    saveLabel?: string;
    // Fix: Add 'purple' to the available color options.
    saveColor?: 'red' | 'green' | 'blue' | 'yellow' | 'orange' | 'purple';
}

const colorClasses = {
    red: { bg: 'bg-red-600', hover: 'hover:bg-red-500', text: 'text-red-400' },
    green: { bg: 'bg-green-600', hover: 'hover:bg-green-500', text: 'text-green-400' },
    blue: { bg: 'bg-blue-600', hover: 'hover:bg-blue-500', text: 'text-blue-400' },
    yellow: { bg: 'bg-yellow-600', hover: 'hover:bg-yellow-500', text: 'text-yellow-400' },
    orange: { bg: 'bg-orange-600', hover: 'hover:bg-orange-500', text: 'text-orange-400' },
    // Fix: Add styles for the new 'purple' color option.
    purple: { bg: 'bg-purple-600', hover: 'hover:bg-purple-500', text: 'text-purple-400' },
};

const DataSyncControls: React.FC<DataSyncControlsProps> = ({
    onLoad,
    onSave,
    isLoading,
    isSyncing,
    isConfigured,
    loadLabel = 'Load',
    saveLabel = 'Save',
    saveColor = 'red',
}) => {
    const anyLoading = isLoading || isSyncing;
    const theme = colorClasses[saveColor];

    return (
        <div className="flex items-center gap-2">
            <button
                onClick={onLoad}
                disabled={!isConfigured || anyLoading}
                className="bg-gray-600 px-3 py-2 text-sm rounded-md hover:bg-gray-500 transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                title={isConfigured ? `Download data from GitHub` : "Configure GitHub in settings to enable"}
            >
                <DownloadCloudIcon className="w-5 h-5" /> {loadLabel}
            </button>
            {onSave && (
                <button
                    onClick={onSave}
                    disabled={!isConfigured || anyLoading}
                    className={`${theme.bg} ${theme.hover} px-3 py-2 text-sm rounded-md transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed`}
                    title={isConfigured ? `Upload data to GitHub` : "Configure GitHub in settings to enable"}
                >
                    <UploadCloudIcon className="w-5 h-5" /> {saveLabel}
                </button>
            )}
            {anyLoading && <Spinner className={`w-5 h-5 ${theme.text}`} />}
        </div>
    );
};

export default DataSyncControls;