

import React from 'react';
import { GitProject } from '../types';
import { Sparkles } from './icons';

interface ProjectCardProps {
  project: GitProject;
  onSelect: (project: GitProject) => void;
  onQuickScan?: (project: GitProject) => void;
  onShowDiff?: () => void;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project, onSelect, onQuickScan, onShowDiff }) => {
  const formatNumber = (num: number = 0) => {
    if (num === 0) return '0';
    if (num > 1000) return (num / 1000).toFixed(1) + 'k';
    return num.toLocaleString();
  };

  const avatarUrl = `https://github.com/${project.owner}.png`;
  
  const loc = project.totalLinesOfCode || 0;
  let statusColor = 'text-green-400';
  let borderColor = 'group-hover:border-green-500/50';
  let shadowColor = 'group-hover:shadow-[0_0_20px_rgba(74,222,128,0.2)]';
  let barColor = 'bg-green-500';

  if (loc > 100000) {
      statusColor = 'text-red-400';
      borderColor = 'group-hover:border-red-500/50';
      shadowColor = 'group-hover:shadow-[0_0_20px_rgba(248,113,113,0.2)]';
      barColor = 'bg-red-500';
  } else if (loc > 50000) {
      statusColor = 'text-orange-400';
      borderColor = 'group-hover:border-orange-500/50';
      shadowColor = 'group-hover:shadow-[0_0_20px_rgba(251,146,60,0.2)]';
      barColor = 'bg-orange-500';
  } else if (loc > 10000) {
      statusColor = 'text-blue-400';
      borderColor = 'group-hover:border-blue-500/50';
      shadowColor = 'group-hover:shadow-[0_0_20px_rgba(96,165,250,0.2)]';
      barColor = 'bg-blue-500';
  }

  // Ensure commitsBehind is treated as a number
  const commitsBehind = Number(project.commitsBehind || 0);

  return (
    <div
      onClick={() => onSelect(project)}
      className={`
        bg-[#0a0a0a] border border-gray-800/60 rounded-xl p-4 flex flex-col justify-between 
        cursor-pointer transition-all duration-300 ${borderColor} ${shadowColor}
        group relative overflow-hidden h-full min-h-[190px]
      `}
    >
      {/* Dynamic Glow Line */}
      <div className={`absolute top-0 left-0 w-full h-0.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 ${barColor}`} />

      {/* Holographic BG Effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-transparent via-transparent to-white/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
      
      {/* Commits Behind Bubble */}
      {commitsBehind > 0 && (
         <button
            onClick={(e) => { e.stopPropagation(); onShowDiff && onShowDiff(); }}
            className="absolute top-0 right-0 z-30 bg-red-600 hover:bg-red-500 text-white text-[10px] font-bold px-2 py-1 rounded-bl-lg shadow-lg shadow-red-900/50 transition-transform hover:scale-105 border-b border-l border-red-400/50"
            title={`${commitsBehind} commits behind origin. Click to view diff.`}
         >
            -{commitsBehind}
         </button>
      )}

      <div className="relative z-10">
        <div className="flex items-start gap-3 mb-3">
          <div className="relative">
             <img src={avatarUrl} alt="owner" className="w-10 h-10 rounded-lg bg-gray-900 border border-gray-700 object-cover" />
             <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-[#0a0a0a] ${barColor}`}></div>
          </div>
          <div className="flex-1 min-w-0 flex justify-between items-start">
             <div className="overflow-hidden pr-2">
                <h3 className={`text-md font-bold ${statusColor} truncate tracking-tight font-mono`}>{project.projectName}</h3>
                <p className="text-[10px] text-gray-500 uppercase tracking-widest">{project.owner}</p>
             </div>
             {onQuickScan && (
                 <button 
                    onClick={(e) => { e.stopPropagation(); onQuickScan(project); }}
                    className="text-gray-600 hover:text-yellow-400 p-1 hover:bg-yellow-400/10 rounded transition-colors"
                    title="Quick Deep Scan"
                 >
                    <Sparkles className="w-4 h-4" />
                 </button>
             )}
          </div>
        </div>
        
        <p className="text-xs text-gray-400 line-clamp-2 h-8 leading-relaxed font-light">
          {project.description || <span className="text-gray-600 italic">No description available.</span>}
        </p>
      </div>

      <div className="relative z-10 mt-4">
          <div className="grid grid-cols-4 gap-px bg-gray-800/50 rounded-lg overflow-hidden border border-gray-800">
            <div className="bg-[#0f0f0f] p-2 text-center group/stat hover:bg-[#151515] transition-colors">
                <div className="text-[9px] text-gray-600 uppercase tracking-wider mb-0.5">FILES</div>
                <div className="text-xs font-mono font-bold text-gray-300 group-hover/stat:text-white">{formatNumber(project.fileCount)}</div>
            </div>
            <div className="bg-[#0f0f0f] p-2 text-center group/stat hover:bg-[#151515] transition-colors">
                <div className="text-[9px] text-gray-600 uppercase tracking-wider mb-0.5">LOC</div>
                <div className={`text-xs font-mono font-bold ${statusColor} group-hover/stat:text-white`}>{formatNumber(project.totalLinesOfCode)}</div>
            </div>
             <div className="bg-[#0f0f0f] p-2 text-center group/stat hover:bg-[#151515] transition-colors">
                <div className="text-[9px] text-gray-600 uppercase tracking-wider mb-0.5" title="Lines Committed Per Month">LCPM</div>
                <div className={`text-xs font-mono font-bold ${project.lcpm ? 'text-blue-300' : 'text-gray-500'} group-hover/stat:text-white`}>
                    {formatNumber(project.lcpm || 0)}
                </div>
            </div>
             <div className="bg-[#0f0f0f] p-2 text-center group/stat hover:bg-[#151515] transition-colors">
                <div className="text-[9px] text-gray-600 uppercase tracking-wider mb-0.5">LANG</div>
                <div className="text-xs font-mono font-bold text-gray-300 group-hover/stat:text-white truncate">{project.language || 'N/A'}</div>
            </div>
          </div>
          
          <div className="flex justify-between items-center mt-3 text-[10px] text-gray-600 font-mono">
             <span>LAST UPDATED: <span className="text-gray-400 font-bold">{project.updatedAt ? new Date(project.updatedAt).toLocaleDateString() : 'N/A'}</span></span>
             {project.mermaidGraph && (
                 <span className="flex items-center gap-1 text-green-500 animate-pulse font-bold">
                     <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span> GRAPH READY
                 </span>
             )}
          </div>
      </div>
    </div>
  );
};

export default ProjectCard;
