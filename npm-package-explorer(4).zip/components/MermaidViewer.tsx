
import React, { useRef, useEffect, useState } from 'react';
import * as d3 from 'd3';
import { ZoomInIcon, ZoomOutIcon, RefreshIcon, CodeBracketIcon } from './icons';

declare global {
  interface Window {
    mermaid: any;
  }
}

interface MermaidViewerProps {
    graphDefinition: string;
}

const MermaidViewer: React.FC<MermaidViewerProps> = ({ graphDefinition }) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const svgRef = useRef<HTMLDivElement>(null);
    const [renderError, setRenderError] = useState<boolean>(false);
    const [zoomTransform, setZoomTransform] = useState<d3.ZoomTransform>(d3.zoomIdentity);

    useEffect(() => {
        const renderGraph = async () => {
            if (!graphDefinition || !svgRef.current) return;
            
            try {
                setRenderError(false);
                if (window.mermaid) {
                    window.mermaid.initialize({ 
                        startOnLoad: false, 
                        theme: 'dark', 
                        securityLevel: 'loose',
                        flowchart: { curve: 'basis' } 
                    });
                    
                    const id = `mermaid-${Date.now()}`;
                    const { svg } = await window.mermaid.render(id, graphDefinition);
                    
                    if (svgRef.current) {
                        svgRef.current.innerHTML = svg;
                        
                        // Setup Zoom after render
                        if (containerRef.current) {
                            const container = d3.select(containerRef.current);
                            const innerSvg = d3.select(svgRef.current).select('svg');
                            
                            // Ensure the inner SVG allows overflow so we can pan it
                            innerSvg.attr('width', '100%').attr('height', '100%');

                            const zoom = d3.zoom<HTMLDivElement, unknown>()
                                .scaleExtent([0.1, 5])
                                .on('zoom', (event) => {
                                    setZoomTransform(event.transform);
                                    if(svgRef.current) {
                                        d3.select(svgRef.current).style('transform', `translate(${event.transform.x}px, ${event.transform.y}px) scale(${event.transform.k})`);
                                        d3.select(svgRef.current).style('transform-origin', '0 0');
                                    }
                                });

                            container.call(zoom).on("dblclick.zoom", null);
                            
                            // Initial Center
                            container.transition().duration(750).call(
                                zoom.transform, 
                                d3.zoomIdentity.translate(containerRef.current.clientWidth / 2 - 200, 50).scale(0.8)
                            );
                        }
                    }
                }
            } catch (e) {
                console.error("Mermaid Render Error", e);
                setRenderError(true);
            }
        };

        renderGraph();
    }, [graphDefinition]);

    const handleZoomIn = () => {
        if (containerRef.current) {
            const container = d3.select(containerRef.current);
            container.transition().call(d3.zoom<HTMLDivElement, unknown>().scaleBy, 1.2);
        }
    };

    const handleZoomOut = () => {
        if (containerRef.current) {
            const container = d3.select(containerRef.current);
            container.transition().call(d3.zoom<HTMLDivElement, unknown>().scaleBy, 0.8);
        }
    };

    const handleReset = () => {
        if (containerRef.current) {
            const container = d3.select(containerRef.current);
            container.transition().duration(750).call(
                 d3.zoom<HTMLDivElement, unknown>().transform, 
                 d3.zoomIdentity.translate(containerRef.current.clientWidth / 2 - 200, 50).scale(0.8)
            );
        }
    };

    if (renderError) {
        return (
            <div className="flex flex-col items-center justify-center h-full text-gray-500">
                <CodeBracketIcon className="w-16 h-16 opacity-20 mb-4" />
                <p className="text-sm">Logic Flow Render Error</p>
                <p className="text-xs mt-1">The graph structure is too complex or invalid.</p>
            </div>
        );
    }

    return (
        <div className="relative w-full h-full bg-[#050505] overflow-hidden group">
            <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-900/10 to-transparent"></div>
            
            <div 
                ref={containerRef} 
                className="w-full h-full cursor-move overflow-hidden"
            >
                <div ref={svgRef} className="w-full h-full" />
            </div>

            {/* Controls HUD */}
            <div className="absolute bottom-6 right-6 flex flex-col gap-2 z-10">
                <button 
                    onClick={handleZoomIn}
                    className="p-2 bg-gray-800/80 backdrop-blur border border-gray-600 rounded-lg text-gray-300 hover:text-white hover:bg-gray-700 hover:border-cyan-500 transition-all shadow-lg"
                    title="Zoom In"
                >
                    <ZoomInIcon className="w-5 h-5" />
                </button>
                <button 
                    onClick={handleZoomOut}
                    className="p-2 bg-gray-800/80 backdrop-blur border border-gray-600 rounded-lg text-gray-300 hover:text-white hover:bg-gray-700 hover:border-cyan-500 transition-all shadow-lg"
                    title="Zoom Out"
                >
                    <ZoomOutIcon className="w-5 h-5" />
                </button>
                <button 
                    onClick={handleReset}
                    className="p-2 bg-gray-800/80 backdrop-blur border border-gray-600 rounded-lg text-gray-300 hover:text-white hover:bg-gray-700 hover:border-cyan-500 transition-all shadow-lg"
                    title="Reset View"
                >
                    <RefreshIcon className="w-5 h-5" />
                </button>
            </div>
            
             <div className="absolute top-4 right-4 bg-black/60 px-3 py-1 rounded text-[10px] text-gray-500 font-mono pointer-events-none border border-white/5">
                LOGIC FLOW
             </div>
        </div>
    );
};

export default MermaidViewer;
