
// DEPRECATED: Logic consolidated into StudioLayout global ProjectExplorer
export default function GitProjectDetailView() { return null; }
