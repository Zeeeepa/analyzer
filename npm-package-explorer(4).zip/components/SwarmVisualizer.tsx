
import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as d3 from 'd3';
import { SwarmOrchestrator } from '../services/swarmService';
import { AgentNode, SwarmState } from '../types';

interface SwarmVisualizerProps {
    orchestrator: SwarmOrchestrator;
}

interface VisualNode extends d3.SimulationNodeDatum {
    id: string;
    agent: AgentNode;
    r: number;
    color: string;
    x?: number;
    y?: number;
    vx?: number;
    vy?: number;
    fx?: number | null;
    fy?: number | null;
}

interface VisualLink extends d3.SimulationLinkDatum<VisualNode> {
    source: string | VisualNode;
    target: string | VisualNode;
}

const SwarmVisualizer: React.FC<SwarmVisualizerProps> = ({ orchestrator }) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [state, setState] = useState<SwarmState | null>(null);
    const simulationRef = useRef<d3.Simulation<VisualNode, VisualLink> | null>(null);
    
    // Track nodes to preserve positions between renders
    const nodesRef = useRef<Map<string, VisualNode>>(new Map());

    useEffect(() => {
        const unsub = orchestrator.subscribe(setState);
        return unsub;
    }, [orchestrator]);

    // Logic to update simulation based on state
    useEffect(() => {
        if (!state || !canvasRef.current) return;
        
        const canvas = canvasRef.current;
        const width = canvas.width;
        const height = canvas.height;

        // 1. Map Agents to Nodes
        const currentNodes: VisualNode[] = Object.values(state.agents).map((agent: AgentNode) => {
            const existing = nodesRef.current.get(agent.id);
            
            let color = '#64748b'; // Idle: Slate
            let r = 5;

            switch(agent.status) {
                case 'thinking': color = '#eab308'; r = 7; break; // Yellow
                case 'working': color = '#3b82f6'; r = 7; break; // Blue
                case 'completed': color = '#22c55e'; r = 5; break; // Green
                case 'failed': color = '#ef4444'; r = 5; break; // Red
            }
            if (agent.role === 'overseer') { r = 12; color = '#f472b6'; } // Pink Root

            const node: VisualNode = {
                id: agent.id,
                agent,
                r,
                color,
                x: existing ? existing.x : width / 2 + (Math.random() - 0.5) * 50,
                y: existing ? existing.y : height / 2 + (Math.random() - 0.5) * 50,
                vx: existing ? existing.vx : 0,
                vy: existing ? existing.vy : 0
            };
            return node;
        });

        // Update Ref
        currentNodes.forEach(n => nodesRef.current.set(n.id, n));

        // 2. Map Hierarchy to Links
        const links: VisualLink[] = [];
        Object.values(state.agents).forEach((agent: AgentNode) => {
            if (agent.parentId && state.agents[agent.parentId]) {
                links.push({ source: agent.parentId, target: agent.id });
            }
        });

        // 3. Setup/Update Simulation
        if (!simulationRef.current) {
            simulationRef.current = d3.forceSimulation<VisualNode, VisualLink>(currentNodes)
                .force("link", d3.forceLink<VisualNode, VisualLink>(links).id(d => d.id).distance(60))
                .force("charge", d3.forceManyBody().strength(-200))
                .force("center", d3.forceCenter(width / 2, height / 2))
                .force("collide", d3.forceCollide<VisualNode>().radius(d => d.r + 5));
        } else {
            simulationRef.current.nodes(currentNodes);
            (simulationRef.current.force("link") as d3.ForceLink<VisualNode, VisualLink>).links(links);
            simulationRef.current.alpha(0.3).restart();
        }

    }, [state]);

    // Render Loop
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas || !simulationRef.current) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let animationFrameId: number;

        const render = () => {
            if (!canvas || !ctx || !simulationRef.current) return;
            
            const width = canvas.width;
            const height = canvas.height;

            ctx.clearRect(0, 0, width, height);
            
            // Draw Links
            ctx.strokeStyle = 'rgba(148, 163, 184, 0.2)'; // Slate-400 low opacity
            ctx.lineWidth = 1;
            
            const links = (simulationRef.current.force("link") as d3.ForceLink<VisualNode, VisualLink>).links();
            const nodes = simulationRef.current.nodes();

            links.forEach(link => {
                const source = link.source as VisualNode;
                const target = link.target as VisualNode;
                if (source.x != null && source.y != null && target.x != null && target.y != null) {
                    ctx.beginPath();
                    ctx.moveTo(source.x, source.y);
                    ctx.lineTo(target.x, target.y);
                    ctx.stroke();

                    // Active Data Flow Particle
                    if (target.agent.status === 'working') {
                        const time = Date.now() / 300;
                        const t = time % 1; 
                        const px = source.x + (target.x - source.x) * t;
                        const py = source.y + (target.y - source.y) * t;
                        
                        ctx.fillStyle = '#60a5fa'; // Blue glow
                        ctx.beginPath();
                        ctx.arc(px, py, 2, 0, 2 * Math.PI);
                        ctx.fill();
                    }
                }
            });

            // Draw Nodes
            nodes.forEach(node => {
                if (node.x != null && node.y != null) {
                    // Glow for active agents
                    if (node.agent.status === 'thinking' || node.agent.status === 'working') {
                        const pulse = Math.sin(Date.now() / 200) * 3 + 3;
                        ctx.shadowBlur = 10 + pulse;
                        ctx.shadowColor = node.color;
                    } else {
                        ctx.shadowBlur = 0;
                    }

                    ctx.fillStyle = node.color;
                    ctx.beginPath();
                    ctx.arc(node.x, node.y, node.r, 0, 2 * Math.PI);
                    ctx.fill();

                    // Reset Shadow
                    ctx.shadowBlur = 0;

                    // Labels
                    ctx.fillStyle = 'rgba(255,255,255, 0.7)';
                    ctx.font = '10px monospace';
                    ctx.textAlign = 'center';
                    ctx.fillText(node.agent.role.toUpperCase(), node.x, node.y + node.r + 12);
                }
            });

            animationFrameId = requestAnimationFrame(render);
        };

        render();

        return () => cancelAnimationFrame(animationFrameId);
    }, []);

    // Handle Resize
    useEffect(() => {
        const handleResize = () => {
            if (canvasRef.current && canvasRef.current.parentElement) {
                canvasRef.current.width = canvasRef.current.parentElement.clientWidth;
                canvasRef.current.height = canvasRef.current.parentElement.clientHeight;
                simulationRef.current?.force("center", d3.forceCenter(canvasRef.current.width / 2, canvasRef.current.height / 2));
                simulationRef.current?.alpha(0.3).restart();
            }
        };
        window.addEventListener('resize', handleResize);
        handleResize();
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    if (!state) return null;

    return (
        <div className="relative w-full h-full bg-[#020617] overflow-hidden">
             {/* Background Grid */}
             <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 pointer-events-none"></div>
             <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle at center, rgba(30, 41, 59, 0.2) 0%, rgba(2, 6, 23, 1) 70%)'}}></div>

             {/* HUD */}
             <div className="absolute top-6 left-6 z-10 flex gap-4 pointer-events-none">
                 <div className="bg-black/40 backdrop-blur-md border border-white/10 p-4 rounded-xl shadow-xl">
                     <div className="text-[10px] uppercase text-gray-500 font-bold tracking-widest mb-1">Active Agents</div>
                     <div className="text-3xl font-mono text-green-400">{Object.keys(state.agents).length}</div>
                 </div>
                 <div className="bg-black/40 backdrop-blur-md border border-white/10 p-4 rounded-xl shadow-xl">
                     <div className="text-[10px] uppercase text-gray-500 font-bold tracking-widest mb-1">Root Status</div>
                     <div className={`text-3xl font-mono ${state.agents['overseer']?.status === 'idle' ? 'text-gray-500' : 'text-blue-400 animate-pulse'}`}>
                         {state.agents['overseer']?.status.toUpperCase() || 'OFFLINE'}
                     </div>
                 </div>
             </div>

             <div className="absolute bottom-6 left-6 z-10 pointer-events-none max-w-md">
                 <div className="text-[10px] uppercase text-gray-500 font-bold tracking-widest mb-2">Live Logs</div>
                 <div className="bg-black/60 backdrop-blur-md border border-white/10 rounded-lg p-3 font-mono text-[10px] text-green-400/80 h-32 overflow-hidden flex flex-col justify-end mask-gradient-top">
                    {Object.values(state.agents)
                        .flatMap((a: AgentNode) => a.logs.map(l => ({ id: a.id, name: a.name, msg: l })))
                        .slice(-6)
                        .map((log, i) => (
                            <div key={i} className="truncate">
                                <span className="text-blue-400">[{log.name}]</span> {log.msg}
                            </div>
                        ))
                    }
                 </div>
             </div>

             <canvas ref={canvasRef} className="block w-full h-full" />
        </div>
    );
};

export default SwarmVisualizer;
