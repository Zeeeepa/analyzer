
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { summarizeText } from '../services/geminiService';
import Spinner from './Spinner';
import { GeminiIcon, JsIcon, TsIcon, CssIcon, HtmlIcon, JsonIcon, MdIcon, FileIcon } from './icons';
import MonacoEditor from './MonacoEditor';

interface FileContentProps {
  fileName: string;
  content: string;
}

const getFileIcon = (filename: string) => {
    const ext = filename.split('.').pop()?.toLowerCase();
    const props = { className: "w-5 h-5" };
    switch (ext) {
        case 'js': return <JsIcon {...props} />;
        case 'ts': case 'tsx': return <TsIcon {...props} />;
        case 'css': case 'scss': case 'less': return <CssIcon {...props} />;
        case 'html': return <HtmlIcon {...props} />;
        case 'json': return <JsonIcon {...props} />;
        case 'md': return <MdIcon {...props} />;
        default: return <FileIcon {...props} />;
    }
};

const FileContent: React.FC<FileContentProps> = ({ fileName, content }) => {
  const [summary, setSummary] = useState<string | null>(null);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Force layout update when content changes
  const [key, setKey] = useState(0);
  useEffect(() => {
      setKey(prev => prev + 1);
  }, [content, fileName]);

  useEffect(() => {
      // Small timeout to ensure container has size before editor renders
      const timer = setTimeout(() => {
          window.dispatchEvent(new Event('resize')); 
      }, 100);
      return () => clearTimeout(timer);
  }, [key]);

  const handleSummarize = async () => {
    setIsSummarizing(true);
    setSummary(null);
    const context = fileName.toLowerCase().includes('readme.md') ? 'readme' : 'code';
    const result = await summarizeText(content, context);
    setSummary(result);
    setIsSummarizing(false);
  };
  
  const fileSizeKB = (new TextEncoder().encode(content).length / 1024).toFixed(2);

  const handleCopy = () => {
      navigator.clipboard.writeText(content);
  };

  return (
    <div className="flex-1 flex flex-col bg-[#1e1e1e] overflow-hidden h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 bg-[#252526] border-b border-[#3e3e42] shrink-0 shadow-sm z-10">
        <div className="flex items-center gap-3">
            {getFileIcon(fileName)}
            <div>
                <h3 className="font-mono text-sm font-bold text-gray-200">{fileName}</h3>
                <div className="flex items-center gap-3 text-[10px] text-gray-500 uppercase tracking-wide">
                    <span className="w-1 h-1 rounded-full bg-gray-600"></span>
                    <span>{fileSizeKB} KB</span>
                </div>
            </div>
        </div>
        <div className="flex items-center gap-2">
            <button
                onClick={handleCopy}
                className="text-xs bg-[#333333] hover:bg-[#444444] text-gray-300 px-3 py-1.5 rounded transition-colors border border-[#3e3e42]"
            >
                Copy
            </button>
            <button
              onClick={handleSummarize}
              disabled={isSummarizing}
              className="flex items-center gap-2 px-3 py-1.5 bg-purple-900/30 text-purple-300 border border-purple-500/50 text-xs rounded hover:bg-purple-900/50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm font-medium"
            >
              <GeminiIcon className="w-3 h-3" />
              {isSummarizing ? 'Analyzing...' : 'Explain'}
            </button>
        </div>
      </div>

      {/* Content Area - Using Monaco */}
      <div className="flex-1 overflow-hidden relative" ref={containerRef}>
         {/* Key forces re-mount on file change ensuring clean state */}
         <MonacoEditor 
            key={key}
            value={content} 
            fileName={fileName}
            readOnly={true}
         />
      </div>

      {(isSummarizing || summary) && (
        <div className="border-t border-purple-900/50 p-4 bg-gray-900/95 backdrop-blur max-h-64 overflow-y-auto shrink-0 shadow-inner relative z-20">
          <div className="flex items-center gap-2 mb-2 sticky top-0 bg-gray-900/95 pb-2 border-b border-purple-500/20">
             <GeminiIcon className="w-5 h-5 text-purple-400"/>
             <h4 className="text-sm font-bold text-purple-300">AI Analysis</h4>
          </div>
          {isSummarizing && <Spinner text="Analyzing code context..." />}
          {summary && <div className="text-sm text-gray-300 leading-relaxed whitespace-pre-wrap">{summary}</div>}
        </div>
      )}
    </div>
  );
};

export default FileContent;
