
import React, { useState } from 'react';
import { NpmUser, EnrichedPackageInfo } from '../../types';
import { CloseIcon, CubeIcon, SearchIcon, HeartIcon } from '../icons';

interface UserDetailModalProps {
    isOpen: boolean;
    onClose: () => void;
    user: NpmUser | null;
    onSelectPackage: (pkg: EnrichedPackageInfo) => void;
    onToggleFavorite: (packageName: string) => void;
    trackedPackages: EnrichedPackageInfo[];
}

const UserDetailModal: React.FC<UserDetailModalProps> = ({ isOpen, onClose, user, onSelectPackage, onToggleFavorite, trackedPackages }) => {
    const [search, setSearch] = useState('');

    if (!isOpen || !user) return null;

    const filteredPackages = user.packages.filter(p => 
        p.name?.toLowerCase().includes(search.toLowerCase()) || 
        p.description?.toLowerCase().includes(search.toLowerCase())
    );

    const isFavorite = (name: string) => trackedPackages.some(p => p.name === name);

    return (
        <div className="fixed inset-0 bg-black/85 flex items-center justify-center z-[60] p-4 animate-in fade-in">
            <div className="bg-[#0f172a] border border-gray-700 rounded-xl shadow-2xl w-full max-w-4xl flex flex-col h-[85vh] overflow-hidden">
                {/* Header */}
                <header className="p-5 border-b border-gray-700 bg-gray-900/50 flex justify-between items-start shrink-0">
                    <div className="flex items-center gap-4">
                        <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-purple-500 shadow-lg shadow-purple-500/20">
                            <img 
                                src={user.avatar || `https://github.com/${user.username}.png`} 
                                alt={user.username} 
                                className="w-full h-full object-cover"
                                onError={(e) => { e.currentTarget.src = `https://ui-avatars.com/api/?name=${user.username}&background=random` }}
                            />
                        </div>
                        <div>
                            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                                {user.username}
                                <span className="text-xs bg-purple-900/50 text-purple-300 px-2 py-0.5 rounded border border-purple-500/30">MAINTAINER</span>
                            </h2>
                            <p className="text-sm text-gray-400 mt-1 flex items-center gap-4">
                                <span>{user.email || 'No email provided'}</span>
                                <span className="text-gray-600">•</span>
                                <span className="text-white font-mono">{user.packageCount} Packages</span>
                            </p>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-700 transition-colors text-gray-400 hover:text-white">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </header>

                {/* Toolbar */}
                <div className="p-4 border-b border-gray-800 bg-[#0b1221] flex items-center gap-4 shrink-0">
                    <div className="relative flex-1">
                        <SearchIcon className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />
                        <input 
                            type="text" 
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                            placeholder="Filter packages..." 
                            className="w-full bg-gray-900 border border-gray-700 rounded-lg pl-9 pr-4 py-2 text-sm text-white focus:outline-none focus:border-purple-500 transition-colors"
                        />
                    </div>
                </div>

                {/* Package List */}
                <div className="flex-1 overflow-y-auto custom-scrollbar p-4 bg-[#050505]">
                    {filteredPackages.length === 0 ? (
                        <div className="flex flex-col items-center justify-center h-full text-gray-500 opacity-60">
                            <CubeIcon className="w-12 h-12 mb-2" />
                            <p>No packages found matching your filter.</p>
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {filteredPackages.map((pkg, idx) => (
                                <div 
                                    key={idx}
                                    className="bg-[#0b1221] border border-gray-800 p-4 rounded-lg hover:bg-gray-800 hover:border-purple-500/50 transition-all group flex flex-col justify-between h-32 relative"
                                >
                                    <div 
                                        className="cursor-pointer"
                                        onClick={() => onSelectPackage(pkg as EnrichedPackageInfo)}
                                    >
                                        <div className="flex justify-between items-start mb-1 pr-6">
                                            <h3 className="font-bold text-purple-300 group-hover:text-purple-200 truncate text-sm">{pkg.name}</h3>
                                            <span className="text-[10px] bg-gray-900 text-gray-500 px-1.5 py-0.5 rounded font-mono">v{pkg.version}</span>
                                        </div>
                                        <p className="text-xs text-gray-500 line-clamp-2 leading-relaxed">{pkg.description || 'No description.'}</p>
                                    </div>
                                    
                                    <div className="flex items-center justify-between pt-3 border-t border-gray-800/50 mt-2">
                                        <div className="flex items-center gap-3">
                                            <span className="text-[10px] text-gray-600 font-mono">
                                                {new Date(pkg.lastPublished || '').toLocaleDateString()}
                                            </span>
                                            {pkg.repositoryUrl && (
                                                <span className="text-[10px] text-blue-900/80 bg-blue-900/10 px-1.5 rounded truncate max-w-[150px]">
                                                    git
                                                </span>
                                            )}
                                        </div>
                                        <button 
                                            onClick={(e) => { e.stopPropagation(); if (pkg.name) onToggleFavorite(pkg.name); }}
                                            className={`transition-colors p-1 rounded-full ${isFavorite(pkg.name!) ? 'text-red-400 hover:text-red-300 bg-red-900/10' : 'text-gray-600 hover:text-red-400'}`}
                                            title={isFavorite(pkg.name!) ? "Remove from tracking" : "Add to tracking"}
                                        >
                                            <HeartIcon className="w-4 h-4" solid={isFavorite(pkg.name!)} />
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default UserDetailModal;
