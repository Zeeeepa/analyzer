import React, { useState, useEffect } from 'react';
import { KnowledgeItem } from '../../types';
import { CloseIcon } from '../icons';

interface KnowledgeItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (item: KnowledgeItem) => void;
  initialData: KnowledgeItem | null;
}

const KnowledgeItemModal: React.FC<KnowledgeItemModalProps> = ({ isOpen, onClose, onSave, initialData }) => {
  const [item, setItem] = useState<Partial<KnowledgeItem>>(initialData || {});

  useEffect(() => {
    setItem(initialData || {
      title: '',
      type: 'url',
      source: '',
      tags: [],
      content: '',
    });
  }, [initialData, isOpen]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    if (name === 'tags') {
      setItem(prev => ({ ...prev, [name]: value.split(';').map(t => t.trim()) }));
    } else {
      setItem(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (item.title && item.source) {
      onSave({
        ...item,
        createdAt: item.createdAt || new Date().toISOString(),
      } as KnowledgeItem);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 border border-gray-700 rounded-lg shadow-2xl w-full max-w-lg flex flex-col">
        <header className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-xl font-bold text-blue-400">{initialData ? 'Edit Item' : 'Add New Item'}</h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-700">
            <CloseIcon className="w-6 h-6 text-gray-400" />
          </button>
        </header>

        <form onSubmit={handleSubmit}>
          <main className="p-6 flex-1 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Title *</label>
              <input type="text" name="title" value={item.title || ''} onChange={handleChange} required className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Type *</label>
                <select name="type" value={item.type || 'url'} onChange={handleChange} className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="url">URL</option>
                    <option value="file">File</option>
                    <option value="note">Note</option>
                </select>
              </div>
               <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Source *</label>
                <input type="text" name="source" value={item.source || ''} onChange={handleChange} required className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-500" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Tags (semicolon-separated)</label>
              <input type="text" name="tags" value={Array.isArray(item.tags) ? item.tags.join(';') : ''} onChange={handleChange} className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
             <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Content / Summary</label>
              <textarea name="content" value={item.content || ''} onChange={handleChange} rows={4} className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" />
            </div>
          </main>

          <footer className="p-4 border-t border-gray-700 flex justify-end gap-4">
            <button type="button" onClick={onClose} className="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-500">Cancel</button>
            <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-500">Save Item</button>
          </footer>
        </form>
      </div>
    </div>
  );
};

export default KnowledgeItemModal;
