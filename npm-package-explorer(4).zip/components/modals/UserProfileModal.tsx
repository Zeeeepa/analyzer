
import React, { useState, useEffect } from 'react';
import { useStudio } from '../../contexts/StudioContext';
import { listUserRepos, listUserStarred } from '../../services/githubService';
import { GithubRepo } from '../../types';
import { CloseIcon, CodeBracketIcon, StarIcon, GitHubIcon } from '../icons';
import Spinner from '../Spinner';

interface UserProfileModalProps {
    isOpen: boolean;
    onClose: () => void;
    username: string;
}

const UserProfileModal: React.FC<UserProfileModalProps> = ({ isOpen, onClose, username }) => {
    const { githubConfig, isGithubConfigured } = useStudio();
    const [activeTab, setActiveTab] = useState<'repos' | 'stars'>('repos');
    const [repos, setRepos] = useState<GithubRepo[]>([]);
    const [starred, setStarred] = useState<GithubRepo[]>([]);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        if (!isOpen || !username || !isGithubConfigured) return;
        
        const fetchData = async () => {
            setIsLoading(true);
            try {
                if (activeTab === 'repos') {
                    const data = await listUserRepos(githubConfig.token, username);
                    setRepos(data);
                } else {
                    const data = await listUserStarred(githubConfig.token, username);
                    setStarred(data);
                }
            } catch (e) {
                console.error("Failed to fetch user data", e);
            } finally {
                setIsLoading(false);
            }
        };

        fetchData();
    }, [isOpen, username, activeTab, isGithubConfigured, githubConfig.token]);

    if (!isOpen) return null;

    const currentList = activeTab === 'repos' ? repos : starred;

    return (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100] p-4 animate-in fade-in">
            <div className="bg-[#0f172a] border border-gray-700 rounded-xl shadow-2xl w-full max-w-4xl flex flex-col h-[80vh] overflow-hidden">
                {/* Header */}
                <header className="p-4 border-b border-gray-700 bg-gray-900/50 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                         <div className="w-10 h-10 rounded-full bg-gray-800 border border-gray-600 flex items-center justify-center overflow-hidden">
                             <img 
                                src={`https://github.com/${username}.png`} 
                                alt={username} 
                                className="w-full h-full object-cover"
                                onError={(e) => (e.currentTarget.style.display = 'none')}
                             />
                         </div>
                         <div>
                             <h2 className="text-lg font-bold text-white flex items-center gap-2">
                                 {username}
                                 <a 
                                    href={`https://github.com/${username}`} 
                                    target="_blank" 
                                    rel="noreferrer" 
                                    className="text-gray-500 hover:text-white"
                                >
                                    <GitHubIcon className="w-4 h-4" />
                                </a>
                             </h2>
                             <div className="flex gap-4 mt-1">
                                 <button 
                                    onClick={() => setActiveTab('repos')}
                                    className={`text-xs font-mono uppercase tracking-wider hover:text-white transition-colors ${activeTab === 'repos' ? 'text-cyan-400 font-bold' : 'text-gray-500'}`}
                                 >
                                     Repositories
                                 </button>
                                 <button 
                                    onClick={() => setActiveTab('stars')}
                                    className={`text-xs font-mono uppercase tracking-wider hover:text-white transition-colors ${activeTab === 'stars' ? 'text-yellow-400 font-bold' : 'text-gray-500'}`}
                                 >
                                     Starred
                                 </button>
                             </div>
                         </div>
                    </div>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-700 transition-colors">
                        <CloseIcon className="w-6 h-6 text-gray-400" />
                    </button>
                </header>

                {/* Content */}
                <main className="flex-1 overflow-y-auto custom-scrollbar p-4 bg-[#050505]">
                    {isLoading ? (
                        <div className="flex justify-center items-center h-full">
                            <Spinner text={`Fetching ${activeTab}...`} />
                        </div>
                    ) : currentList.length === 0 ? (
                        <div className="flex flex-col items-center justify-center h-full text-gray-500 opacity-50">
                             <GitHubIcon className="w-12 h-12 mb-2" />
                             <p>No {activeTab} found.</p>
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {currentList.map(repo => (
                                <a 
                                    key={repo.id} 
                                    href={repo.html_url}
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="bg-[#0b1221] border border-gray-800 p-3 rounded-lg hover:border-cyan-500/50 hover:bg-[#111827] transition-all group"
                                >
                                    <div className="flex justify-between items-start mb-1">
                                        <h3 className="font-bold text-cyan-300 group-hover:text-cyan-200 truncate pr-2">{repo.name}</h3>
                                        {activeTab === 'stars' && (
                                            <div className="flex items-center gap-1 text-[10px] text-yellow-500">
                                                <StarIcon className="w-3 h-3" />
                                                {repo.stargazers_count}
                                            </div>
                                        )}
                                    </div>
                                    <p className="text-xs text-gray-500 line-clamp-2 h-8">{repo.description || 'No description'}</p>
                                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-800/50">
                                        <span className="text-[10px] text-gray-600 font-mono">{repo.language || 'Code'}</span>
                                        <span className="text-[10px] text-gray-600 font-mono">Last updated: {new Date(repo.updated_at).toLocaleDateString()}</span>
                                    </div>
                                </a>
                            ))}
                        </div>
                    )}
                </main>
            </div>
        </div>
    );
};

export default UserProfileModal;
