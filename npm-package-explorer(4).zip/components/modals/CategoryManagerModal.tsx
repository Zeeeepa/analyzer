
import React, { useState, useMemo } from 'react';
import { RepoCategoryAssignment } from '../../types';
import { CloseIcon } from '../icons';

interface CategoryManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  allCategories: string[];
  assignments: RepoCategoryAssignment[];
  onUpdate: (updatedAssignments: RepoCategoryAssignment[]) => void;
}

const CategoryManagerModal: React.FC<CategoryManagerModalProps> = ({ isOpen, onClose, allCategories, assignments, onUpdate }) => {
  const [editingCategory, setEditingCategory] = useState<{ oldName: string; newName: string } | null>(null);

  const handleRenameStart = (cat: string) => {
    setEditingCategory({ oldName: cat, newName: cat });
  };
  
  const handleRenameSave = () => {
    if (!editingCategory || editingCategory.newName.trim() === '' || editingCategory.newName === editingCategory.oldName) {
        setEditingCategory(null);
        return;
    }
    const { oldName, newName } = editingCategory;
    const updatedAssignments = assignments.map(assign => {
        // Ensure categories is an array
        const cats = Array.isArray(assign.categories) ? assign.categories : [];
        if (cats.includes(oldName)) {
            const newCats = cats.map(c => c === oldName ? newName : c);
            return { ...assign, categories: [...new Set(newCats)] }; // Use Set to unique
        }
        return assign;
    });
    onUpdate(updatedAssignments);
    setEditingCategory(null);
  };

  const handleDelete = (catToDelete: string) => {
      if (window.confirm(`Are you sure you want to delete the category "${catToDelete}" from all repositories?`)) {
          const updatedAssignments = assignments.map(assign => {
               const cats = Array.isArray(assign.categories) ? assign.categories : [];
               if (cats.includes(catToDelete)) {
                   const newCats = cats.filter(c => c !== catToDelete);
                   return { ...assign, categories: newCats };
               }
               return assign;
          }).filter(a => a.categories.length > 0); // Remove assignments that become empty
          onUpdate(updatedAssignments);
      }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 border border-gray-700 rounded-lg shadow-2xl w-full max-w-lg flex flex-col">
        <header className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-xl font-bold text-purple-400">Manage Categories</h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-700">
            <CloseIcon className="w-6 h-6 text-gray-400" />
          </button>
        </header>

        <main className="p-6 flex-1 max-h-[60vh] overflow-y-auto">
          <p className="text-sm text-gray-400 mb-4">Rename or delete categories. Changes will apply to all repositories using them.</p>
          <ul className="space-y-2">
            {allCategories.map(cat => (
              <li key={cat} className="flex items-center justify-between bg-gray-900/50 p-2 rounded">
                {editingCategory?.oldName === cat ? (
                    <input
                        type="text"
                        value={editingCategory.newName}
                        onChange={(e) => setEditingCategory({ ...editingCategory, newName: e.target.value })}
                        className="bg-gray-700 border border-gray-500 rounded px-2 py-1 text-sm flex-grow"
                        autoFocus
                    />
                ) : (
                    <span className="text-purple-300">{cat}</span>
                )}
                
                <div className="flex items-center gap-2">
                    {editingCategory?.oldName === cat ? (
                        <>
                            <button onClick={handleRenameSave} className="text-xs text-green-400 hover:text-green-300">Save</button>
                            <button onClick={() => setEditingCategory(null)} className="text-xs text-gray-400 hover:text-white">Cancel</button>
                        </>
                    ) : (
                        <>
                            <button onClick={() => handleRenameStart(cat)} className="text-xs text-yellow-400 hover:text-yellow-300">Rename</button>
                            <button onClick={() => handleDelete(cat)} className="text-xs text-red-400 hover:text-red-300">Delete</button>
                        </>
                    )}
                </div>
              </li>
            ))}
          </ul>
        </main>
        
        <footer className="p-4 border-t border-gray-700 flex justify-end gap-4">
            <button type="button" onClick={onClose} className="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-500">Close</button>
        </footer>
      </div>
    </div>
  );
};

export default CategoryManagerModal;
