import React, { useState, useEffect } from 'react';
import { ApiDefinition } from '../../types';
import { CloseIcon } from '../icons';

interface ApiDefModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (apiDef: ApiDefinition) => void;
  initialData: ApiDefinition | null;
}

const ApiDefModal: React.FC<ApiDefModalProps> = ({ isOpen, onClose, onSave, initialData }) => {
  const [apiDef, setApiDef] = useState<Partial<ApiDefinition>>(initialData || {});

  useEffect(() => {
    setApiDef(initialData || {
      name: '',
      method: 'GET',
      endpointUrl: '',
      description: '',
      tags: [],
    });
  }, [initialData, isOpen]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
     if (name === 'tags') {
      setApiDef(prev => ({ ...prev, [name]: value.split(';').map(t => t.trim()) }));
    } else {
      setApiDef(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (apiDef.name && apiDef.endpointUrl) {
      onSave(apiDef as ApiDefinition);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 border border-gray-700 rounded-lg shadow-2xl w-full max-w-lg flex flex-col">
        <header className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-xl font-bold text-yellow-400">{initialData ? 'Edit API Definition' : 'Add New API Definition'}</h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-700">
            <CloseIcon className="w-6 h-6 text-gray-400" />
          </button>
        </header>

        <form onSubmit={handleSubmit}>
          <main className="p-6 flex-1 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Name *</label>
              <input type="text" name="name" value={apiDef.name || ''} onChange={handleChange} required className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-yellow-500" />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="col-span-1">
                <label className="block text-sm font-medium text-gray-300 mb-1">Method *</label>
                <select name="method" value={apiDef.method || 'GET'} onChange={handleChange} className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-yellow-500">
                    <option>GET</option>
                    <option>POST</option>
                    <option>PUT</option>
                    <option>DELETE</option>
                    <option>PATCH</option>
                </select>
              </div>
              <div className="col-span-2">
                <label className="block text-sm font-medium text-gray-300 mb-1">Endpoint URL *</label>
                <input type="text" name="endpointUrl" value={apiDef.endpointUrl || ''} onChange={handleChange} required className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-yellow-500" />
              </div>
            </div>
             <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Tags (semicolon-separated)</label>
              <input type="text" name="tags" value={Array.isArray(apiDef.tags) ? apiDef.tags.join(';') : ''} onChange={handleChange} className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-yellow-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Description</label>
              <textarea name="description" value={apiDef.description || ''} onChange={handleChange} rows={3} className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-yellow-500 resize-none" />
            </div>
          </main>

          <footer className="p-4 border-t border-gray-700 flex justify-end gap-4">
            <button type="button" onClick={onClose} className="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-500">Cancel</button>
            <button type="submit" className="bg-yellow-600 text-white px-4 py-2 rounded-md hover:bg-yellow-500">Save Definition</button>
          </footer>
        </form>
      </div>
    </div>
  );
};

export default ApiDefModal;
