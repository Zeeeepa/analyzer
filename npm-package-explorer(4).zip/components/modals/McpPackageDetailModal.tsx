import React, { useMemo } from 'react';
import { McpPackage } from '../../types';
import { CloseIcon, CubeIcon } from '../icons';

interface McpPackageDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  pkg: McpPackage | null;
}

const McpPackageDetailModal: React.FC<McpPackageDetailModalProps> = ({ isOpen, onClose, pkg }) => {
  
  const variables = useMemo(() => {
    if (!pkg || !pkg.configuration) return [];
    // Regex to find ${VAR_NAME}
    const regex = /\$\{([^}]+)\}/g;
    const matches = Array.from(pkg.configuration.matchAll(regex)).map(m => m[1]);
    return [...new Set(matches)]; // Unique variables
  }, [pkg]);

  if (!isOpen || !pkg) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 border border-gray-700 rounded-lg shadow-2xl w-full max-w-4xl flex flex-col max-h-[90vh]">
        <header className="flex items-center justify-between p-4 border-b border-gray-700">
            <div className="flex items-center gap-3">
                <CubeIcon className="w-6 h-6 text-blue-400" />
                <div>
                    <h2 className="text-xl font-bold text-blue-400">{pkg.name}</h2>
                    <p className="text-xs text-gray-400">Source: {pkg.source}</p>
                </div>
            </div>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-700">
            <CloseIcon className="w-6 h-6 text-gray-400" />
          </button>
        </header>

        <main className="p-6 flex-1 overflow-y-auto space-y-6">
           {pkg.description && (
               <div>
                   <h3 className="text-sm font-bold text-gray-300 mb-1">Description</h3>
                   <p className="text-gray-400 text-sm">{pkg.description}</p>
               </div>
           )}

           {variables.length > 0 && (
               <div className="bg-blue-900/20 border border-blue-800 p-4 rounded-lg">
                   <h3 className="text-sm font-bold text-blue-300 mb-2">Required Environment Variables</h3>
                   <div className="flex flex-wrap gap-2">
                       {variables.map(v => (
                           <span key={v} className="px-2 py-1 bg-blue-900 text-blue-200 text-xs font-mono rounded border border-blue-700">
                               {v}
                           </span>
                       ))}
                   </div>
               </div>
           )}

           <div>
               <h3 className="text-sm font-bold text-gray-300 mb-2">Configuration (JSON)</h3>
               <div className="bg-gray-900 rounded-lg p-4 border border-gray-700 overflow-x-auto">
                   <pre className="text-xs font-mono text-green-300 whitespace-pre-wrap">
                       {pkg.configuration ? 
                        JSON.stringify(JSON.parse(pkg.configuration), null, 2) 
                        : '// No configuration provided'
                       }
                   </pre>
               </div>
           </div>
        </main>
        
        <footer className="p-4 border-t border-gray-700 flex justify-end">
            <button onClick={onClose} className="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-500">Close</button>
        </footer>
      </div>
    </div>
  );
};

export default McpPackageDetailModal;