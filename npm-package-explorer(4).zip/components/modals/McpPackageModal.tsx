
import React, { useState, useEffect } from 'react';
import { McpPackage, McpSource } from '../../types';
import { CloseIcon } from '../icons';

interface McpPackageModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (pkg: McpPackage) => void;
  initialData: McpPackage | null;
  sources: McpSource[];
}

const McpPackageModal: React.FC<McpPackageModalProps> = ({ isOpen, onClose, onSave, initialData, sources }) => {
  const [pkg, setPkg] = useState<Partial<McpPackage>>(initialData || {});
  const [jsonError, setJsonError] = useState<string | null>(null);

  useEffect(() => {
    setPkg(initialData || { 
        name: '', 
        source: sources.length > 0 ? sources[0].name : '', 
        description: '',
        configuration: '',
        tags: []
    });
    setJsonError(null);
  }, [initialData, isOpen, sources]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    if (name === 'tags') {
        setPkg(prev => ({ ...prev, [name]: value.split(';').map(t => t.trim()) }));
    } else {
        setPkg(prev => ({ ...prev, [name]: value }));
    }
    
    if (name === 'configuration') {
        if (!value.trim()) {
            setJsonError(null);
            return;
        }
        try {
            JSON.parse(value);
            setJsonError(null);
        } catch (e) {
            setJsonError('Invalid JSON format');
        }
    }
  };

  const handlePrettify = () => {
      if (!pkg.configuration) return;
      try {
          const parsed = JSON.parse(pkg.configuration);
          const prettified = JSON.stringify(parsed, null, 2);
          setPkg(prev => ({ ...prev, configuration: prettified }));
          setJsonError(null);
      } catch (e) {
          setJsonError("Cannot prettify: Invalid JSON");
      }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (jsonError) return;
    
    if (pkg.name && pkg.source) {
      onSave(pkg as McpPackage);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 border border-gray-700 rounded-lg shadow-2xl w-full max-w-lg flex flex-col max-h-[90vh]">
        <header className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-xl font-bold text-orange-400">{initialData ? 'Edit Package' : 'Add New Package'}</h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-700">
            <CloseIcon className="w-6 h-6 text-gray-400" />
          </button>
        </header>

        <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden">
          <main className="p-6 flex-1 overflow-y-auto space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Name *</label>
              <input type="text" name="name" value={pkg.name || ''} onChange={handleChange} required className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-orange-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Source *</label>
              <select name="source" value={pkg.source || ''} onChange={handleChange} required className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-orange-500">
                <option value="" disabled>Select a source</option>
                {sources.map(s => <option key={s.name} value={s.name}>{s.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Tags (semicolon-separated)</label>
              <input type="text" name="tags" value={Array.isArray(pkg.tags) ? pkg.tags.join(';') : ''} onChange={handleChange} className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-orange-500" />
            </div>
             <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Description</label>
              <textarea name="description" value={pkg.description || ''} onChange={handleChange} rows={2} className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-orange-500 resize-none" />
            </div>
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-sm font-medium text-gray-300">Configuration (JSON)</label>
                <button 
                    type="button" 
                    onClick={handlePrettify}
                    className="text-xs text-orange-400 hover:text-orange-300"
                >
                    Prettify
                </button>
              </div>
              <textarea 
                name="configuration" 
                value={pkg.configuration || ''} 
                onChange={handleChange} 
                rows={6} 
                className={`w-full bg-gray-900 border rounded-md p-2 focus:outline-none focus:ring-2 font-mono text-xs ${jsonError ? 'border-red-500 focus:ring-red-500' : 'border-gray-600 focus:ring-orange-500'}`}
                placeholder='{"apiKey": "${API_KEY}"}'
              />
              {jsonError && <p className="text-red-400 text-xs mt-1">{jsonError}</p>}
            </div>
          </main>

          <footer className="p-4 border-t border-gray-700 flex justify-end gap-4 shrink-0">
            <button type="button" onClick={onClose} className="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-500">Cancel</button>
            <button type="submit" disabled={!!jsonError} className="bg-orange-600 text-white px-4 py-2 rounded-md hover:bg-orange-500 disabled:bg-gray-500 disabled:cursor-not-allowed">Save Package</button>
          </footer>
        </form>
      </div>
    </div>
  );
};

export default McpPackageModal;
