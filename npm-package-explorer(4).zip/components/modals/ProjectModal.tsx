import React, { useState, useEffect } from 'react';
import { GitProject } from '../../types';
import { CloseIcon } from '../icons';

interface ProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (project: GitProject) => void;
  initialData: GitProject | null;
}

const ProjectModal: React.FC<ProjectModalProps> = ({ isOpen, onClose, onSave, initialData }) => {
  const [project, setProject] = useState<Partial<GitProject>>(initialData || {});

  useEffect(() => {
    setProject(initialData || {
      projectName: '',
      description: '',
      originUrl: '',
      owner: '',
    });
  }, [initialData, isOpen]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setProject(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (project.projectName && project.originUrl && project.owner) {
      onSave(project as GitProject);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 border border-gray-700 rounded-lg shadow-2xl w-full max-w-lg flex flex-col">
        <header className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-xl font-bold text-green-400">{initialData ? 'Edit Project' : 'Add New Project'}</h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-700">
            <CloseIcon className="w-6 h-6 text-gray-400" />
          </button>
        </header>

        <form onSubmit={handleSubmit}>
          <main className="p-6 flex-1 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Project Name *</label>
              <input type="text" name="projectName" value={project.projectName || ''} onChange={handleChange} required className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-green-500" />
            </div>
             <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Owner *</label>
              <input type="text" name="owner" value={project.owner || ''} onChange={handleChange} required className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-green-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Origin URL *</label>
              <input type="url" name="originUrl" value={project.originUrl || ''} onChange={handleChange} required className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-green-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Description</label>
              <textarea name="description" value={project.description || ''} onChange={handleChange} rows={3} className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-green-500 resize-none" />
            </div>
          </main>

          <footer className="p-4 border-t border-gray-700 flex justify-end gap-4">
            <button type="button" onClick={onClose} className="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-500">Cancel</button>
            <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-500">Save Project</button>
          </footer>
        </form>
      </div>
    </div>
  );
};

export default ProjectModal;
