
import React, { useState } from 'react';
import { McpSource, McpServer } from '../../types';
import { CloseIcon, GlobeIcon, GeminiIcon, ServerStackIcon, PlusCircleIcon, CodeBracketIcon } from '../icons';
import Spinner from '../Spinner';
import { analyzeMcpSourceContent } from '../../services/geminiService';

interface McpSourceDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  source: McpSource | null;
  onAddServer: (server: McpServer) => void;
}

const McpSourceDetailModal: React.FC<McpSourceDetailModalProps> = ({ isOpen, onClose, source, onAddServer }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [foundServers, setFoundServers] = useState<McpServer[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [rawContent, setRawContent] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'analysis' | 'raw'>('analysis');

  const handleAnalyze = async () => {
    if (!source?.url) return;
    setIsAnalyzing(true);
    setError(null);
    setFoundServers([]);
    setRawContent(null);

    try {
        // 1. Try to fetch client-side
        const res = await fetch(source.url);
        if (!res.ok) throw new Error(`Failed to fetch URL: ${res.statusText}`);
        const text = await res.text();
        setRawContent(text);
        
        // 2. Send to Gemini
        const results = await analyzeMcpSourceContent(text);
        if (results.length === 0) {
            setError("No MCP servers found in the page content.");
        } else {
            // Transform generic objects to McpServer type
            const servers: McpServer[] = results.map(r => ({
                name: r.name || 'Unknown Server',
                url: r.url,
                description: r.description,
                type: r.type === 'stdio' ? 'stdio' : 'sse'
            }));
            setFoundServers(servers);
        }

    } catch (err) {
        console.error(err);
        let msg = "Failed to analyze source.";
        if (err instanceof TypeError && err.message.includes('Failed to fetch')) {
            msg = "CORS Error: Cannot fetch this URL directly from the browser. The server does not allow cross-origin requests.";
        } else if (err instanceof Error) {
            msg = err.message;
        }
        setError(msg);
    } finally {
        setIsAnalyzing(false);
    }
  };

  if (!isOpen || !source) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 border border-gray-700 rounded-lg shadow-2xl w-full max-w-4xl flex flex-col max-h-[90vh]">
        <header className="flex items-center justify-between p-4 border-b border-gray-700">
            <div className="flex items-center gap-3">
                <GlobeIcon className="w-6 h-6 text-orange-400" />
                <div>
                    <h2 className="text-xl font-bold text-orange-400">{source.name}</h2>
                    <a href={source.url} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-400 hover:underline">{source.url}</a>
                </div>
            </div>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-700">
            <CloseIcon className="w-6 h-6 text-gray-400" />
          </button>
        </header>
        
        <div className="border-b border-gray-700 px-4 pt-2 flex gap-4">
            <button 
                onClick={() => setActiveTab('analysis')}
                className={`pb-2 px-2 text-sm border-b-2 transition-colors ${activeTab === 'analysis' ? 'border-orange-400 text-orange-400' : 'border-transparent text-gray-400 hover:text-gray-200'}`}
            >
                AI Analysis
            </button>
            <button 
                onClick={() => setActiveTab('raw')}
                className={`pb-2 px-2 text-sm border-b-2 transition-colors ${activeTab === 'raw' ? 'border-orange-400 text-orange-400' : 'border-transparent text-gray-400 hover:text-gray-200'}`}
            >
                Raw Content
            </button>
        </div>

        <main className="p-6 flex-1 overflow-y-auto space-y-6">
           
           {activeTab === 'analysis' && (
               <div className="bg-gray-900/50 rounded-lg p-4 border border-gray-700">
                    <div className="flex items-center justify-between mb-4">
                        <h3 className="text-md font-bold text-gray-200 flex items-center gap-2">
                            <GeminiIcon className="w-5 h-5 text-purple-400" />
                            AI Server Scanner
                        </h3>
                        <button 
                            onClick={handleAnalyze} 
                            disabled={isAnalyzing}
                            className="px-4 py-2 bg-purple-600 text-white text-sm rounded hover:bg-purple-500 disabled:bg-gray-600 disabled:cursor-not-allowed flex items-center gap-2"
                        >
                            {isAnalyzing ? <Spinner className="w-4 h-4 text-white" /> : 'Scan for Servers'}
                        </button>
                    </div>
                    <p className="text-sm text-gray-400 mb-2">
                        Use Gemini to analyze the source page content and automatically extract MCP server configurations.
                    </p>

                    {error && (
                        <div className="mt-4 p-3 bg-red-900/30 border border-red-800 rounded text-red-300 text-sm">
                            {error}
                        </div>
                    )}

                    {foundServers.length > 0 && (
                        <div className="mt-4 space-y-2">
                            <p className="text-green-400 text-sm font-semibold">Found {foundServers.length} servers:</p>
                            {foundServers.map((server, idx) => (
                                <div key={idx} className="flex items-center justify-between bg-gray-800 p-3 rounded border border-gray-600">
                                    <div className="flex items-start gap-3">
                                        <ServerStackIcon className="w-5 h-5 text-gray-400 mt-1" />
                                        <div>
                                            <p className="font-bold text-gray-200">{server.name}</p>
                                            <p className="text-xs text-gray-400 font-mono">{server.url}</p>
                                            <p className="text-xs text-gray-500">{server.description}</p>
                                        </div>
                                    </div>
                                    <button 
                                        onClick={() => {
                                            onAddServer(server);
                                            alert(`Added ${server.name} to servers list!`);
                                        }}
                                        className="flex items-center gap-1 text-xs bg-green-600 hover:bg-green-500 text-white px-3 py-1.5 rounded transition-colors"
                                    >
                                        <PlusCircleIcon className="w-4 h-4" /> Add
                                    </button>
                                </div>
                            ))}
                        </div>
                    )}
               </div>
           )}

           {activeTab === 'raw' && (
               <div className="bg-gray-900 rounded-lg border border-gray-700 flex flex-col h-full min-h-[300px]">
                   <div className="flex items-center justify-between p-2 border-b border-gray-700 bg-gray-800">
                       <h3 className="text-xs font-mono text-gray-400">Raw Source Content</h3>
                       {!rawContent && !isAnalyzing && (
                            <button onClick={handleAnalyze} className="text-xs text-orange-400 hover:underline">
                                Fetch Content
                            </button>
                       )}
                   </div>
                   <div className="flex-1 overflow-auto p-4">
                        {isAnalyzing ? (
                            <div className="flex justify-center pt-8"><Spinner text="Fetching content..." /></div>
                        ) : rawContent ? (
                            <pre className="text-xs font-mono text-gray-300 whitespace-pre-wrap break-all">
                                {rawContent}
                            </pre>
                        ) : (
                            <div className="text-center text-gray-500 py-8">
                                Content not loaded. Click "Scan for Servers" or "Fetch Content" to retrieve.
                            </div>
                        )}
                   </div>
               </div>
           )}
        </main>
        
        <footer className="p-4 border-t border-gray-700 flex justify-end">
            <button onClick={onClose} className="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-500">Close</button>
        </footer>
      </div>
    </div>
  );
};

export default McpSourceDetailModal;
