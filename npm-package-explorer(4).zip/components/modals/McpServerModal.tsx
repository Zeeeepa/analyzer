import React, { useState, useEffect } from 'react';
import { McpServer } from '../../types';
import { CloseIcon } from '../icons';

interface McpServerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (server: McpServer) => void;
  initialData: McpServer | null;
}

const McpServerModal: React.FC<McpServerModalProps> = ({ isOpen, onClose, onSave, initialData }) => {
  const [server, setServer] = useState<Partial<McpServer>>(initialData || {});

  useEffect(() => {
    setServer(initialData || { name: '', url: '', type: 'sse', description: '' });
  }, [initialData, isOpen]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setServer(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (server.name && server.url) {
      onSave(server as McpServer);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 border border-gray-700 rounded-lg shadow-2xl w-full max-w-lg flex flex-col">
        <header className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-xl font-bold text-purple-400">{initialData ? 'Edit Server' : 'Add New Server'}</h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-700">
            <CloseIcon className="w-6 h-6 text-gray-400" />
          </button>
        </header>

        <form onSubmit={handleSubmit}>
          <main className="p-6 flex-1 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Name *</label>
              <input type="text" name="name" value={server.name || ''} onChange={handleChange} required className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500" />
            </div>
            <div className="grid grid-cols-3 gap-4">
                <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-300 mb-1">URL *</label>
                    <input type="url" name="url" value={server.url || ''} onChange={handleChange} required className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Type</label>
                     <select name="type" value={server.type || 'sse'} onChange={handleChange} className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500">
                        <option value="sse">SSE</option>
                        <option value="stdio">Stdio</option>
                     </select>
                </div>
            </div>
             <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Description</label>
              <textarea name="description" value={server.description || ''} onChange={handleChange} rows={3} className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none" />
            </div>
          </main>

          <footer className="p-4 border-t border-gray-700 flex justify-end gap-4">
            <button type="button" onClick={onClose} className="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-500">Cancel</button>
            <button type="submit" className="bg-purple-600 text-white px-4 py-2 rounded-md hover:bg-purple-500">Save Server</button>
          </footer>
        </form>
      </div>
    </div>
  );
};

export default McpServerModal;