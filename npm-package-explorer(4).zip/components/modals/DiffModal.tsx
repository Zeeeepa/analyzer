
import React, { useState, useEffect } from 'react';
import { CloseIcon, CodeBracketIcon } from '../icons';
import { DiffResult, FileDiff } from '../../types';

interface DiffModalProps {
  isOpen: boolean;
  onClose: () => void;
  diffData: DiffResult | null;
  upstreamName: string;
}

const DiffModal: React.FC<DiffModalProps> = ({ isOpen, onClose, diffData, upstreamName }) => {
  const [selectedFile, setSelectedFile] = useState<FileDiff | null>(null);

  useEffect(() => {
      if (isOpen && diffData?.files?.length > 0) {
          setSelectedFile(diffData.files[0]);
      }
  }, [isOpen, diffData]);

  if (!isOpen || !diffData) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 animate-in fade-in">
      <div className="bg-[#0f172a] border border-gray-700 rounded-xl shadow-2xl w-full max-w-5xl flex flex-col h-[85vh]">
        {/* Header */}
        <header className="flex items-center justify-between p-4 border-b border-gray-700 bg-gray-900/50">
          <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                  Wait! You are behind origin.
              </h2>
              <p className="text-sm text-gray-400 mt-1">
                  Your repository is missing <strong className="text-white">{diffData.ahead_by} commits</strong> from <span className="font-mono text-cyan-400">{upstreamName}</span>.
              </p>
          </div>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-700 transition-colors">
            <CloseIcon className="w-6 h-6 text-gray-400" />
          </button>
        </header>

        <main className="flex-1 flex overflow-hidden">
            {/* Sidebar: File List */}
            <div className="w-1/3 border-r border-gray-700 flex flex-col bg-[#0b1221]">
                <div className="p-3 border-b border-gray-800 bg-gray-900/30">
                    <div className="flex justify-between text-xs font-mono text-gray-500 mb-1">
                        <span>CHANGED FILES</span>
                        <span>{diffData.files.length}</span>
                    </div>
                    <div className="flex gap-2 text-[10px] font-bold">
                        <span className="text-green-400">+{diffData.files.reduce((acc, f) => acc + f.additions, 0)} Lines</span>
                        <span className="text-red-400">-{diffData.files.reduce((acc, f) => acc + f.deletions, 0)} Lines</span>
                    </div>
                </div>
                <div className="flex-1 overflow-y-auto custom-scrollbar">
                    {diffData.files.map((file) => (
                        <button
                            key={file.sha}
                            onClick={() => setSelectedFile(file)}
                            className={`w-full text-left px-4 py-3 border-b border-gray-800/50 hover:bg-white/5 transition-colors flex items-center gap-3 ${selectedFile?.sha === file.sha ? 'bg-blue-900/20 border-l-2 border-l-blue-500' : 'border-l-2 border-l-transparent'}`}
                        >
                            <CodeBracketIcon className={`w-4 h-4 shrink-0 ${file.status === 'added' ? 'text-green-500' : file.status === 'removed' ? 'text-red-500' : 'text-yellow-500'}`} />
                            <div className="overflow-hidden">
                                <p className="text-xs text-gray-300 truncate font-mono">{file.filename}</p>
                                <p className="text-[10px] text-gray-500 mt-0.5">
                                    <span className="text-green-500/80">+{file.additions}</span> <span className="text-red-500/80">-{file.deletions}</span>
                                </p>
                            </div>
                        </button>
                    ))}
                </div>
            </div>

            {/* Main: Diff Viewer */}
            <div className="flex-1 flex flex-col bg-[#050505] overflow-hidden">
                {selectedFile ? (
                    <>
                        <div className="p-3 border-b border-gray-800 bg-[#0a0a0a] flex justify-between items-center">
                            <span className="text-xs font-mono text-blue-300 truncate">{selectedFile.filename}</span>
                            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-gray-800 text-gray-400 border border-gray-700">
                                {selectedFile.status}
                            </span>
                        </div>
                        <div className="flex-1 overflow-auto custom-scrollbar p-4">
                            <pre className="font-mono text-xs leading-5 whitespace-pre-wrap">
                                {selectedFile.patch ? (
                                    selectedFile.patch.split('\n').map((line, i) => {
                                        let color = "text-gray-400";
                                        let bg = "transparent";
                                        if (line.startsWith('+')) { color = "text-green-400"; bg = "bg-green-900/20"; }
                                        else if (line.startsWith('-')) { color = "text-red-400"; bg = "bg-red-900/20"; }
                                        else if (line.startsWith('@')) { color = "text-purple-400"; }
                                        
                                        return (
                                            <div key={i} className={`${bg} w-full`}>
                                                <span className={`${color} inline-block select-text`}>{line}</span>
                                            </div>
                                        );
                                    })
                                ) : (
                                    <span className="text-gray-500 italic">Binary file or too large to show diff.</span>
                                )}
                            </pre>
                        </div>
                    </>
                ) : (
                    <div className="flex flex-col items-center justify-center h-full text-gray-600">
                        <CodeBracketIcon className="w-16 h-16 opacity-20 mb-4" />
                        <p className="text-sm">Select a file to view changes</p>
                    </div>
                )}
            </div>
        </main>
        
        <footer className="p-4 border-t border-gray-700 bg-gray-900/50 flex justify-end">
             <button onClick={onClose} className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-2 rounded-lg font-bold text-sm transition-all shadow-lg shadow-blue-900/20">
                 Acknowledge
             </button>
        </footer>
      </div>
    </div>
  );
};

export default DiffModal;
