import React, { useState, useEffect } from 'react';
import { McpSource } from '../../types';
import { CloseIcon } from '../icons';

interface McpSourceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (source: McpSource) => void;
  initialData: McpSource | null;
}

const McpSourceModal: React.FC<McpSourceModalProps> = ({ isOpen, onClose, onSave, initialData }) => {
  const [source, setSource] = useState<Partial<McpSource>>(initialData || {});

  useEffect(() => {
    setSource(initialData || { name: '', url: '' });
  }, [initialData, isOpen]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setSource(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (source.name && source.url) {
      onSave(source as McpSource);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 border border-gray-700 rounded-lg shadow-2xl w-full max-w-lg flex flex-col">
        <header className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-xl font-bold text-orange-400">{initialData ? 'Edit Source' : 'Add New Source'}</h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-700">
            <CloseIcon className="w-6 h-6 text-gray-400" />
          </button>
        </header>

        <form onSubmit={handleSubmit}>
          <main className="p-6 flex-1 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Name *</label>
              <input type="text" name="name" value={source.name || ''} onChange={handleChange} required className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-orange-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">URL *</label>
              <input type="url" name="url" value={source.url || ''} onChange={handleChange} required className="w-full bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-orange-500" />
            </div>
          </main>

          <footer className="p-4 border-t border-gray-700 flex justify-end gap-4">
            <button type="button" onClick={onClose} className="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-500">Cancel</button>
            <button type="submit" className="bg-orange-600 text-white px-4 py-2 rounded-md hover:bg-orange-500">Save Source</button>
          </footer>
        </form>
      </div>
    </div>
  );
};

export default McpSourceModal;
