// DEPRECATED
export default function StorageView() { return null; }