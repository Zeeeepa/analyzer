// DEPRECATED
export default function FavouritesView() { return null; }