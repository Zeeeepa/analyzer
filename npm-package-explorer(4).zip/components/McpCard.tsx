import React from 'react';
import { GlobeIcon, CubeIcon, ServerStackIcon, CloseIcon, SettingsIcon } from './icons';

interface McpCardProps {
    item: { id?: string; name: string; [key: string]: any };
    type: 'source' | 'package' | 'server';
    onSelect: () => void;
    onEdit?: (e: React.MouseEvent) => void;
    onDelete?: (e: React.MouseEvent) => void;
}

const McpCard: React.FC<McpCardProps> = ({ item, type, onSelect, onEdit, onDelete }) => {
    const config = {
        source: {
            icon: GlobeIcon,
            color: 'text-orange-400',
            border: 'hover:border-orange-500',
            bg: 'hover:bg-gray-700',
            label: 'Source'
        },
        package: {
            icon: CubeIcon,
            color: 'text-blue-400',
            border: 'hover:border-blue-500',
            bg: 'hover:bg-gray-700',
            label: 'Package'
        },
        server: {
            icon: ServerStackIcon,
            color: 'text-purple-400',
            border: 'hover:border-purple-500',
            bg: 'hover:bg-gray-700',
            label: 'Server'
        }
    };

    const theme = config[type];
    const Icon = theme.icon;

    return (
        <div
            onClick={onSelect}
            className={`bg-gray-800 border border-gray-700 rounded-lg p-3 flex flex-col justify-between ${theme.bg} ${theme.border} cursor-pointer transition-all duration-200 shadow-lg h-full group relative`}
        >
            <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                {onEdit && (
                    <button onClick={(e) => { e.stopPropagation(); onEdit(e); }} className="p-1 hover:bg-gray-600 rounded text-yellow-400" title="Edit">
                        <SettingsIcon className="w-4 h-4" />
                    </button>
                )}
                {onDelete && (
                    <button onClick={(e) => { e.stopPropagation(); onDelete(e); }} className="p-1 hover:bg-gray-600 rounded text-red-400" title="Delete">
                        <CloseIcon className="w-4 h-4" />
                    </button>
                )}
            </div>

            <div>
                <div className="flex items-start gap-3 mb-2">
                    <div className={`p-2 rounded-full bg-gray-900/50 ${theme.color}`}>
                        <Icon className="w-6 h-6" />
                    </div>
                    <div className="flex-1 overflow-hidden pr-6">
                        <h3 className={`text-md font-bold ${theme.color} truncate`} title={item.name}>{item.name}</h3>
                        <p className="text-xs text-gray-500 truncate">{item.url || item.source || 'Local'}</p>
                    </div>
                </div>
                <p className="text-sm text-gray-400 h-10 overflow-hidden text-ellipsis my-1 display-webkit-box line-clamp-2">
                    {item.description || <span className="text-gray-600 italic">No description provided.</span>}
                </p>
            </div>

            <div className="flex justify-between items-center pt-2 border-t border-gray-700/50 mt-2">
                 <span className={`text-xs font-mono px-2 py-0.5 rounded bg-gray-900/50 text-gray-400`}>
                    {type.toUpperCase()}
                </span>
                 {item.type && (
                    <span className="text-xs text-gray-500">
                        {item.type}
                    </span>
                 )}
            </div>
        </div>
    );
};

export default McpCard;