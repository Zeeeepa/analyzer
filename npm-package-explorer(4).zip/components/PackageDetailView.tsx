// DEPRECATED: Replaced by ProjectExplorer.tsx
export default function PackageDetailView() { return null; }