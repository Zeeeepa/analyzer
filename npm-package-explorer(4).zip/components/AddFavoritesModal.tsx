import React, { useState } from 'react';
import Spinner from './Spinner';
import { CloseIcon } from './icons';

interface AddFavoritesModalProps {
  onClose: () => void;
  onAdd: (packageNames: string[]) => Promise<{ success: string[]; failed: string[] }>;
}

const AddFavoritesModal: React.FC<AddFavoritesModalProps> = ({ onClose, onAdd }) => {
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<{ success: string[]; failed: string[] } | null>(null);

  const handleSubmit = async () => {
    setIsLoading(true);
    setResult(null);
    const names = inputText
      .split(/[\s,;\n]+/)
      .map(name => name.trim())
      .filter(Boolean);
    
    const res = await onAdd(names);
    setResult(res);
    setIsLoading(false);
    setInputText('');
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 border border-gray-700 rounded-lg shadow-2xl w-full max-w-lg flex flex-col">
        <header className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-xl font-bold text-red-400">Bulk Add Favorites</h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-700">
            <CloseIcon className="w-6 h-6 text-gray-400" />
          </button>
        </header>

        <main className="p-6 flex-1">
          {result ? (
            <div>
              <h3 className="text-lg font-semibold text-gray-200 mb-2">Bulk Add Results</h3>
              {result.success.length > 0 && (
                <div className="mb-4">
                  <p className="text-green-400 font-medium">{result.success.length} packages added successfully:</p>
                  <div className="bg-gray-900/50 rounded p-2 mt-1 max-h-24 overflow-y-auto text-sm">
                    {result.success.join(', ')}
                  </div>
                </div>
              )}
              {result.failed.length > 0 && (
                <div>
                  <p className="text-red-400 font-medium">{result.failed.length} packages could not be found (they may not be in your local DB):</p>
                  <div className="bg-gray-900/50 rounded p-2 mt-1 max-h-24 overflow-y-auto text-sm">
                    {result.failed.join(', ')}
                  </div>
                </div>
              )}
               <button onClick={onClose} className="mt-6 w-full bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-500">
                    Close
                </button>
            </div>
          ) : (
            <>
              <p className="text-gray-400 mb-2 text-sm">
                Paste a list of package names. They can be separated by spaces, commas, semicolons, or new lines.
              </p>
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="react, vue, @angular/core..."
                className="w-full h-48 bg-gray-900 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-red-500 resize-none font-mono text-sm"
              />
            </>
          )}
        </main>
        
        {!result && (
            <footer className="p-4 border-t border-gray-700 flex justify-end gap-4">
                {isLoading && <Spinner/>}
                <button onClick={onClose} disabled={isLoading} className="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-500 disabled:opacity-50">
                    Cancel
                </button>
                <button onClick={handleSubmit} disabled={isLoading || !inputText} className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-500 disabled:bg-gray-500 disabled:cursor-not-allowed">
                    {isLoading ? 'Adding...' : 'Add to Favorites'}
                </button>
            </footer>
        )}
      </div>
    </div>
  );
};

export default AddFavoritesModal;