// DEPRECATED: Replaced by PackageCard.tsx grid
export default function PackageTable() { return null; }