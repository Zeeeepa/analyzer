// DEPRECATED: Replaced by ProjectCard.tsx
export default function RepoCard() { return null; }