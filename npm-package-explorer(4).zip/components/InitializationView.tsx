// DEPRECATED
export default function InitializationView() { return null; }