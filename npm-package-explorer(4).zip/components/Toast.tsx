import React, { useState, createContext, useContext, useCallback, ReactNode } from 'react';
import { CloseIcon } from './icons';

type ToastType = 'success' | 'error' | 'info';

interface ToastMessage {
  id: number;
  message: string;
  type: ToastType;
}

interface ToastContextType {
  addToast: (toast: Omit<ToastMessage, 'id'>) => void;
  removeToast: (id: number) => void;
}

const ToastContext = createContext<ToastContextType | undefined>(undefined);

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
};

export const ToastProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback((toast: Omit<ToastMessage, 'id'>) => {
    const id = Date.now();
    setToasts((prevToasts) => [...prevToasts, { ...toast, id }]);
    setTimeout(() => {
      removeToast(id);
    }, 5000); // Auto-dismiss after 5 seconds
  }, []);

  const removeToast = useCallback((id: number) => {
    setToasts((prevToasts) => prevToasts.filter((toast) => toast.id !== id));
  }, []);

  return (
    <ToastContext.Provider value={{ addToast, removeToast }}>
      {children}
      <ToastContainer toasts={toasts} removeToast={removeToast} />
    </ToastContext.Provider>
  );
};

const ToastContainer: React.FC<{ toasts: ToastMessage[]; removeToast: (id: number) => void }> = ({ toasts, removeToast }) => {
  return (
    <div className="fixed top-5 right-5 z-[100] space-y-2">
      {toasts.map((toast) => (
        <Toast key={toast.id} message={toast} onDismiss={removeToast} />
      ))}
    </div>
  );
};

const toastStyles = {
  success: { bg: 'bg-green-500', border: 'border-green-600' },
  error: { bg: 'bg-red-500', border: 'border-red-600' },
  info: { bg: 'bg-blue-500', border: 'border-blue-600' },
};

const Toast: React.FC<{ message: ToastMessage; onDismiss: (id: number) => void }> = ({ message, onDismiss }) => {
  const style = toastStyles[message.type];
  return (
    <div className={`${style.bg} ${style.border} text-white text-sm rounded-md shadow-lg flex items-center p-3 border-l-4 animate-fade-in-right`}>
      <div className="flex-grow">{message.message}</div>
      <button onClick={() => onDismiss(message.id)} className="ml-4 p-1 rounded-full hover:bg-white/20">
        <CloseIcon className="w-4 h-4" />
      </button>
    </div>
  );
};

// Add keyframes animation to index.html or a global CSS file if you have one.
// For now, let's inject it via a style tag in the Toast.tsx file itself for simplicity.
const animationStyle = `
@keyframes fade-in-right {
  from {
    opacity: 0;
    transform: translateX(100%);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}
.animate-fade-in-right {
  animation: fade-in-right 0.3s ease-out forwards;
}
`;

// A simple component to inject the style
const AnimationStyles = () => <style>{animationStyle}</style>;

// It's good practice to include this at the root, e.g., in App.tsx
// But for encapsulation, we can have ToastProvider render it.
// Let's modify ToastProvider to include this.
export const ToastProviderWithStyles: React.FC<{ children: ReactNode }> = ({ children }) => (
    <>
        <AnimationStyles/>
        <ToastProvider>{children}</ToastProvider>
    </>
)
