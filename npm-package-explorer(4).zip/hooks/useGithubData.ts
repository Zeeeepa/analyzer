
import { useState, useCallback } from 'react';
import { GithubConfig } from '../types';
import { githubDataService } from '../services/githubDataService';
import { useToast } from '../components/Toast';

type DataItem = { id?: string; [key: string]: any };

export function useGithubData<T extends DataItem>(
    config: GithubConfig | null,
    isConfigured: boolean,
    path: string,
    entityName: string // e.g., 'Projects', 'Knowledge Items'
) {
    const [data, setData] = useState<T[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [isSyncing, setIsSyncing] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const { addToast } = useToast();

    const load = useCallback(async () => {
        if (!isConfigured || !config) {
            // Do not clear data here, just return. 
            // This prevents wiping local state if config is temporarily invalid.
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            const loadedData = await githubDataService.loadData<T>(config, path);
            const dataWithIds = loadedData.map(item => ({
                ...item,
                id: item.id || crypto.randomUUID(),
            }));
            setData(dataWithIds as T[]);
            addToast({ message: `${entityName} loaded from GitHub.`, type: 'success' });
        } catch (err) {
            const message = err instanceof Error ? err.message : `An unknown error occurred while loading ${entityName}.`;
            setError(message);
            addToast({ message, type: 'error' });
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    }, [isConfigured, config, path, entityName, addToast]);

    const save = useCallback(async () => {
        if (!isConfigured || !config) {
            setError('GitHub is not configured properly. Check Settings.');
            addToast({ message: 'GitHub configuration incomplete.', type: 'error' });
            return;
        }
        setIsSyncing(true);
        setError(null);
        try {
            await githubDataService.saveData(config, path, data, `Update ${entityName}`);
            addToast({ message: `${entityName} saved to GitHub.`, type: 'success' });
        } catch (err) {
            const message = err instanceof Error ? err.message : `An unknown error occurred while saving ${entityName}.`;
            setError(message);
            addToast({ message, type: 'error' });
        } finally {
            setIsSyncing(false);
        }
    }, [isConfigured, config, path, data, entityName, addToast]);
    
    const add = useCallback((item: T) => {
        const newItem = { ...item, id: crypto.randomUUID() };
        setData(prev => [...prev, newItem as T]);
        addToast({ message: `${entityName.slice(0, -1)} added locally. Save to persist.`, type: 'info' });
    }, [addToast, entityName]);

    const update = useCallback((id: string, updatedItem: T) => {
        setData(prev => prev.map(item => (item.id === id ? updatedItem : item)));
        addToast({ message: `${entityName.slice(0, -1)} updated locally. Save to persist.`, type: 'info' });
    }, [addToast, entityName]);

    const remove = useCallback((id: string) => {
        setData(prev => prev.filter(item => item.id !== id));
        addToast({ message: `${entityName.slice(0, -1)} removed locally. Save to persist.`, type: 'info' });
    }, [addToast, entityName]);


    return { data, setData, isLoading, isSyncing, error, load, save, add, update, remove };
}
