
import React from 'react';
import { ToastProviderWithStyles } from './components/Toast';
import { StudioProvider } from './contexts/StudioContext';
import StudioLayout from './components/StudioLayout';

const App: React.FC = () => {
    return (
        <ToastProviderWithStyles>
            <StudioProvider>
                <StudioLayout />
            </StudioProvider>
        </ToastProviderWithStyles>
    );
};

export default App;
