
// A simple JSON to CSV converter
export function jsonToCsv<T extends Record<string, any>>(jsonData: T[]): string {
  if (!jsonData || jsonData.length === 0) {
    return "";
  }
  
  const keys = Object.keys(jsonData[0]);
  const replacer = (key: string, value: any) => value === null ? '' : value;

  const csvRows = jsonData.map(row =>
    keys.map(fieldName => {
        let value = row[fieldName];
        
        // Handle Arrays (primitive or objects)
        if (Array.isArray(value)) {
             // Always serialize arrays to JSON to preserve structure (e.g. package lists, tags)
             return `"${JSON.stringify(value).replace(/"/g, '""')}"`;
        }
        
        // Handle Objects (nested metadata)
        if (typeof value === 'object' && value !== null) {
             return `"${JSON.stringify(value).replace(/"/g, '""')}"`;
        }

        if (typeof value === 'string') {
            // Escape double quotes by doubling them
            return `"${value.replace(/"/g, '""')}"`;
        }
        return JSON.stringify(value, replacer);
    }).join(',')
  );

  csvRows.unshift(keys.join(',')); // Add header row
  return csvRows.join('\r\n');
}

// A robust CSV to JSON converter that handles quoted fields and newlines correctly
export function csvToJson<T>(csv: string): T[] {
    const result: T[] = [];
    const rows: string[][] = [];
    let currentRow: string[] = [];
    let currentValue = '';
    let inQuotes = false;

    // 1. Parse CSV into 2D array (handling quoted newlines/commas)
    for (let i = 0; i < csv.length; i++) {
        const char = csv[i];
        const nextChar = csv[i + 1];

        if (inQuotes) {
            if (char === '"') {
                if (nextChar === '"') {
                    currentValue += '"';
                    i++; // Skip next quote (escaped quote)
                } else {
                    inQuotes = false;
                }
            } else {
                currentValue += char;
            }
        } else {
            if (char === '"') {
                inQuotes = true;
            } else if (char === ',') {
                currentRow.push(currentValue);
                currentValue = '';
            } else if (char === '\n' || (char === '\r' && nextChar === '\n')) {
                currentRow.push(currentValue);
                rows.push(currentRow);
                currentRow = [];
                currentValue = '';
                if (char === '\r') i++; // Skip \n
            } else if (char === '\r') {
                // Handle lone \r (old mac style)
                currentRow.push(currentValue);
                rows.push(currentRow);
                currentRow = [];
                currentValue = '';
            } else {
                currentValue += char;
            }
        }
    }
    // Push last row if exists
    if (currentValue || currentRow.length > 0) {
        currentRow.push(currentValue);
        rows.push(currentRow);
    }

    if (rows.length < 2) return [];

    // 2. Map rows to objects using headers
    // Sanitize headers: remove BOM, surrounding quotes, and trim.
    const headers = rows[0].map(h => h.trim().replace(/^"|"$/g, '').replace(/^\uFEFF/, ''));

    for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        // Skip empty lines or lines with mismatching column counts (basic validation)
        if (row.length === 1 && row[0] === '') continue; 
        
        const obj: any = {};
        // Use header length to avoid index out of bounds if row is short
        for (let j = 0; j < headers.length; j++) {
             let value: string | number | boolean | string[] | any = row[j] !== undefined ? row[j] : '';
             const header = headers[j];

             // Type conversion logic
              if (value === 'true') {
                  value = true;
              } else if (value === 'false') {
                  value = false;
              } else if (typeof value === 'string') {
                   // Try JSON parse for arrays/objects (starts with [ or {)
                   const trimmedVal = value.trim();
                   if ((trimmedVal.startsWith('[') && trimmedVal.endsWith(']')) || (trimmedVal.startsWith('{') && trimmedVal.endsWith('}'))) {
                       try {
                           value = JSON.parse(trimmedVal);
                       } catch (e) {
                           // keep as string if parse fails
                       }
                   } else if (!isNaN(Number(value)) && value.trim() !== '') {
                        // Strictly parse numbers if they look like standard numbers (not 0-prefixed unless 0 or decimal)
                        if(!value.startsWith('0') || value === '0' || value.includes('.')) {
                             value = Number(value);
                        }
                   } else if (header === 'keywords' || header === 'categories' || header === 'tags') {
                       // Fallback for old semicolon lists if not JSON
                       if (typeof value === 'string' && value.includes(';') && !value.startsWith('[')) {
                           value = value.split(';').filter(v => v);
                       }
                   }
              }

             obj[header] = value;
        }
        result.push(obj as T);
    }

    return result;
}
