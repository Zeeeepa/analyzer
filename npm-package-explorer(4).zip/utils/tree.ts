import { FileTreeNode } from '../types';

export function buildTreeFromPathList(
    items: { path: string; type: string }[],
    pathSeparator: string = '/'
): FileTreeNode[] {
    const root: FileTreeNode = { name: 'root', path: '', type: 'directory', children: [] };
    
    items.forEach(item => {
        const path = item.path.startsWith(pathSeparator) ? item.path.substring(1) : item.path;
        const parts = path.split(pathSeparator);
        let currentNode = root;
        let currentPath = '';

        parts.forEach((part, index) => {
            currentPath = currentPath ? `${currentPath}${pathSeparator}${part}` : part;
            const isLastPart = index === parts.length - 1;
            // GitHub uses 'blob' for files and 'tree' for directories
            const nodeType = isLastPart && (item.type === 'file' || item.type === 'blob') ? 'file' : 'directory';

            let childNode = currentNode.children?.find(child => child.name === part);

            if (!childNode) {
                childNode = {
                    name: part,
                    // Use the constructed path for directories, and the item path for files
                    // This ensures directories have a unique, stable path for expansion state
                    path: nodeType === 'directory' ? currentPath : item.path,
                    type: nodeType,
                    children: nodeType === 'file' ? undefined : [],
                };
                currentNode.children!.push(childNode);
            }
             if (childNode.type === 'directory' && !childNode.children) {
              childNode.children = [];
            }
            currentNode = childNode;
        });
    });

    const sortNodes = (nodes: FileTreeNode[]) => {
      nodes.sort((a, b) => {
        if (a.type === 'directory' && b.type === 'file') return -1;
        if (a.type === 'file' && b.type === 'directory') return 1;
        return a.name.localeCompare(b.name);
      });
      nodes.forEach(node => {
        if (node.children) {
          sortNodes(node.children);
        }
      });
    };
    
    if (root.children) {
        sortNodes(root.children);
        return root.children;
    }
    return [];
}