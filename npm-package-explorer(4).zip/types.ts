// types.ts

// --- Unified Resource Types ---

export type ResourceType = 'github_repo' | 'npm_package' | 'knowledge_item' | 'mcp_server';

export interface StudioResource {
  id: string;
  type: ResourceType;
  name: string;
  owner?: string; // for github
  version?: string; // for npm
  description?: string;
  tags: string[];
  metadata: Record<string, any>; // Flexible storage for specific stats
  lastAnalyzed?: string;
  contentSummary?: string; // For RAG context
}

export interface ViewedResource {
    type: 'github' | 'npm';
    name: string; // "facebook/react" or "react"
    version?: string; // "HEAD" or "latest"
    description?: string;
    data: any; // The EnrichedPackageInfo or GitProject object
}

// --- Library & Context Types ---

export interface LibraryContext {
    isHydrated: boolean;
    files: Record<string, string>; // path -> content map for "Hot" files
    structure: string[]; // Simplified list of all paths
    importantPaths: string[]; // Detected entry points, configs, etc.
}

// --- Agent Swarm Types ---

export type AgentStatus = 'idle' | 'thinking' | 'working' | 'completed' | 'failed';

export interface AgentNode {
  id: string;
  parentId?: string;
  name: string;
  role: 'overseer' | 'researcher' | 'coder' | 'reviewer';
  status: AgentStatus;
  currentTask?: string;
  depth: number;
  logs: string[];
  children: string[]; // Child Agent IDs
  result?: string;
}

export interface SwarmState {
  agents: Record<string, AgentNode>;
  rootAgentId: string;
  activeTaskCount: number;
}

// --- Legacy Types (Preserved for Service Compatibility) ---

export interface EnrichedPackageInfo {
  id?: string;
  name: string;
  status: 'indexed' | 'enriched' | 'enrich-failed' | 'untracked';
  isFavorite: 0 | 1;
  version?: string;
  description?: string;
  lastPublished?: string;
  fileCount?: number;
  unpackedSize?: number;
  dependenciesCount?: number;
  devDependenciesCount?: number;
  keywords?: string[];
  homepage?: string;
  repositoryUrl?: string;
  license?: string;
  codeFileCount?: number;
  docFileCount?: number;
  totalLinesOfCode?: number;
  entrypoints?: string;
  hasTypes?: boolean;
  techStack?: string[];
  symbolGraph?: string;
  mermaidGraph?: string;
  infographic?: string;
  d3Graph?: string;
  analysisData?: string;
  lastAnalyzed?: string;
  // New Stats
  downloads?: number;
  stars?: number;
  maintainers?: { name: string; email?: string }[];
}

export interface NpmUser {
    id?: string;
    username: string;
    email?: string;
    avatar?: string;
    packageCount: number;
    packages: Partial<EnrichedPackageInfo>[];
    lastUpdated: string;
}

export interface FileTreeNode {
  name:string;
  path: string;
  type: 'file' | 'directory';
  children?: FileTreeNode[];
  size?: number;
  isEntrypoint?: boolean;
  sha?: string;
}

export interface GithubConfig {
    token: string;
    owner: string;
    repo: string;
}

export interface RepoMetadata {
    fileCount: number;
    codeFileCount: number;
    linesOfCode: number;
}

export interface GithubRepo {
    id: number;
    name: string;
    full_name: string;
    private: boolean;
    owner: {
        login: string;
        avatar_url: string;
    };
    description: string | null;
    fork: boolean;
    html_url: string;
    language: string | null;
    size: number;
    updated_at: string;
    stargazers_count: number;
    metadata?: any;
    default_branch?: string;
    parent?: GithubRepo;
}

export interface GithubUser {
  login: string;
  id: number;
  avatar_url: string;
  html_url: string;
}

export interface GitProject {
  id?: string;
  projectName: string;
  description?: string;
  originUrl?: string;
  owner: string;
  fileCount?: number;
  codeFileCount?: number;
  totalLinesOfCode?: number;
  entrypoints?: string[]; 
  language?: string;
  stars?: number;
  updatedAt?: string;
  mermaidGraph?: string;
  analysisData?: string;
  lastAnalyzed?: string;
  infographic?: string;
  d3Graph?: string;
  // New Fields
  commitsBehind?: number;
  lcpm?: number; // Lines Committed Per Month
}

export interface AnalysisResult {
  exports: any;
  structure: any;
  dependencyGraph: any;
  mermaidGraph?: string;
  d3Graph?: { nodes: D3Node[]; links: D3Link[] };
  infographic?: string;
}

export interface D3Node {
  id: string;
  label: string;
  group: number;
  type?: string;
  val?: number; 
}

export interface D3Link {
  source: string;
  target: string;
  value: number;
}

export interface ChatContext {
  type: 'github' | 'npm' | 'global';
  name: string;
  owner?: string;
  version?: string;
  description?: string;
  analysisData?: string;
  language?: string;
}

export interface KnowledgeItem {
  id: string;
  type: 'url' | 'file' | 'note';
  title: string;
  source: string;
  content?: string;
  tags?: string[]; 
  createdAt: string;
}

export interface McpSource { id?: string; name: string; url: string; }
export interface McpPackage { id?: string; name: string; source: string; category?: string; tags?: string[]; description?: string; configuration?: string; }
export interface McpServer { id?: string; name: string; url: string; type: 'stdio' | 'sse'; description?: string; }
export interface ApiDefinition { id: string; name: string; description?: string; endpointUrl: string; method: string; tags?: string[]; }
export interface RepoCategoryAssignment { id: string; repoFullName: string; categories: string[]; }
export interface SymbolData { type: string; name: string; line: number; args?: string; usage?: string[]; }

export interface UserVariable {
    id: string;
    key: string;
    value: string;
    updatedAt: string;
}

export interface JsDelivrFile {
  name: string;
  hash: string;
  time: string;
  size: number;
  type: 'file' | 'directory';
}

export interface JsDelivrDir {
  files: JsDelivrFile[];
  default: string;
}

export interface FileDiff {
  sha: string;
  filename: string;
  status: 'added' | 'removed' | 'modified' | 'renamed';
  additions: number;
  deletions: number;
  changes: number;
  patch?: string;
}

export interface DiffResult {
  status: string;
  ahead_by: number;
  behind_by: number;
  total_commits: number;
  files: FileDiff[];
  commits: any[];
}